jQuery( document ).ready(function() {
    jQuery( ".datepicker" ).datepicker();   
});

jQuery(document).ready(function($) {
   $('#add-row').on('click', function() {
     var row = $('.empty-row.screen-reader-text').clone(true);
     row.removeClass('empty-row screen-reader-text');
     row.insertBefore('#repeatable-fieldset-one tbody>tr:last');
     return false;
   });

   $('.remove-row').on('click', function() {
     $(this).parents('tr').remove();
     return false;
   });
 });
 jQuery('#pre_invoice_discount_percent').val();
 jQuery('#formated_total').val(0);
 jQuery('#pre_Discount_Total').val();

 function updateTotal(discount) {
   var discount = parseFloat(jQuery('#pre_invoice_discount_percent').val());

   var subtotal = 0.00;
   var total = 0.00;
   var list = document.getElementsByClassName("custome_prices");

   for (var i = 0; i < list.length; ++i) {
     subtotal1 = (subtotal + parseFloat(list[i].value));
     subtotal = subtotal1;
   }
   discountAmt = ((subtotal * discount) / 100).toFixed(2);
   total = (subtotal - discountAmt).toFixed(2);
   var pre_final = parseFloat(jQuery("#formated_total").val(subtotal));
   jQuery("#pre_Discount_Total").val(total);
   jQuery("#pre_grand_Total").val(subtotal.toFixed(2));
}


jQuery('#pre_invoice_discount_percent').on('change', function() {
  updateTotal();
});