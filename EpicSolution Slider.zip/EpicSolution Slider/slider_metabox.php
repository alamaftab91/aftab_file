<?php
/*
Add meta box in Post type slider
*/
if (!defined('ABSPATH'))
{
    exit;
}

add_action('admin_init', 'pre_add_meta_boxes', 2);
function pre_add_meta_boxes()
{
    add_meta_box('preinvoice-group', 'EpicSolution Slider', 'pre_repeatable_meta_box_display', 'slider', 'normal', 'default');
}
function pre_repeatable_meta_box_display()
{
    global $post;
    $preinvoice_group = get_post_meta($post->ID, 'preinvoice-group', true);
    wp_nonce_field('pre_repeatable_meta_box_nonce', 'pre_repeatable_meta_box_nonce');
?>
    

 <table id="repeatable-fieldset-one" width="100%">
  <tbody>
    <?php
    if ($preinvoice_group):
        foreach ($gpminvoice_group as $field)
        {
?>
    <tr>
      <td>Start Date
        <input type="text" style="width:80%;"  name="invoiceItem[]" value="<?php if ($field['invoiceItem'] != '') echo esc_attr($field['invoiceItem']); ?>" /></td>
      <td>End date
        <input type="text"  style="width:80%;"  onchange='updateTotal();' class="widefat custome_prices" name="price[]" value="<?php if ($field['price'] != '') echo esc_attr($field['price']); ?>" /></td>
      <td><a class="button remove-row" href="#1">Remove</a></td>
    </tr>
    <?php
        }
        else:
            // show a blank one
            
?>
    <tr class='addmoredate'>
      <td id = "imagemetabox">Insert Image
        <input type="file" class= "slider_image" style="width:80%;" name="sliderimage[]" placeholder="insert Image" autocomplete="off" /></td>
      <td>Start Date
        <input type="text" class="datepicker" style="width:80%;" name="invoiceItem[]" placeholder="mm/dd/yyyy" autocomplete="off" /></td>
      <td>End date
        <input type="text" style="width:80%;"  id="input" class="widefat custome_prices datepicker" name="price[]" onchange='updateTotal();' value="" onfocus="(this.value == '') && (this.value = '')"
       onblur="(this.value == '') && (this.value = '')"  placeholder="mm/dd/yyyy" autocomplete="off" /></td>
      <td><a class="button  cmb-remove-row-button button-disabled" href="#">Remove</a></td>
    </tr>
    <?php
        endif; ?>

    <!-- empty hidden one for jQuery -->
    
    <tr class="empty-row screen-reader-text">
      <td>Insert Image
        <input type="file"  style="width:80%;" name="sliderimage[]" placeholder="insert Image" autocomplete="off" /></td>
      <td>Start Date
        <input type="text" class="datepicker" style="width:80%;"  name="invoiceItem[]" placeholder="mm/dd/yyyy" /></td>
      <td>End Date
        <input type="text"  style="width:80%;"   class="widefat custome_prices datepicker" name="price[]" onchange='updateTotal();'  value="" onfocus="(this.value == '') && (this.value = '')"
       onblur="(this.value == '') && (this.value = '')"  placeholder="mm/dd/yyyy"/></td>
      <td><a class="button remove-row" href="#">Remove</a></td>
    </tr>
  </tbody>
</table>
<p><a id="add-row" class="button" href="#">Add another</a></p>

<?php
    }

    add_action('save_post', 'pre_repeatable_meta_box_save');
    function pre_repeatable_meta_box_save($post_id)
    {
        if (!isset($_POST['pre_repeatable_meta_box_nonce']) || !wp_verify_nonce($_POST['pre_repeatable_meta_box_nonce'], 'pre_repeatable_meta_box_nonce')) return;

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

        if (!current_user_can('edit_post', $post_id)) return;

        $old = get_post_meta($post_id, 'preinvoice_group', true);
        $new = array();
        $invoiceItems = $_POST['invoiceItem'];
        $prices = $_POST['price'];
        $count = count($invoiceItems);
        for ($i ;$i < $count;$i++)
        {
            if ($invoiceItems[$i] != ''):
                $new[$i]['invoiceItem'] = stripslashes(strip_tags($invoiceItems[$i]));
                $new[$i]['price'] = stripslashes($prices[$i]); // and however you want to sanitize
                
            endif;
        }
        if (!empty($new) && $new != $old) update_post_meta($post_id, 'preinvoice_group', $new);
        elseif (empty($new) && $old) delete_post_meta($post_id, 'preinvoice_group', $old);
        $pre_invoice_status = $_REQUEST['pre_invoice_status'];
        update_post_meta($post_id, 'pre_invoice_status', $pre_invoice_status);
    }
?>
