<?php
/*
Plugin Name: EpicSolution Slider
Description: This Plugin for EpicSolution Slider.
*/
if(!defined('ABSPATH')){
  exit;
}

/* Plugin Activation Code*/
function cptui_register_my_slider() {
$labels = [
		"name" => __( "Slider", "monstroid2" ),
		"singular_name" => __( "Slider", "monstroid2" ),
		"menu_name" => __( "EpicSolution Slider", "monstroid2" ),
		"add_new" => __( "Add Image", "monstroid2" ),
	];

	$args = [
		"label" => __( "Slider", "monstroid2" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => true,
		"rewrite" => [ "slug" => "slider", "with_front" => true ],
		"query_var" => true,
		"supports" => [ "title" ],
		"show_in_graphql" => false,
		'menu_icon' => 'dashicons-format-gallery',
		'menu_position' => 59,
	];

	register_post_type( "slider", $args );
}
add_action( 'init', 'cptui_register_my_slider' );



function myplugin_flush_rewrites() {
    cptui_register_my_slider();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'myplugin_flush_rewrites' );


/*plugin Deactivation*/
register_uninstall_hook( __FILE__, 'my_plugin_uninstall' );
function my_plugin_uninstall() {

    unregister_post_type( 'slider' );
}



include plugin_dir_path(__FILE__).'slider_metabox.php';


/* Add css and js in Admin panel*/

function wpdocs_slider_enqueue_admin_script() {
    
    wp_enqueue_script( 'datepicker_script', plugin_dir_url( __FILE__ ) . 'assets/js/jquery-ui.js', array(), '1.0' );
    wp_enqueue_style( 'datepicker_style', plugin_dir_url( __FILE__ ) . 'assets/css/jquery-ui.css', array(), '1.0' );
    wp_enqueue_style( 'slider_custom_style', plugin_dir_url( __FILE__ ) . 'assets/css/slider_custom.css', array(), '1.0' );
    wp_enqueue_script( 'slider_custom_script', plugin_dir_url( __FILE__ ) . 'assets/js/slider_custom.js', array(), '1.0' );
    wp_enqueue_script( 'slider_custom_script1', plugin_dir_url( __FILE__ ) . 'assets/js/wp_media_uploader.js', array(), '1.0' );
}
add_action( 'admin_enqueue_scripts', 'wpdocs_slider_enqueue_admin_script' );


