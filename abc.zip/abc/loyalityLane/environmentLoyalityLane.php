<?php
// error_reporting(0);
if(!session_id()) {
    session_start();
}
global $wpdb;
$results = $wpdb->get_results("SELECT * FROM wp_api_detail ORDER BY id DESC");
$api_url = $results[0]->api;
$api_token = $results[0]->token;

 define("BASE_URL", $api_url);

    /* $urlClientSession = BASE_URL.'/ClientSession';
    $curl = curl_init();
    $curlArrayData =  array(
    CURLOPT_URL => $urlClientSession,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => 'username=teetsfoodstore&password=MVC4%26kbz7%2Brh',
    CURLOPT_HTTPHEADER => array(
        'auth_token: v2--5W8kaVGHoUpxcm98nrmtp287KVHZChE9hXWaagYeXJw=--hUvxfLBwMdTBUCwiYLSi7YNv6gMOYQYsOZJyxM1OjemkAR0K9dqRj6f-hvei1K8MNA==',
        'Content-Type: application/x-www-form-urlencoded'
    ),
    );
    curl_setopt_array($curl,$curlArrayData);
    $responseData1 = curl_exec($curl);
    curl_close($curl);
    $token = json_decode($responseData1);
    echo $token->data->ClientToken;*/
 define("CLIENT_TOKEN",$api_token);
?>