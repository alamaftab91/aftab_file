<?php
global $wpdb;

if(isset($_POST['save'])){
  // print_r($_POST); die();
  $apiurl = $_POST['url'];
  $apitoken = $_POST['token'];

  $wpdb->insert( 'wp_api_detail', 
            array( 
            'api' => $apiurl,
            'token'=> $apitoken
    ));
}
$results = $wpdb->get_results("SELECT * FROM wp_api_detail ORDER BY id DESC");
// echo'<pre>';
// print_r($results);
$api_id = $results[0]->id;
$api_url = $results[0]->api;
$api_token = $results[0]->token;

if($_GET['getid']){

        $wpdb->delete( 'wp_api_detail', array( 'id' => $_GET['getid'] ) );
        ?>
        <script>
        jQuery(document).ready( function() {
            window.location.href = "<?php echo get_admin_url();?>options-general.php?page=epicplugin";
        });
        </script>
        <?php
}

?>

<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<style>
input[type=text]#api,#token, select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit]#api_submit {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]#api_submit:hover {
  background-color: #45a049;
}

div#Loyaltylane {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>  
<body>

<h2>Loyaltylane API</h2>

<div id="Loyaltylane">
 <?php  if($results== false){?>
  <form action="" method="post">
    <label for="api">API EndPoint</label>
    <input type="text" id="api" name="url" placeholder="Enter Your API EndPoint.." value="<?php echo $api_url; ?>" autocomplete="off" required>

    <label for="token">Token</label>
    <input type="text" id="token" name="token" placeholder="Enter Your Token.." value="<?php echo $api_token; ?>" autocomplete="off" required>
  
    <input type="submit" id="api_submit" name="save" value="Submit">
  </form>
  <?php  }?>
  <?php if(!empty($results)){ ?>
<form action="" method="post">
    <label for="api">API EndPoint</label>
    <input type="text" id="api" name="url" placeholder="Enter Your API EndPoint.." value="<?php echo $api_url; ?>" autocomplete="off" disabled>

    <label for="token">Token</label>
    <input type="text" id="token" name="token" placeholder="Enter Your Token.." value="<?php echo $api_token; ?>" autocomplete="off" disabled>
  
    <input type="submit" id="api_submit" formaction="<?php echo get_admin_url();?>options-general.php?page=epicplugin&getid=<?php echo $api_id; ?>" name="delete" value="Delete">
  </form>
  <?php }?>  
</div>

</body>
</html>



