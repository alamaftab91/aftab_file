<?php /* couponsrewardspage */

error_reporting(0);
include(plugin_dir_path(__FILE__).'loyalityLane/functions.php');

if($_GET['tab'] == 'home-mobile'){
   ?>
   <style>
      .header-container_wrap{
           display:none;
        }
        #colophon{
         display:none;
        }
       
   </style>
   <?php
}              

if(!array_key_exists('accountid',$_SESSION)){
   if(isset($_COOKIE["member_login"])) {
      $remember = 'on';
      loyaltyLanLogin($_COOKIE["member_login"],$_COOKIE["member_password"],$remember);
   }
}

$current_url = home_url(add_query_arg(array(), $wp->request));

   $header = array(
      "ClientToken : ".CLIENT_TOKEN,
      "ShopperToken :".$_SESSION['ShopperToken'],
      "Content-Type : application/json"
   );

   $isLoggedIn = false;
   if(array_key_exists('accountid',$_SESSION)){
      $isLoggedIn = true;

      $urlbalance = BASE_URL.'/Balance';

      $offer_Value = requestToLL($urlbalance,"GET", $_POST, $header);

      if($_GET['type'] == 'Available' || 'Clipped')
      {
            $urlAvailable = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];
            $respAvailable = requestToLL($urlAvailable,"GET");
         if($_GET['type'] == 'Clipped'){
            $url = BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'];
         }else{
            $url = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];   
         }
      } else if($_GET['type'] == 'Clipped'){
         $url = BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'];
      } else if($_GET['type'] == 'MyClubs'){
         $url = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];
         
      } else {
        echo "<script> window.location.href='".site_url()."/rewards?type=Available'</script>";
      }
      $response = requestToLL( BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'],"GET"); // avl
      $countClipped = requestToLL(BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'],"GET"); // clip
      $clippedCouponsValue  = (object)$countClipped->data->coupons;
      $_SESSION['countClipped'] = count($countClipped->data->coupons);
      
      $reward_value = (object)$offer_Value->data->balances;
      
      //echo $reward_value->BalanceAmount;
   } else {
      $url = BASE_URL.'/Coupon';
      
   }

   $response = requestToLL($url,"GET"); 
   $coupons_value = (object)$response->data->coupons;
   
   $totalAvailableSaving = 0;

   foreach($coupons_value as $data){
      preg_match('/\$([0-9]+[\.,0-9]*)/', $data->OfferSummaryTop, $match);
      $totalAvailableSaving += $match[1];
   }
   $totalClippedSaving = 0;
   foreach($clippedCouponsValue as $data){
      preg_match('/\$([0-9]+[\.,0-9]*)/', $data->OfferSummaryTop, $match);
      $totalClippedSaving += $match[1];
   }

   ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>/epicsolutions/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>/epicsolutions/templates/css/style.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>/epicsolutions/templates/css/responsive.css">
<style>
#img_data{
   display:none;
}
/* Absolute Center Spinner */
.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.loading:before {
  content: '';
  display: hide;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
    background: radial-gradient(rgba(20, 20, 20,.8), rgba(0, 0, 0, .8));

  background: -webkit-radial-gradient(rgba(20, 20, 20,.8), rgba(0, 0, 0,.8));
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}

.loading:not(:required):after {
  content: '';
  display: block;
  font-size: 10px;
  width: 1em;
  height: 1em;
  margin-top: -0.5em;
  -webkit-animation: spinner 150ms infinite linear;
  -moz-animation: spinner 150ms infinite linear;
  -ms-animation: spinner 150ms infinite linear;
  -o-animation: spinner 150ms infinite linear;
  animation: spinner 150ms infinite linear;
  border-radius: 0.5em;
  -webkit-box-shadow: rgba(255,255,255, 0.75) 1.5em 0 0 0, rgba(255,255,255, 0.75) 1.1em 1.1em 0 0, rgba(255,255,255, 0.75) 0 1.5em 0 0, rgba(255,255,255, 0.75) -1.1em 1.1em 0 0, rgba(255,255,255, 0.75) -1.5em 0 0 0, rgba(255,255,255, 0.75) -1.1em -1.1em 0 0, rgba(255,255,255, 0.75) 0 -1.5em 0 0, rgba(255,255,255, 0.75) 1.1em -1.1em 0 0;
box-shadow: rgba(255,255,255, 0.75) 1.5em 0 0 0, rgba(255,255,255, 0.75) 1.1em 1.1em 0 0, rgba(255,255,255, 0.75) 0 1.5em 0 0, rgba(255,255,255, 0.75) -1.1em 1.1em 0 0, rgba(255,255,255, 0.75) -1.5em 0 0 0, rgba(255,255,255, 0.75) -1.1em -1.1em 0 0, rgba(255,255,255, 0.75) 0 -1.5em 0 0, rgba(255,255,255, 0.75) 1.1em -1.1em 0 0;
}

/* Animation */

@-webkit-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@-moz-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@-o-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
 
      #config{
          overflow: auto;
          margin-bottom: 10px;
      }
      .config{
          float: left;
          width: 200px;
          height: 250px;
          border: 1px solid #000;
          margin-left: 10px;
      }
      .config .title{
          font-weight: bold;
          text-align: center;
      }
      .config .barcode2D,
      #miscCanvas{
        display: none;
      }
      #submit{
          clear: both;
      }
      #barcodeTarget,
      #canvasTarget{
        margin-top: 20px;
      }
    


      @media(max-width:992px){
         #barcodeTarget {
    margin-top: 20px;
    TOP: 0;
    BACKGROUND: white;
    WIDTH: 100%;
    HEIGHT: 100%;

}


        }
        @media only screen and (min-device-width: 320px) and (max-device-width: 767px){
.registerSec {
    padding: 0;

   
   }
   #barcodeTarget p {
    font-size: 39px !important;
}
   .maincontent {

    padding: 0px;
}

   span.alert.alert-success {
    font-size: 12px;
}
   .edit_pro{
      font-size: 18px;
   }
}


      @media(max-width:1199px){
         .couponsTab .nav-item{
            margin-bottom:10px;
         }
         .colorboxmain{
            height:80px;
         }
      }
      @media(max-width:1000px){ 
         .colorboxmain{
            height:75px;
         }
      }
      @media(max-width:900px){ 
         .colorboxmain{
            height:50px;
         }
      }
      @media(max-width:800px){ 
         .colorboxmain{
            height:45px;
         }
      }
      @media(max-width:700px){ 
         .colorboxmain{
            height:30px;
         }
      }
      @media(max-width:600px){ 
         .colorboxmain{
            height:25px;
         }
      }
      @media(max-width:500px){ 
         .colorboxmain{
            height:25px;
         }
         #barcodeTarget{
            zoom:80%;
            margin:auto;
         }




      }
      @media(max-width:400px){ 
         .colorboxmain{
            height:20px;
            margin:5px;
         }
         #barcodeTarget{
            zoom:75%;
            margin:auto;
         }
      }
      @media(max-width:300px){ 
         .colorboxmain{
            height:15px; 
         } 
         #barcodeTarget{
            zoom:50%;
            margin:auto;
         }
      }
      
      .sfsiplus_footerLnk{
    display: none;
}

      
</style>
<div id="page-loader" class="loading">Loading&#8230;</div>
<!---- Home page start ----->
<div class="main container">
   <!---body conteent----->
   <div class="maincontent">
      <div class="row mt-3 faqavalaiblehide">
         <div class="welcomeUser text-center">
         
         <?php

         if($_SESSION['loyalityLaneUserDetails'] != ''){
            if(!empty($_GET['tab'])){
               $mobileApp = substr($_GET['tab'],-6);
               if($mobileApp == 'mobile'){
                  echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login?logout=true&tab=home-mobile&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>";
               }else{
                  echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login?logout=true&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>";
               }
               
            }else{
               echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login?logout=true&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>";
            }
              
         }else{
          echo ($_GET['tab'] == 'home-mobile') ? '<a href="'.site_url().'/login/?tab=login-mobile" ><button  class="btn mb-3">Sign in</button></a>' : '<a href="'.site_url().'/login" ><button  class="btn mb-3">Sign in</button></a>';
         }

         ?>

         </div>
         
         <div class="col-md-12 mb-2">
            <div class="guidContent">
               <p>To redeem coupons:</p>
               <p>1. Click on the coupons that you want to use.</p>
               <p>2. Your coupons will automatically be applied to qualifying purchases when you give your phone number at the register</p>
            </div>
         </div>
         <div class="col-md-12 mt-2">
            <div class="serachCoupen">

               <select class="form-control selectOp1 brandCatCoupon" id="categoryOption">
               <option value="">Categories</option>
                  <option value="">All</option>
                  <?php 
                     $catData = $response->data->coupons;
                     $cat  = array();  
                     $brand = array();              
                     foreach($catData as $category){									
                     $cat[]   = $category->CategoryName;
                     $brand[] = $category->Brand;									
                     }
                     $cat_array = array_unique($cat);
                     $brand_array = array_unique($brand);
                     sort($cat_array);
                     sort($brand_array);
                     
                     foreach($cat_array as $cat){
                        
                     ?>
                  <option value="<?php echo $cat; ?>"><?php echo $cat; ?></option>
                  <?php 
                    
                     }
                     ?>	
               </select>


               <p id="mssg"></p>
               <select class="form-control selectOp2 brandCatCoupon" id="brandSelected">
                  <option value="">Brands</option>
                  <option value="">All</option>
                  <?php
                     foreach($brand_array as $band){ ?>
                  <option value="<?php echo $band; ?>"><?php echo $band; ?></option>
                  <?php } ?>
               </select>
              
            </div>
           
         </div>
      </div>
      
	  <?php
			if($isLoggedIn){ ?>
      <div class="row mt-3 faqavalaiblehide saving-data">
         <div class="col-md-4">
            <div class="userreward myreward">
               Available Savings: <span id="available_saving">$<?php echo number_format($totalAvailableSaving, 2);?></span>
            </div>
         </div>
         <div class="col-md-4 text-md-center">
            <div class="userreward myreward">
               Clipped Savings: <span id="clipped_saving">$<?php echo number_format($totalClippedSaving, 2); ?></span>
            </div>
         </div>
         <div class="col-md-4 text-md-right">
            <div class="userreward myreward">
               My Reward Points: <?php foreach($reward_value as $reward){ if($reward->BalanceDescription=='Points Balance'){ echo $reward->BalanceAmount; } }?>
            </div>
         </div>
      </div>



			<?php } ?>
      <div class="mt-3">
         <ul class="nav nav-tabs couponsTab" role="tablist">
         <?php
			if($isLoggedIn){

            $url = BASE_URL.'/Balance';
            $response = requestToLL($url,"GET",$_POST,$header); 
            
            ?>
         <li class="nav-item availables">
               <a <?php if($_GET['tab'] == 'home-mobile' || $_GET['tab'] == 'clipped-count-mobile'){?>style="display:none;" <?php }?> id="available-count" class="nav-link <?php echo ($_GET['type']=="Available" || $_GET['type']=="") ? 'active':'none' ?>" href="javascript:void(0);" role="tab">Available (<?php echo count($respAvailable->data->coupons) ?>)</a>
         </li>
         <li class="nav-item availables" <?php if($_GET['tab'] == 'home-mobile' || $_GET['tab'] == 'clipped-count-mobile'){ }else{?> style="display:none;" <?php } ?>>
         <a id="home-mobile" class="nav-link <?php echo ($_GET['type']=="Available" || $_GET['type']=="") ? 'active':'none' ?>" href="javascript:void(0);" role="tab">Available (<?php echo count($respAvailable->data->coupons) ?>)</a>
         </li>
			<li class="nav-item clipeds">
				<a <?php if($_GET['tab'] == 'home-mobile' || $_GET['tab'] == 'clipped-count-mobile'){?>style="display:none;" <?php }?> id="clipped-count" class="nav-link <?php echo ($_GET['type']=="Clipped") ? 'active':'none' ?>"  href="javascript:void(0);" role="tab">Clipped (<span id="clippedCountData"><?php echo count($countClipped->data->coupons) ?></span>)</a>
			</li>
         <li class="nav-item clipeds" <?php if($_GET['tab'] == 'home-mobile' || $_GET['tab'] == 'clipped-count-mobile'){ }else{?> style="display:none;" <?php } ?>>
				<a id="clipped-count-mobile" class="nav-link <?php echo ($_GET['type']=="Clipped") ? 'active':'none' ?>"  href="javascript:void(0);" role="tab">Clipped (<span id="clippedCountValue"><?php echo count($countClipped->data->coupons) ?></span>)</a>
			</li>
			<li class="nav-item myclubs">
				<a id="myclub-count" class="nav-link <?php echo ($_GET['type']=="MyClubs") ? 'active':'none' ?>" href="javascript:void(0);" role="tab">My Clubs (<?php echo count($response->data->offer_balances); ?>)</a>
			</li>
         <li class="nav-item my-rewards">
				<a id="my-reward" class="nav-link <?php echo ($_GET['type']=="MyReward") ? 'active':'none' ?>" href="<?php echo site_url()?>/reward-special/" role="tab">Reward Specials</a>
			</li>
         <li class="nav-item edit-profiles">
				<a id="edit-profile" class="nav-link" href="javascript:void(0);" role="tab">Edit Profile </a>
			</li>
         <li class="nav-item member-ids">
				<a id="member-id" class="nav-link" href="javascript:void(0);" role="tab">Member Id </a>
         </li>
         <li class="nav-item faq-pages">
				<a id="faq-page" class="nav-link" href="<?php echo site_url()?>/faqs/" role="tab">FAQs</a>
			</li>
         <li class="nav-item edit-profiles" style="display:none;">
				<a id="edit-profile-mobile" class="nav-link" href="javascript:void(0);" role="tab">Edit Profile </a>
			</li>
         <li class="nav-item member-ids" style="display:none;">
				<a id="member-id-mobile" class="nav-link" href="javascript:void(0);" role="tab">Member Id </a>
         </li>
         <li class="nav-item myclubs" style="display:none;">
				<a id="myclub-count-mobile" class="nav-link" href="javascript:void(0);" role="tab">My Clubs</a>
			</li>
         
			<?php } ?>
            
         </ul>
         <!-- Tab panes -->
         
         <div class="tab-content">
            <div class="tab-pane active" id="Available" role="tabpanel">
      
               <div class="row">
                  <?php 
                     foreach($coupons_value as $data){
                     ?>
                   <div class="col-md-6 col-lg-4 col-xl-4 <?php echo 'cat'.$data->CategoryName; ?> dataHide">
                     <div class="couponsItems">
                        <div class="proImg">
                           <img src="<?php echo $data->ImageUrl; ?>" class="customcouponimgheight img-fluid" style="width: auto; max-height: 100%; max-width: 100%;">
                        </div>
                        <div class="proDetails">
                           <h3><?php echo substr($data->OfferSummaryTop,0,11); ?></h3>
                           <p><?php echo substr($data->OfferShortDesc,0,70).'..'; ?></p>
                           <?php

                                $timestamp = strtotime($data->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);
                                 if($diff->format("%a")<7){
                                    echo '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }
                              
                           ?>
                        </div>
                     </div>
                     <div class="CoupAction">
                        <div class="<?php if($_GET['type']=='Clipped'){?>ActionBtnLarge<?php }else{?>ActionBtn<?php } ?>">
                       
                          <a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-available-id="Available" data-coupon-id="<?php echo $data->id ?>" class="coupDetails" id="coupon_details">Details</a>
                          
                           <?php if(empty($_SESSION['ShopperToken'])){ ?>	
                           <a href="<?php echo site_url();?>/login" class="coupSinup">Sign in To Clip </a>
                           <?php } else{ 
                           if($_GET['type']=="Clipped") {
                              echo "";
                           } else {
                              ?>
                           <!-- <a id="clipCoupon" href="<?php //echo site_url()?>/coupon?couponId=<?php //echo $data->id?>" class="coupSinup">Clip Coupon</a> -->
                           <a id="clipCoupon" href="javascript:void(0);" data-coupons-id=<?php echo $data->id; ?> class="coupSinup">Clip Coupon</a>
                           <?php } } ?>		
                        </div>
                        <div class="ShareFB loginBtn--facebook">
                        <a fb-data-URL="<?php echo $current_url; ?>" fb-data-image="<?php echo $data->ImageUrl?>" fb-data-title="<?php echo $data->OfferShortDesc ?>" href="javascript:void(0);" class="ShareFB">Share on Facebook</a><br>
                        
                        </div>
                     </div>
                   </div>
                   <?php 
                  }
               
               ?>
               </div>
            </div>
         </div>
      </div>
   </div>

   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
	<script type="text/javascript" src="<?php echo plugin_dir_url('__FILE__')?>/epicsolutions/templates/css/jquery-barcode.js"></script>

   
   <!---body conteent end----->
</div>
<!---- Home page end ----->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
 <div id="modal-loader" class="loading">Loading&#8230;</div>
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Product Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
      <div class="modal-body">

         <div class="row">
           <div class="col-md-6"><b>Product image</b></div>
           <div class="col-md-6"><img src="" id="img_data" height="90px" width="90px"/></div>
           <div class="col-md-6"><b>Brand</b></div>
           <div class="col-md-6" id="brand_data"></div>
           <div class="col-md-6"><b>Category</b></div>
           <div class="col-md-6" id="category_data"></div>
           <div class="col-md-6"><b>Short Description</b></div>
           <div class="col-md-6" id="short_data"></div>
           <div class="col-md-6"><b>Expiration Date</b></div>
           <div class="col-md-6" id="expiration_data"></div>
           <div class="col-md-6"><b>UPCs</b></div>
           <div class="col-md-6" id="ItemUPCs" style="max-height: 150px; overflow-y: scroll;"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>
<div class='error' style="display:none;">Coupon has been clipped successfully!</div>

<script type="text/javascript">
 jQuery( document ).ready(function() {
  jQuery(".loading").hide();
    console.log( "ready!" );
});
 function generateBarcode(){
        var value = $("#barcodeValue").val();
        var btype = $("input[name=btype]:checked").val();
        var renderer = $("input[name=renderer]:checked").val();

        var settings = {
          output:renderer,
          bgColor: $("#bgColor").val(),
          color: $("#color").val(),
          barWidth: $("#barWidth").val(),
          barHeight: $("#barHeight").val(),
          moduleSize: $("#moduleSize").val(),
          posX: $("#posX").val(),
          posY: $("#posY").val(),
          addQuietZone: $("#quietZoneSize").val()
        };
        if ($("#rectangular").is(':checked') || $("#rectangular").attr('checked')){
          value = {code:value, rect: true};
        }
        if (renderer == 'canvas'){
          clearCanvas();
          $("#barcodeTarget").hide();
          $("#canvasTarget").show().barcode(value, btype, settings);
        } else {
          $("#canvasTarget").hide();
          $("#barcodeTarget").html("").show().barcode(value, btype, settings);
        }
      }
          
      function showConfig1D(){
        $('.config .barcode1D').show();
        $('.config .barcode2D').hide();
      }
      
      function showConfig2D(){
        $('.config .barcode1D').hide();
        $('.config .barcode2D').show();
      }
      
      function clearCanvas(){
        var canvas = $('#canvasTarget').get(0);
        var ctx = canvas.getContext('2d');
        ctx.lineWidth = 1;
        ctx.lineCap = 'butt';
        ctx.fillStyle = '#FFFFFF';
        ctx.strokeStyle  = '#000000';
        ctx.clearRect (0, 0, canvas.width, canvas.height);
        ctx.strokeRect (0, 0, canvas.width, canvas.height);
      }
      
      $(function(){
        $('input[name=btype]').click(function(){
          if ($(this).attr('id') == 'datamatrix') showConfig2D(); else showConfig1D();
        });
        $('input[name=renderer]').click(function(){
          if ($(this).attr('id') == 'canvas') $('#miscCanvas').show(); else $('#miscCanvas').hide();
        });
        generateBarcode();
      });


      (function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
      fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
  
    </script>
  
<!--   <script>

$(window).resize(function(){

if ($(window).width() <= 360) {  
   
   $( "#member-id").click(function() {
      $(".faqavalaiblehide").hide();
      $(".couponsTab").hide();
      $(".masthead").hide();
      $("#colophon").hide();
      $(".site-logo").hide();
      $(".availables").hide();
      $(".clipeds").hide();
      $(".myclubs").hide();
      $(".my-rewards").hide();
      $(".edit-profiles").hide();
      $(".member-ids").hide();
      $(".faq-pages").hide();
  }); 
  $( "#edit-profile").click(function() {
   $(".faqavalaiblehide").hide();
      $(".couponsTab").hide();
      $(".masthead").hide();
      $("#colophon").hide();
      $(".site-logo").hide();
      $(".availables").hide();
      $(".clipeds").hide();
      $(".myclubs").hide();
      $(".my-rewards").hide();
      $(".edit-profiles").hide();
      $(".member-ids").hide();
      $(".faq-pages").hide();
  });

}     

});


$(window).resize(function(){

if ($(window).width() <= 480) {  
   
   $( "#member-id").click(function() {
      $(".faqavalaiblehide").hide();
      $(".couponsTab").hide();
      $(".masthead").hide();
      $("#colophon").hide();
      $(".site-logo").hide();
      $(".availables").hide();
      $(".clipeds").hide();
      $(".myclubs").hide();
      $(".my-rewards").hide();
      $(".edit-profiles").hide();
      $(".member-ids").hide();
      $(".faq-pages").hide();
  }); 
  $( "#edit-profile").click(function() {
   $(".faqavalaiblehide").hide();
      $(".couponsTab").hide();
      $(".masthead").hide();
      $("#colophon").hide();
      $(".site-logo").hide();
      $(".availables").hide();
      $(".clipeds").hide();
      $(".myclubs").hide();
      $(".my-rewards").hide();
      $(".edit-profiles").hide();
      $(".member-ids").hide();
      $(".faq-pages").hide();
  });

}     

});

</script> -->
