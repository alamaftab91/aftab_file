<?php

$rewards = get_option('rewards_epic');
wp_delete_post($rewards);
$login = get_option('login_epic');
wp_delete_post($login);
$signup = get_option('signup_epic');
wp_delete_post($signup);
$reward_special = get_option('special_epic');
wp_delete_post($reward_special);
$forget = get_option('forget_epic');
wp_delete_post($forget);
$reset = get_option('reset_epic');
wp_delete_post($reset);
$faq = get_option('faq_page_teet');
wp_delete_post($faq)

?>
