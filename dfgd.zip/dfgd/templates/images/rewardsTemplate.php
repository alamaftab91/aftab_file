<?php /* Template Name: couponsrewardspage */ 
error_reporting(0);
   include(plugin_dir_path(__FILE__).'/loyalityLane/functions.php');
// }
   $header = array(
      "ClientToken : ".CLIENT_TOKEN,
      "ShopperToken :".$_SESSION['ShopperToken'],
      "Content-Type : application/json"
   );
   $isLoggedIn = false;
   if(array_key_exists('accountid',$_SESSION)){
      $isLoggedIn = true;

      $urlbalance = BASE_URL.'/Balance';

    $offer_Value = requestToLL($urlbalance,"GET", $_POST, $header);

      if($_GET['type'] == 'Available' || 'Clipped')
      {
            $urlAvailable = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];
            $respAvailable = requestToLL($urlAvailable,"GET");
         if($_GET['type'] == 'Clipped'){
            $url = BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'];
         }else{
            $url = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];
            
         }
      } else if($_GET['type'] == 'Clipped'){
         $url = BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'];
      } else if($_GET['type'] == 'MyClubs'){
         $url = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];
         
      } else {
        echo "<script> window.location.href='/rewards?type=Available'</script>";
      }
      $response = requestToLL( BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'],"GET"); // avl
      $countClipped = requestToLL(BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'],"GET"); // clip

      
      $clippedCouponsValue  = (object)$countClipped->data->coupons;
      $_SESSION['countClipped'] = count($countClipped->data->coupons);
      
      $reward_value = (object)$offer_Value->data->balances;
      
      echo $reward_value->BalanceAmount;
   } else {
      $url = BASE_URL.'/Coupon';
      
   }

   $response = requestToLL($url,"GET"); 
   $coupons_value = (object)$response->data->coupons;
   
   $totalAvailableSaving = 0;

   foreach($coupons_value as $data){
      preg_match('/\$([0-9]+[\.,0-9]*)/', $data->OfferSummaryTop, $match);
      $totalAvailableSaving += $match[1];
   }
   $totalClippedSaving = 0;
   foreach($clippedCouponsValue as $data){
      preg_match('/\$([0-9]+[\.,0-9]*)/', $data->OfferSummaryTop, $match);
      $totalClippedSaving += $match[1];
   }
  
   ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/templates/css/style.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/templates/css/responsive.css">
<style>
#img_data{
   display:none;
}
/* Absolute Center Spinner */
.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.loading:before {
  content: '';
  display: hide;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
    background: radial-gradient(rgba(20, 20, 20,.8), rgba(0, 0, 0, .8));

  background: -webkit-radial-gradient(rgba(20, 20, 20,.8), rgba(0, 0, 0,.8));
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}

.loading:not(:required):after {
  content: '';
  display: block;
  font-size: 10px;
  width: 1em;
  height: 1em;
  margin-top: -0.5em;
  -webkit-animation: spinner 150ms infinite linear;
  -moz-animation: spinner 150ms infinite linear;
  -ms-animation: spinner 150ms infinite linear;
  -o-animation: spinner 150ms infinite linear;
  animation: spinner 150ms infinite linear;
  border-radius: 0.5em;
  -webkit-box-shadow: rgba(255,255,255, 0.75) 1.5em 0 0 0, rgba(255,255,255, 0.75) 1.1em 1.1em 0 0, rgba(255,255,255, 0.75) 0 1.5em 0 0, rgba(255,255,255, 0.75) -1.1em 1.1em 0 0, rgba(255,255,255, 0.75) -1.5em 0 0 0, rgba(255,255,255, 0.75) -1.1em -1.1em 0 0, rgba(255,255,255, 0.75) 0 -1.5em 0 0, rgba(255,255,255, 0.75) 1.1em -1.1em 0 0;
box-shadow: rgba(255,255,255, 0.75) 1.5em 0 0 0, rgba(255,255,255, 0.75) 1.1em 1.1em 0 0, rgba(255,255,255, 0.75) 0 1.5em 0 0, rgba(255,255,255, 0.75) -1.1em 1.1em 0 0, rgba(255,255,255, 0.75) -1.5em 0 0 0, rgba(255,255,255, 0.75) -1.1em -1.1em 0 0, rgba(255,255,255, 0.75) 0 -1.5em 0 0, rgba(255,255,255, 0.75) 1.1em -1.1em 0 0;
}

/* Animation */

@-webkit-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@-moz-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@-o-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
</style>
<div id="page-loader" class="loading">Loading&#8230;</div>
<!---- Home page start ----->
<div class="main container">
   <!---body conteent----->
   <div class="maincontent">
      <div class="row mt-3">
         <div class="welcomeUser text-center">
            <?php echo ($_SESSION['loyalityLaneUserDetails'] != '') ? "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span class='ddlllogout' style='float:right; color:red; font-size:12px'> <a href='/login?logout=true&token=".$_SESSION['ShopperToken']."'>Logout</a> </span> </h2>" : '<a href="/login" ><button  class="btn mb-3">Sign in</button></a>' ?>
         </div>
         
         <div class="col-md-12 mb-2">
            <div class="guidContent">
               <p>To redeem coupons:</p>
               <p>1. Click on the coupons that you want to use.</p>
               <p>2. Your coupons will automatically be applied to qualifying purchases when you give your phone number at the register</p>
            </div>
         </div>
         <div class="col-md-12 mt-2">
            <div class="serachCoupen">

               <select class="form-control selectOp1 brandCatCoupon" id="categoryOption">
                  <option value="">Categories</option>
                  <?php 
                     $catData = $response->data->coupons;
                     $cat  = array();  
                     $brand = array();              
                     foreach($catData as $category){									
                     $cat[]   = $category->CategoryName;
                     $brand[] = $category->Brand;									
                     }
                     $cat_array = array_unique($cat);
                     $brand_array = array_unique($brand);
                     
                     foreach($cat_array as $cat){
                        
                     ?>
                  <option id = "<?php echo rand(1000,9999).$_GET['type']; ?>" value="<?php echo $cat; ?>"><?php echo $cat; ?></option>
                  <?php 
                    
                     }
                     ?>	
               </select>


               <p id="mssg"></p>
               <select class="form-control selectOp2 brandCatCoupon" id="<?php echo $brand_array; ?>">
                  <option value="">Brands</option>
                  <?php
                     foreach($brand_array as $band){ ?>
                  <option value="<?php echo $band; ?>"><?php echo $band; ?></option>
                  <?php } ?>
               </select>
            </div>
         </div>
      </div>
      
	  <?php
			if($isLoggedIn){ ?>
      <div class="row mt-3">
         <div class="col-md-4">
            <div class="userreward myreward">
               Available Savings: <span id="available_saving">$<?php echo $totalAvailableSaving;?></span>
            </div>
         </div>
         <div class="col-md-4 text-md-center">
            <div class="userreward myreward">
               Clipped Savings: <span id="clipped_saving">$<?php echo $totalClippedSaving; ?></span>
            </div>
         </div>
         <div class="col-md-4 text-md-right">
            <div class="userreward myreward">
               My Reward Points: <?php foreach($reward_value as $reward){ if($reward->BalanceDescription=='Points Balance'){ echo $reward->BalanceAmount; } }?>
            </div>
         </div>
      </div>
			<?php } ?>
      <div class="mt-3">
         <ul class="nav nav-tabs couponsTab" role="tablist">
         <?php
			if($isLoggedIn){

            $url = BASE_URL.'/Balance';
            $response = requestToLL($url,"GET",$_POST,$header); 

            ?>
         <li class="nav-item">
               <a id="available-count" class="nav-link <?php echo ($_GET['type']=="Available" || $_GET['type']=="") ? 'active':'none' ?>" href="javascript:void(0);" role="tab">Available (<?php echo count($respAvailable->data->coupons) ?>)</a>
         </li>
			
			<li class="nav-item">
				<a id="clipped-count" class="nav-link <?php echo ($_GET['type']=="Clipped") ? 'active':'none' ?>"  href="javascript:void(0);" role="tab">Clipped ()</a>
			</li>
			<li class="nav-item">
				<a id="myclub-count" class="nav-link <?php echo ($_GET['type']=="MyClubs") ? 'active':'none' ?>" href="javascript:void(0);" role="tab">My Clubs (<?php echo count($response->data->offer_balances); ?>)</a>
			</li>
         <li class="nav-item">
				<a id="my-reward" class="nav-link <?php echo ($_GET['type']=="MyReward") ? 'active':'none' ?>" href="javascript:void(0);" role="tab">My Reward </a>
			</li>
         <li class="nav-item">
				<a id="edit-profile" class="nav-link" href="javascript:void(0);" role="tab">Edit Profile </a>
			</li>
         <li class="nav-item">
				<a id="member-id" class="nav-link" href="javascript:void(0);" role="tab">Member Id </a>
         </li>
         <li class="nav-item">
				<a id="faq-page" class="nav-link" href="javascript:void(0);" role="tab">FAQ </a>
			</li>
			<?php } ?>
            
         </ul>
         <!-- Tab panes -->
         
         <div class="tab-content">
            <div class="tab-pane active" id="Available" role="tabpanel">
       
               <div class="row">
                  <?php 
                     foreach($coupons_value as $data){
                     ?>
                   <div class="col-md-6 col-lg-4 col-xl-4 <?php echo 'cat'.$data->CategoryName; ?> dataHide">
                     <div class="couponsItems">
                        <div class="proImg">
                           <img src="<?php echo $data->ImageUrl; ?>" class="customcouponimgheight img-fluid">
                        </div>
                        <div class="proDetails">
                           <h3><?php echo substr($data->OfferSummaryTop,0,11); ?></h3>
                           <p><?php echo substr($data->OfferShortDesc,0,70).'..'; ?></p>
                        </div>
                     </div>
                     <div class="CoupAction">
                        <div class="<?php if($_GET['type']=='Clipped'){?>ActionBtnLarge<?php }else{?>ActionBtn<?php } ?>">
                       
                          <a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-coupon-id="<?php echo $data->id ?>" class="coupDetails"  id="coupon_details">Details</a>
                           <?php if(empty($_SESSION['ShopperToken'])){ ?>	
                           <a href="/login" class="coupSinup">Sign in To Clip </a>
                           <?php } else{ 
                           if($_GET['type']=="Clipped") {
                              echo "";
                           } else {
                              ?>
                           <a href="/coupon?couponId=<?php echo $data->id?>" class="coupSinup">Clip Coupon</a>
                           <?php } } ?>		
                        </div>
                        <div class="ShareFB loginBtn--facebook">
                           <a href="">Share on Facebook</a>
                        </div>
                     </div>
                   </div>
                   <?php 
                  }
               
               ?>
               </div>
            </div>
         </div>
      </div>
   </div>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

 
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   
   
   <!---body conteent end----->
</div>
<!---- Home page end ----->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
<div id="modal-loader" class="loading">Loading&#8230;</div>
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Product Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
      <div class="modal-body">

         <div class="row">
           <div class="col-md-6"><b>Product image</b></div>
           <div class="col-md-6"><img src="" id="img_data" height="90px" width="90px"/></div>
           <div class="col-md-6"><b>Brand</b></div>
           <div class="col-md-6" id="brand_data"></div>
           <div class="col-md-6"><b>Category</b></div>
           <div class="col-md-6" id="category_data"></div>
           <div class="col-md-6"><b>Short Description</b></div>
           <div class="col-md-6" id="short_data"></div>
           <div class="col-md-6"><b>Expiration Date</b></div>
           <div class="col-md-6" id="expiration_data"></div>
           <div class="col-md-6"><b>UPCs</b></div>
           <div class="col-md-6" id="ItemUPCs"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>





