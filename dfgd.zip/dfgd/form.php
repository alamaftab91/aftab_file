<?php

global $wpdb;

if(isset($_POST['save'])){

  $apiurl = $_POST['url'];
  $apiuser = $_POST['user'];
  $apipass = $_POST['pass'];
  $apitoken = $_POST['token'];

  $wpdb->insert( 'wp_api_detail', 
            array( 
            'api' => $apiurl,
            'user_name'=> $apiuser,
            'password'=> $apipass,
            'token'=> $apitoken
    ));
}
$results = $wpdb->get_results("SELECT * FROM wp_api_detail ORDER BY id DESC");
// echo'<pre>';
// print_r($results);
$api_id = $results[0]->id;
$api_url = $results[0]->api;
$api_token = $results[0]->token;
$api_user = $results[0]->user_name;
$api_pass = $results[0]->password;

if($_GET['getid']){

        $wpdb->delete( 'wp_api_detail', array( 'id' => $_GET['getid'] ) );
        ?>
        <script>
        jQuery(document).ready( function() {
            window.location.href = "<?php echo get_admin_url();?>options-general.php?page=epicplugin";
        });
        </script>
        <?php
}

?>

<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__); ?>templates/css/form_style.css">
</head>
<body>

<h1>Loyalty Lane API</h1>

<div id="Loyaltylane">
 <?php  if($results== false){?>
  <form action="" method="post">
    <label for="api" id="api_head">Loyalty Lane API Endpoint<span style="color:rgb(255, 38, 0)">*</span></label>
    <input type="text" id="api" name="url" placeholder="Enter Your API EndPoint.." value="" autocomplete="off">
    <span style="color:red" id="apiError"></span><br>

    <label for="user" id="user_head">User Name<span style="color:rgb(255, 38, 0)">*</span></label>
    <input type="text" id="user" name="user" placeholder="Enter Your Username.." value="" autocomplete="off">
    <span style="color:red" id="userError"></span><br>

    <label for="api" id="pass_head">Password<span style="color:rgb(255, 38, 0)">*</span></label>
    <input type="text" id="pass" name="pass" placeholder="Enter Your Password.." value="" autocomplete="off">
    <span style="color:red" id="passError"></span><br>

    <label for="token" id="token_head">EpicSolutions ClientId</label>
    <input type="text" id="token" name="token" placeholder="Enter Your ClientId.." value="" autocomplete="off">
  
    <input type="submit" id="api_submit" onclick="return form_valid()" name="save" value="Submit">
  </form>
  <?php  }?>
  <?php if(!empty($results)){ ?>
<form action="" method="post">
    <label for="api" id="api_head">Loyalty Lane API Endpoint</label>
    <input type="text" id="api" name="url" placeholder="Enter Your API EndPoint.." value="<?php echo $api_url; ?>" autocomplete="off" disabled>

    <label for="api" id="user_head">Username</label>
    <input type="text" id="user" name="user" placeholder="Enter Your Username.." value="<?php echo $api_user ?>" autocomplete="off" disabled>

    <label for="api" id="pass_head">Password</label>
    <input type="text" id="pass" name="pass" placeholder="Enter Your Password.." value="<?php echo $api_pass ?>" autocomplete="off" disabled>


    <label for="token" id="token_head">EpicSolutions ClientId</label>
    <input type="text" id="token" name="token" placeholder="Enter Your ClientId.." value="<?php echo $api_token; ?>" autocomplete="off" disabled>
  
    <input type="submit" id="api_submit" formaction="<?php echo get_admin_url();?>options-general.php?page=epicplugin&getid=<?php echo $api_id; ?>" name="delete" value="Delete">
  </form>
  <?php }?>  
</div>

</body>
</html>

<script >
   function form_valid(){
    var count = true;
    var api = document.getElementById("api").value;
    var user = document.getElementById("user").value;
    var pass = document.getElementById("pass").value;

    if(api == ""){
      document.getElementById("apiError").innerHTML="Loyalty Lane API Endpoint is required.";
      count = false;
    }else{
      document.getElementById("apiError").innerHTML="";
    }
    if(user == ""){
      document.getElementById("userError").innerHTML="User Name is required.";
      count = false;
    }else{
      document.getElementById("userError").innerHTML="";

    }
    if(pass == ""){
      document.getElementById("passError").innerHTML="Password is required.";
      count = false;
    }else{
      document.getElementById("passError").innerHTML="";
    }

  if(count==false){
        return count;       
      }else{
        return count;
      }
}
</script>


