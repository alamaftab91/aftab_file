<?php
/**
 * latify functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Latify
 */

	if(isset($_GET['logout'])){
		setcookie ("member_login","");
		setcookie ("member_password","");
	}


	add_action('init', function() {
	if(!empty($_SESSION['member_login'])){
	if (!isset($_COOKIE['member_login'])) {
		setcookie("member_login",$_SESSION['member_login'], time()+3600 * 24 * 365);
		setcookie("member_password",$_SESSION['member_password'], time()+3600 * 24 * 365);
		//setcookie('my_cookie', 'some default Ram', strtotime('+1 day'));
	}
	}
	});

if ( ! class_exists( 'Latify_Theme_Setup' ) ) {

	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * @since 1.0.0
	 */
	class Latify_Theme_Setup {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private static $instance = null;

		/**
		 * A reference to an instance of cherry framework core class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private $core = null;

		/**
		 * Holder for CSS layout scheme.
		 *
		 * @since 1.0.0
		 * @var   array
		 */
		public $layout = array();

		/**
		 * Holder for current customizer module instance.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		public $customizer = null;

		/**
		 * Holder for current dynamic_css module instance.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		public $dynamic_css = null;

		/**
		 * Sets up needed actions/filters for the theme to initialize.
		 *
		 * @since 1.0.0
		 */
		public function __construct() {

			// Set the constants needed by the theme.
			add_action( 'after_setup_theme', array( $this, 'constants' ), -1 );

			// Load the installer core.
			add_action( 'after_setup_theme', require( trailingslashit( get_template_directory() ) . 'cherry-framework/setup.php' ), 0 );

			// Load the core functions/classes required by the rest of the theme.
			add_action( 'after_setup_theme', array( $this, 'get_core' ), 1 );

			// Language functions and translations setup.
			add_action( 'after_setup_theme', array( $this, 'l10n' ), 2 );

			// Handle theme supported features.
			add_action( 'after_setup_theme', array( $this, 'theme_support' ), 3 );

			// Load the theme includes.
			add_action( 'after_setup_theme', array( $this, 'includes' ), 4 );

			// Initialization of modules.
			add_action( 'after_setup_theme', array( $this, 'init' ), 10 );

			// Load admin files.
			add_action( 'wp_loaded', array( $this, 'admin' ), 1 );

			// Enqueue admin assets.
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

			// Register public assets.
			add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 9 );

			// Enqueue public assets.
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ), 20 );

			// Overrides the load textdomain function for the 'cherry-framework' domain.
			add_filter( 'override_load_textdomain', array( $this, 'override_load_textdomain' ), 5, 3 );

		}

		/**
		 * Defines the constant paths for use within the core and theme.
		 *
		 * @since 1.0.0
		 */
		public function constants() {
			global $content_width;

			/**
			 * Fires before definitions the constants.
			 *
			 * @since 1.0.0
			 */
			do_action( 'latify_constants_before' );

			$template  = get_template();
			$theme_obj = wp_get_theme( $template );

			/** Sets the theme version number. */
			define( 'LATIFY_THEME_VERSION', $theme_obj->get( 'Version' ) );

			/** Sets the theme directory path. */
			define( 'LATIFY_THEME_DIR', get_template_directory() );

			/** Sets the theme directory URI. */
			define( 'LATIFY_THEME_URI', get_template_directory_uri() );

			/** Sets the path to the core framework directory. */
			defined( 'CHERRY_DIR' ) or define( 'CHERRY_DIR', trailingslashit( LATIFY_THEME_DIR ) . 'cherry-framework' );

			/** Sets the path to the core framework directory URI. */
			defined( 'CHERRY_URI' ) or define( 'CHERRY_URI', trailingslashit( LATIFY_THEME_URI ) . 'cherry-framework' );

			/** Sets the theme includes paths. */
			define( 'LATIFY_THEME_CLASSES', trailingslashit( LATIFY_THEME_DIR ) . 'inc/classes' );
			define( 'LATIFY_THEME_WIDGETS', trailingslashit( LATIFY_THEME_DIR ) . 'inc/widgets' );
			define( 'LATIFY_THEME_EXT', trailingslashit( LATIFY_THEME_DIR ) . 'inc/extensions' );

			/** Sets the theme assets URIs. */
			define( 'LATIFY_THEME_CSS', trailingslashit( LATIFY_THEME_URI ) . 'assets/css' );
			define( 'LATIFY_THEME_JS', trailingslashit( LATIFY_THEME_URI ) . 'assets/js' );

			// Sets the content width in pixels, based on the theme's design and stylesheet.
			if ( ! isset( $content_width ) ) {
				$content_width = 885;
			}
		}

		/**
		 * Loads the core functions. These files are needed before loading anything else in the
		 * theme because they have required functions for use.
		 *
		 * @since  1.0.0
		 */
		public function get_core() {
			/**
			 * Fires before loads the core theme functions.
			 *
			 * @since 1.0.0
			 */
			do_action( 'latify_core_before' );

			global $chery_core_version;

			if ( null !== $this->core ) {
				return $this->core;
			}

			if ( 0 < sizeof( $chery_core_version ) ) {
				$core_paths = array_values( $chery_core_version );

				require_once( $core_paths[0] );
			} else {
				die( 'Class Cherry_Core not found' );
			}

			$this->core = new Cherry_Core( array(
				'base_dir' => CHERRY_DIR,
				'base_url' => CHERRY_URI,
				'modules'  => array(
					'cherry-js-core' => array(
						'autoload' => true,
					),
					'cherry-ui-elements' => array(
						'autoload' => false,
					),
					'cherry-interface-builder' => array(
						'autoload' => false,
					),
					'cherry-utility' => array(
						'autoload' => true,
						'args'     => array(
							'meta_key' => array(
								'term_thumb' => 'cherry_terms_thumbnails',
							),
						),
					),
					'cherry-widget-factory' => array(
						'autoload' => true,
					),
					'cherry-post-formats-api' => array(
						'autoload' => true,
						'args'     => array(
							'rewrite_default_gallery' => true,
							'gallery_args' => array(
								'size'          => 'latify-thumb-l',
								'base_class'    => 'post-gallery',
								'container'     => '<div class="%2$s swiper-container" id="%4$s" %3$s><div class="swiper-wrapper">%1$s</div><div class="swiper-button-prev"><i class="linearicon linearicon-chevron-left"></i></div><div class="swiper-button-next"><i class="linearicon linearicon-chevron-right"></i></div><div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets"></div></div>',
								'slide'         => '<figure class="%2$s swiper-slide">%1$s</figure>',
								'img_class'     => 'swiper-image',
								'slider_handle' => 'jquery-swiper',
								'slider'        => 'swiper',
								'popup'         => 'magnificPopup',
								'popup_handle'  => 'magnific-popup',
								'popup_init'    => array(
									'type' => 'image',
								),
							),
							'image_args' => array(
								'size'         => 'latify-thumb-l',
								'popup'        => 'magnificPopup',
								'popup_handle' => 'magnific-popup',
								'popup_init'   => array(
									'type' => 'image',
								),
							),
						),
					),
					'cherry-customizer' => array(
						'autoload' => false,
					),
					'cherry-dynamic-css' => array(
						'autoload' => false,
					),
					'cherry-google-fonts-loader' => array(
						'autoload' => false,
					),
					'cherry-term-meta' => array(
						'autoload' => false,
					),
					'cherry-post-meta' => array(
						'autoload' => false,
					),
					'cherry-breadcrumbs' => array(
						'autoload' => false,
					),
				),
			) );

			return $this->core;
		}

		/**
		 * Loads the theme translation file.
		 *
		 * @since 1.0.0
		 */
		public function l10n() {
			/*
			 * Make theme available for translation.
			 * Translations can be filed in the /languages/ directory.
			 */
			load_theme_textdomain( 'latify', trailingslashit( LATIFY_THEME_DIR ) . 'languages' );
		}

		/**
		 * Adds theme supported features.
		 *
		 * @since 1.0.0
		 */
		public function theme_support() {

			// Enable support for Post Thumbnails on posts and pages.
			add_theme_support( 'post-thumbnails' );

			// Enable HTML5 markup structure.
			add_theme_support( 'html5', array(
				'comment-list',
				'comment-form',
				'search-form',
				'gallery',
				'caption',
			) );

			// Enable default title tag.
			add_theme_support( 'title-tag' );

			// Enable post formats.
			add_theme_support( 'post-formats', array(
				'aside',
				'gallery',
				'image',
				'link',
				'quote',
				'video',
				'audio',
				'status',
			) );

			// Enable custom background.
			add_theme_support( 'custom-background', array( 'default-color' => 'ffffff' ) );

			// Add default posts and comments RSS feed links to head.
			add_theme_support( 'automatic-feed-links' );

			// Add support for mobile menu
			add_theme_support( 'tm-custom-mobile-menu' );
		}

		/**
		 * Loads the theme files supported by themes and template-related functions/classes.
		 *
		 * @since 1.0.0
		 */
		public function includes() {
			/**
			 * Configurations.
			 */
			require_once trailingslashit( LATIFY_THEME_DIR ) . 'config/layout.php';
			require_once trailingslashit( LATIFY_THEME_DIR ) . 'config/menus.php';
			require_once trailingslashit( LATIFY_THEME_DIR ) . 'config/sidebars.php';
			require_if_theme_supports( 'post-thumbnails', trailingslashit( LATIFY_THEME_DIR ) . 'config/thumbnails.php' );

			/**
			 * Functions.
			 */
			if ( ! is_admin() ) {
				require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/template-tags.php';
				require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/template-menu.php';
				require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/template-meta.php';
				require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/template-comment.php';
				require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/template-related-posts.php';
			}

			require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/extras.php';
			require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/context.php';
			require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/customizer.php';
			require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/hooks.php';
			require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/register-plugins.php';


			if ( class_exists( 'Cherry_Projects' ) ) {
				require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/plugins-hooks/cherry-projects.php';
			}

			if ( class_exists( 'Cherry_Services_List' ) ) {
				require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/plugins-hooks/cherry-services-list.php';
			}

			if ( class_exists( 'TM_Testimonials_Plugin' ) ) {
				require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/plugins-hooks/cherry-testi.php';
			}

			if ( class_exists( 'Tm_Builder_Plugin' ) ) {
				require_once trailingslashit( LATIFY_THEME_DIR ) . 'inc/plugins-hooks/power-builder.php';
			}



			/**
			 * Widgets.
			 */
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'about/class-about-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'about-author/class-about-author-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'banner/class-banner-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'carousel/class-carousel-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'custom-posts/class-custom-posts-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'image-grid/class-image-grid-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'instagram/class-instagram-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'smart-slider/class-smart-slider-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'subscribe-follow/class-subscribe-follow-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'taxonomy-tiles/class-taxonomy-tiles-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'featured-posts-block/class-featured-posts-block-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'news-smart-box/class-news-smart-box-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'playlist-slider/class-playlist-slider-widget.php';
			require_once trailingslashit( LATIFY_THEME_WIDGETS ) . 'contact-information/class-contact-information-widget.php';

			/**
			 * Classes.
			 */
			if ( ! is_admin() ) {
				require_once trailingslashit( LATIFY_THEME_CLASSES ) . 'class-wrapping.php';
			}

			require_once trailingslashit( LATIFY_THEME_CLASSES ) . 'class-widget-area.php';
			require_once trailingslashit( LATIFY_THEME_CLASSES ) . 'class-tgm-plugin-activation.php';

			/**
			 * Extensions.
			 */
			require_once trailingslashit( LATIFY_THEME_EXT ) . 'woocommerce.php';
			require_once trailingslashit( LATIFY_THEME_EXT ) . 'latify-mega-menu.php';
			require_once trailingslashit( LATIFY_THEME_EXT ) . 'import.php';
		}

		/**
		 * Run initialization of modules.
		 *
		 * @since 1.0.0
		 */
		public function init() {
			$this->customizer  = $this->get_core()->init_module( 'cherry-customizer', latify_get_customizer_options() );
			$this->dynamic_css = $this->get_core()->init_module( 'cherry-dynamic-css', latify_get_dynamic_css_options() );
			$this->get_core()->init_module( 'cherry-google-fonts-loader', latify_get_fonts_options() );
			$this->get_core()->init_module( 'cherry-term-meta', array(
				'tax'      => 'category',
				'priority' => 10,
				'fields'   => array(
					'cherry_terms_thumbnails' => array(
						'type'                => 'media',
						'value'               => '',
						'multi_upload'        => false,
						'library_type'        => 'image',
						'upload_button_text'  => esc_html__( 'Set thumbnail', 'latify' ),
						'label'               => esc_html__( 'Category thumbnail', 'latify' ),
					),
				),
			) );
			$this->get_core()->init_module( 'cherry-term-meta', array(
				'tax'      => 'post_tag',
				'priority' => 10,
				'fields'   => array(
					'cherry_terms_thumbnails' => array(
						'type'                => 'media',
						'value'               => '',
						'multi_upload'        => false,
						'library_type'        => 'image',
						'upload_button_text'  => esc_html__( 'Set thumbnail', 'latify' ),
						'label'               => esc_html__( 'Tag thumbnail', 'latify' ),
					),
				),
			) );
			$this->get_core()->init_module( 'cherry-post-meta', apply_filters( 'latify_page_settings_meta',  array(
				'id'            => 'page-settings',
				'title'         => esc_html__( 'Page settings', 'latify' ),
				'page'          => array( 'post', 'page' ),
				'context'       => 'normal',
				'priority'      => 'high',
				'callback_args' => false,
				'fields'        => array(
					'tabs' => array(
						'element' => 'component',
						'type'    => 'component-tab-horizontal',
					),
					'layout_tab' => array(
						'element'     => 'settings',
						'parent'      => 'tabs',
						'title'       => esc_html__( 'Layout Options', 'latify' ),
					),
					'header_tab' => array(
						'element'     => 'settings',
						'parent'      => 'tabs',
						'title'       => esc_html__( 'Header Style', 'latify' ),
						'description' => esc_html__( 'Header style settings', 'latify' ),
					),
					'header_elements_tab' => array(
						'element'     => 'settings',
						'parent'      => 'tabs',
						'title'       => esc_html__( 'Header Elements', 'latify' ),
						'description' => esc_html__( 'Enable/Disable header elements', 'latify' ),
					),
					'breadcrumbs_tab' => array(
						'element'     => 'settings',
						'parent'      => 'tabs',
						'title'       => esc_html__( 'Breadcrumbs', 'latify' ),
						'description' => esc_html__( 'Breadcrumbs settings', 'latify' ),
					),
					'footer_tab' => array(
						'element'     => 'settings',
						'parent'      => 'tabs',
						'title'       => esc_html__( 'Footer Settings', 'latify' ),
						'description' => esc_html__( 'Footer settings', 'latify' ),
					),
					'latify_sidebar_position' => array(
						'type'          => 'radio',
						'parent'        => 'layout_tab',
						'title'         => esc_html__( 'Sidebar Layout', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options'       => array(
							'inherit' => array(
								'label'   => esc_html__( 'Inherit', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/inherit.svg',
							),
							'one-left-sidebar' => array(
								'label'   => esc_html__( 'Sidebar on left side', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/page-layout-left-sidebar.svg',
							),
							'one-right-sidebar' => array(
								'label'   => esc_html__( 'Sidebar on right side', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/page-layout-right-sidebar.svg',
							),
							'fullwidth' => array(
								'label'   => esc_html__( 'No sidebar', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/page-layout-fullwidth.svg',
							),
						),
					),
					'latify_header_container_type' => array(
						'type'          => 'radio',
						'parent'        => 'layout_tab',
						'title'         => esc_html__( 'Header layout', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options'       => array(
							'inherit'   => array(
								'label'   => esc_html__( 'Inherit', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/inherit.svg',
							),
							'boxed'     => array(
								'label'   => esc_html__( 'Boxed', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/type-boxed.svg',
							),
							'fullwidth' => array(
								'label'   => esc_html__( 'Fullwidth', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/type-fullwidth.svg',
							),
						),
					),
					'latify_content_container_type' => array(
						'type'          => 'radio',
						'parent'        => 'layout_tab',
						'title'         => esc_html__( 'Content layout', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options'       => array(
							'inherit'   => array(
								'label'   => esc_html__( 'Inherit', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/inherit.svg',
							),
							'boxed'     => array(
								'label'   => esc_html__( 'Boxed', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/type-boxed.svg',
							),
							'fullwidth' => array(
								'label'   => esc_html__( 'Fullwidth', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/type-fullwidth.svg',
							),
						),
					),
					'latify_footer_container_type'  => array(
						'type'          => 'radio',
						'parent'        => 'layout_tab',
						'title'         => esc_html__( 'Footer layout', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options'       => array(
							'inherit'   => array(
								'label'   => esc_html__( 'Inherit', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/inherit.svg',
							),
							'boxed'     => array(
								'label'   => esc_html__( 'Boxed', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/type-boxed.svg',
							),
							'fullwidth' => array(
								'label'   => esc_html__( 'Fullwidth', 'latify' ),
								'img_src' => trailingslashit( LATIFY_THEME_URI ) . 'assets/images/admin/type-fullwidth.svg',
							),
						),
					),
					'latify_header_layout_type' => array(
						'type'    => 'select',
						'parent'  => 'header_tab',
						'title'   => esc_html__( 'Header Layout', 'latify' ),
						'value'   => 'inherit',
						'options' => latify_get_header_layout_pm_options(),
					),
					'latify_header_transparent_layout' => array(
						'type'          => 'radio',
						'parent'        => 'header_tab',
						'title'         => esc_html__( 'Header Overlay', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options' => array(
							'inherit' => array(
								'label' => esc_html__( 'Inherit', 'latify' ),
							),
							'true'    => array(
								'label' => esc_html__( 'Enable', 'latify' ),
							),
							'false'   => array(
								'label' => esc_html__( 'Disable', 'latify' ),
							),
						),
					),
					'latify_header_invert_color_scheme' => array(
						'type'          => 'radio',
						'parent'        => 'header_tab',
						'title'         => esc_html__( 'Invert Color scheme', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options' => array(
							'inherit' => array(
								'label' => esc_html__( 'Inherit', 'latify' ),
							),
							'true'    => array(
								'label' => esc_html__( 'Enable', 'latify' ),
							),
							'false'   => array(
								'label' => esc_html__( 'Disable', 'latify' ),
							),
						),
					),
					'latify_top_panel_visibility' => array(
						'type'          => 'select',
						'parent'        => 'header_elements_tab',
						'title'         => esc_html__( 'Top panel', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options' => array(
							'inherit' => esc_html__( 'Inherit', 'latify' ),
							'true'    => esc_html__( 'Enable', 'latify' ),
							'false'   => esc_html__( 'Disable', 'latify' ),
						),
					),
					'latify_header_contact_block_visibility' => array(
						'type'          => 'select',
						'parent'        => 'header_elements_tab',
						'title'         => esc_html__( 'Header Contact Block', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options' => array(
							'inherit' => esc_html__( 'Inherit', 'latify' ),
							'true'    => esc_html__( 'Enable', 'latify' ),
							'false'   => esc_html__( 'Disable', 'latify' ),
						),
					),
					'latify_header_search' => array(
						'type'          => 'select',
						'parent'        => 'header_elements_tab',
						'title'         => esc_html__( 'Header Search', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options' => array(
							'inherit' => esc_html__( 'Inherit', 'latify' ),
							'true'    => esc_html__( 'Enable', 'latify' ),
							'false'   => esc_html__( 'Disable', 'latify' ),
						),
					),
					'latify_header_btn_visibility' => array(
						'type'          => 'select',
						'parent'        => 'header_elements_tab',
						'title'         => esc_html__( 'Header CTA button', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options' => array(
							'inherit' => esc_html__( 'Inherit', 'latify' ),
							'true'    => esc_html__( 'Enable', 'latify' ),
							'false'   => esc_html__( 'Disable', 'latify' ),
						),
					),
					'latify_breadcrumbs_visibillity' => array(
						'type'          => 'radio',
						'parent'        => 'breadcrumbs_tab',
						'title'         => esc_html__( 'Breadcrumbs visibillity', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options' => array(
							'inherit' => array(
								'label' => esc_html__( 'Inherit', 'latify' ),
							),
							'true'    => array(
								'label' => esc_html__( 'Enable', 'latify' ),
							),
							'false'   => array(
								'label' => esc_html__( 'Disable', 'latify' ),
							),
						),
					),
					'latify_footer_layout_type' => array(
						'type'    => 'select',
						'parent'  => 'footer_tab',
						'title'   => esc_html__( 'Footer Layout', 'latify' ),
						'value'   => 'inherit',
						'options' => latify_get_footer_layout_pm_options(),
					),
					'latify_footer_widget_area_visibility' => array(
						'type'          => 'select',
						'parent'        => 'footer_tab',
						'title'         => esc_html__( 'Footer Widgets Area', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options' => array(
							'inherit' => esc_html__( 'Inherit', 'latify' ),
							'true'    => esc_html__( 'Enable', 'latify' ),
							'false'   => esc_html__( 'Disable', 'latify' ),
						),
					),
					'latify_footer_contact_block_visibility' => array(
						'type'          => 'select',
						'parent'        => 'footer_tab',
						'title'         => esc_html__( 'Footer Contact Block', 'latify' ),
						'value'         => 'inherit',
						'display_input' => false,
						'options' => array(
							'inherit' => esc_html__( 'Inherit', 'latify' ),
							'true'    => esc_html__( 'Enable', 'latify' ),
							'false'   => esc_html__( 'Disable', 'latify' ),
						),
					),
				),
			) ) );
			$this->get_core()->init_module( 'cherry-post-meta', array(
				'id'            => 'post-single-type',
				'title'         => esc_html__( 'Single Post Style', 'latify' ),
				'page'          => array( 'post' ),
				'context'       => 'side',
				'priority'      => 'low',
				'callback_args' => false,
				'fields' => array(
					'latify_single_post_type' => array(
						'type'          => 'radio',
						'value'         => 'inherit',
						'display_input' => false,
						'options'       => array(
							'inherit' => array(
								'label' => esc_html__( 'Inherit', 'latify' ),
							),
							'default' => array(
								'label' => esc_html__( 'Default', 'latify' ),
							),
							'modern'  => array(
								'label' => esc_html__( 'Modern', 'latify' ),
							),
						),
					),
				),
			) );
		}

		/**
		 * Load admin files for the theme.
		 *
		 * @since 1.0.0
		 */
		public function admin() {

			// Check if in the WordPress admin.
			if ( ! is_admin() ) {
				return;
			}
		}

		/**
		 * Enqueue admin-specific assets.
		 *
		 * @since 1.0.0
		 */
		public function enqueue_admin_assets( $hook ) {
			// FIX admin style to `The Events Calendar` plugin
			if ( class_exists( 'Tribe__Events__Main' ) ) {
				wp_enqueue_style( 'latify-admin-fix-style', LATIFY_THEME_CSS . '/admin-fix.min.css', array(), LATIFY_THEME_VERSION );
			}

			$available_pages = array(
				'widgets.php',
			);

			if ( ! in_array( $hook, $available_pages ) ) {
				return;
			}

			wp_enqueue_style( 'latify-admin-style', LATIFY_THEME_CSS . '/admin.min.css', array(), LATIFY_THEME_VERSION );
		}

		/**
		 * Register assets.
		 *
		 * @since 1.0.0
		 */
		public function register_assets() {
			wp_register_script( 'jquery-slider-pro', LATIFY_THEME_JS . '/min/jquery.slider-pro.min.js', array( 'jquery' ), '1.2.4', true );
			wp_register_script( 'jquery-swiper', LATIFY_THEME_JS . '/min/swiper.jquery.min.js', array( 'jquery' ), '3.3.0', true );
			wp_register_script( 'magnific-popup', LATIFY_THEME_JS . '/min/jquery.magnific-popup.min.js', array( 'jquery' ), '1.1.0', true );
			wp_register_script( 'object-fit-images', LATIFY_THEME_JS . '/min/ofi.min.js', array(), '3.0.1', true );

			wp_register_style( 'jquery-slider-pro', LATIFY_THEME_CSS . '/slider-pro.min.css', array(), '1.2.4' );
			wp_register_style( 'jquery-swiper', LATIFY_THEME_CSS . '/swiper.min.css', array(), '3.3.0' );
			wp_register_style( 'magnific-popup', LATIFY_THEME_CSS . '/magnific-popup.min.css', array(), '1.1.0' );
			wp_register_style( 'font-awesome', LATIFY_THEME_CSS . '/font-awesome.min.css', array(), '4.6.3' );
			wp_register_style( 'material-icons', LATIFY_THEME_CSS . '/material-icons.min.css', array(), '2.2.0' );
			wp_register_style( 'linear-icons', LATIFY_THEME_CSS . '/linearicons.css', array(), '1.0.0' );

			wp_dequeue_script( 'booked-font-awesome' );
			wp_dequeue_script( 'timeline-fontawesome-css' );
			wp_dequeue_script( 'bootstrap-grid' );
		}

		/**
		 * Enqueue assets.
		 *
		 * @since 1.0.0
		 */
		public function enqueue_assets() {
			wp_enqueue_style( 'latify-theme-style', get_stylesheet_uri(),
				array( 'font-awesome', 'material-icons', 'magnific-popup', 'linear-icons' ),
				LATIFY_THEME_VERSION
			);

			if ( is_404() ) {
				wp_add_inline_style( 'latify-theme-style', latify_404_inline_css() );
			}

			/**
			 * Filter the depends on main theme script.
			 *
			 * @since 1.0.0
			 * @var   array
			 */
			$depends = apply_filters( 'latify_theme_script_depends', array( 'cherry-js-core', 'hoverIntent' ) );

			wp_enqueue_script( 'latify-theme-script', LATIFY_THEME_JS . '/theme-script.js', $depends, LATIFY_THEME_VERSION, true );

			/**
			 * Filter the strings that send to scripts.
			 *
			 * @since 1.0.0
			 * @var   array
			 */
			$labels = apply_filters( 'latify_theme_localize_labels', array(
				'totop_button'  => '',
				'header_layout' => get_theme_mod( 'header_layout_type', latify_theme()->customizer->get_default( 'header_layout_type' ) ),
			) );

			$more_button_options = apply_filters( 'latify_theme_more_button_options', array(
				'more_button_type'             => get_theme_mod( 'more_button_type', latify_theme()->customizer->get_default( 'more_button_type' ) ),
				'more_button_text'             => get_theme_mod( 'more_button_text', latify_theme()->customizer->get_default( 'more_button_text' ) ),
				'more_button_icon'             => get_theme_mod( 'more_button_icon', latify_theme()->customizer->get_default( 'more_button_icon' ) ),
				'more_button_image_url'        => get_theme_mod( 'more_button_image_url', latify_theme()->customizer->get_default( 'more_button_image_url' ) ),
				'retina_more_button_image_url' => get_theme_mod( 'retina_more_button_image_url', latify_theme()->customizer->get_default( 'retina_more_button_image_url' ) ),
			) );

			wp_localize_script( 'latify-theme-script', 'latify', apply_filters(
				'latify_theme_script_variables',
				array(
					'ajaxurl'             => esc_url( admin_url( 'admin-ajax.php' ) ),
					'labels'              => $labels,
					'more_button_options' => $more_button_options,
				) ) );

			// Threaded Comments.
			if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
				wp_enqueue_script( 'comment-reply' );
			}
		}



		/**
		 * Overrides the load textdomain functionality when 'cherry-framework' is the domain in use.
		 *
		 * @since  1.0.0
		 * @link   https://gist.github.com/justintadlock/7a605c29ae26c80878d0
		 *
		 * @param  bool   $override
		 * @param  string $domain
		 * @param  string $mofile
		 *
		 * @return bool
		 */
		public function override_load_textdomain( $override, $domain, $mofile ) {

			// Check if the domain is our framework domain.
			if ( 'cherry-framework' === $domain ) {

				global $l10n;

				// If the theme's textdomain is loaded, assign the theme's translations
				// to the framework's textdomain.
				if ( isset( $l10n['latify'] ) ) {
					$l10n[ $domain ] = $l10n['latify'];
				}

				// Always override.  We only want the theme to handle translations.
				$override = true;
			}

			return $override;
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

/**
 * Returns instanse of main theme configuration class.
 *
 * @since  1.0.0
 * @return object
 */
function latify_theme() {
	return latify_Theme_Setup::get_instance();
}

latify_theme();


add_action('wp_ajax_getCouponDetails', 'getCouponDetails');
add_action('wp_ajax_nopriv_getCouponDetails', 'getCouponDetails');

function getCouponDetails()
{  
	include(get_template_directory().'/loyalityLane/functions.php');

	if($_POST['availableORclipped'] == 'Available'){
		 $url = BASE_URL.'/Coupon';   
	}else{
		$url = BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'];
	}		 
	$header = array(
		"ClientToken : ".CLIENT_TOKEN,
	 );
	$curl = curl_init(); 
	$curlArray = array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_HTTPHEADER => $header,
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
  
	curl_close($curl);
	
	$jsonData = json_decode($response);
	
	$newData = $jsonData->data->coupons;
	
	foreach($newData as $key => $value) {
		if($value->id == $_POST['coupon_id']) {
			$encodedData = json_encode($value);
			wp_send_json(json_decode($encodedData));
		}
	}
	
}

add_action('wp_ajax_getCategoryByCoupons', 'getCategoryByCoupons');
add_action('wp_ajax_nopriv_getCategoryByCoupons', 'getCategoryByCoupons');
 
function getCategoryByCoupons()
{  
	include(get_template_directory().'/loyalityLane/functions.php');


	if(empty($_SESSION['accountid'])){
	    $url = BASE_URL.'/Coupon';
	}
	else{
		$url = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];
	} 
	
	$header = array(
		"ClientToken : ".CLIENT_TOKEN,
	 );
	$curl = curl_init(); 
	$curlArray = array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_HTTPHEADER => $header,
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
  
	curl_close($curl);
	$jsonData = json_decode($response);
	$newData = $jsonData->data->coupons;
	$count_category=0;
    $count_brand=0;
	$responseData = [];
	$totalAvailableSaving = 0;
	$output = "";
	$output .= '<div class="row">';
	foreach($newData as $key => $value) {

		if($value->CategoryName == $_POST['searchByOption']) {
			preg_match('/\$([0-9]+[\.,0-9]*)/', $value->OfferSummaryTop, $match);
             $totalAvailableSaving += $match[1];
			$count_category++;
		 $output .= '<div class="col-md-6 col-lg-4 col-xl-4 cat'.$value->CategoryName.' dataHide">
                     <div class="couponsItems">
                        <div class="proImg">
                           <img src="'.$value->ImageUrl.'" class="customcouponimgheight img-fluid" style="width: auto; max-height: 100%; max-width: 100%;">
                        </div>
                        <div class="proDetails">
                           <h3>'.substr($value->OfferSummaryTop,0,11).'</h3>
                           <p>'.substr($value->OfferShortDesc,0,70).'".."</p>';
						   $timestamp = strtotime($value->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);

                                 if($diff->format("%a")<7){
			$output .= '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }
			$output .= ' </div>
                     </div>
                     <div class="CoupAction">
                        <div class="ActionBtn">
                          <a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-available-id="Available" data-coupon-id="'.$value->id.'" class="coupDetails"  id="coupon_details">Details</a>';
						 
                           if(empty($_SESSION['ShopperToken'])){	
         $output .='<a href="/login" class="coupSinup">Sign in To Clip </a>';
						   }else{ 
                           if($_GET['type']=="Clipped") {
                              echo "";
                           } else {  
		 // $output .= '<a href="'.site_url().'/coupon?couponId='.$value->id.'" class="coupSinup">Clip Coupon</a>';
		 $output .= '<a id="clipCoupon" href="javascript:void(0);" data-coupons-id="'.$value->id.'" class="coupSinup">Clip Coupon</a>';
                           } } 		
		 $output .= '</div>
                        <div class="ShareFB loginBtn--facebook">
                           <a href="">Share on Facebook</a>
                        </div>
                     </div>';
		 $output .= '</div>';
				}
		elseif($value->Brand == $_POST['searchByOption']){
					$count_category++;
					preg_match('/\$([0-9]+[\.,0-9]*)/', $value->OfferSummaryTop, $match);
                      $totalAvailableSaving += $match[1];
		 $output .= '<div class="col-md-6 col-lg-4 col-xl-4 cat'.$value->CategoryName.' dataHide">
                     <div class="couponsItems">
                        <div class="proImg">
                           <img src="'.$value->ImageUrl.'" class="customcouponimgheight img-fluid" style="width: auto; max-height: 100%; max-width: 100%;">
                        </div>
                        <div class="proDetails">
                           <h3>'.substr($value->OfferSummaryTop,0,11).'</h3>
                           <p>'.substr($value->OfferShortDesc,0,70).'".."</p>';
						   $timestamp = strtotime($value->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);

                                 if($diff->format("%a")<7){
			$output .= '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }
			$output .= ' </div>
                     </div>
                     <div class="CoupAction">
                        <div class="ActionBtn">
                          <a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-available-id="Available" data-coupon-id="'.$value->id.'" class="coupDetails"  id="coupon_details">Details</a>';
                           if(empty($_SESSION['ShopperToken'])){	
         $output .='<a href="'.site_url().'/login" class="coupSinup">Sign in To Clip </a>';
						   }else{ 
                           if($_GET['type']=="Clipped") {
                              echo "";
                           } else {  
		 //$output .= '<a href="'.site_url().'/coupon?couponId='.$value->id.'" class="coupSinup">Clip Coupon</a>';
		 $output .= '<a id="clipCoupon" href="javascript:void(0);" data-coupons-id="'.$value->id.'" class="coupSinup">Clip Coupon</a>';
                           } } 		
		 $output .= '</div>
                        <div class="ShareFB loginBtn--facebook">
                           <a href="">Share on Facebook</a>
                        </div>
                     </div>';
		 $output .= '</div>';
				}
				elseif($_POST['searchByOption']==""){
					$count_category++;
					preg_match('/\$([0-9]+[\.,0-9]*)/', $value->OfferSummaryTop, $match);
                    $totalAvailableSaving += $match[1];
					$output .= '<div class="col-md-6 col-lg-4 col-xl-4 cat'.$value->CategoryName.' dataHide">
								<div class="couponsItems">
								   <div class="proImg">
									  <img src="'.$value->ImageUrl.'" class="customcouponimgheight img-fluid" style="width: auto; max-height: 100%; max-width: 100%;">
								   </div>
								   <div class="proDetails">
									  <h3>'.substr($value->OfferSummaryTop,0,11).'</h3>
									  <p>'.substr($value->OfferShortDesc,0,70).'".."</p>';
									  $timestamp = strtotime($value->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);

                                 if($diff->format("%a")<7){
			$output .= '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }
			$output .= ' </div>
								</div>
								<div class="CoupAction">
								   <div class="ActionBtn">
									 <a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-available-id="Available" data-coupon-id="'.$value->id.'" class="coupDetails"  id="coupon_details">Details</a>';
									  if(empty($_SESSION['ShopperToken'])){	
					$output .='<a href="'.site_url().'/login" class="coupSinup">Sign in To Clip </a>';
									  }else{ 
									  if($_GET['type']=="Clipped") {
										 echo "";
									  } else {  
					//$output .= '<a href="'.site_url().'/coupon?couponId='.$value->id.'" class="coupSinup">Clip Coupon</a>';
					$output .= '<a id="clipCoupon" href="javascript:void(0);" data-coupons-id="'.$value->id.'" class="coupSinup">Clip Coupon</a>';
									  } } 		
					$output .= '</div>
								   <div class="ShareFB loginBtn--facebook">
									  <a href="">Share on Facebook</a>
								   </div>
								</div>';
					$output .= '</div>';
				}
			}
		 $output .= '<div>';
		 $responseData['output'] = $output;
		 $responseData['Availablecount'] = $count_category;
		 if(array_key_exists('accountid',$_SESSION)) {
		   $responseData['ClippedCount'] = $_SESSION['countClipped'];
		 }
		 $responseData['AvailableSaving'] =  number_format($totalAvailableSaving, 2);
	     wp_send_json($responseData);
}

add_action('wp_ajax_getClippedCoupons', 'getClippedCoupons');
add_action('wp_ajax_nopriv_getClippedCoupons', 'getClippedCoupons');

function getClippedCoupons()
{  
	include(get_template_directory().'/loyalityLane/functions.php');
	$url = BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'];

	$header = array(
		"ClientToken : ".CLIENT_TOKEN,
	 );
	$curl = curl_init(); 
	$curlArray = array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_HTTPHEADER => $header,
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
  
	curl_close($curl);
	$jsonData = json_decode($response);
	$newData = $jsonData->data->coupons;
	$count_category=0;
	$count_brand=0;
	$totalClippedSaving = 0;
	$responseData = [];
	$output = "";
	$output .= '<div class="row">';
	foreach($newData as $key => $value) {
			$count_category++;
			
            preg_match('/\$([0-9]+[\.,0-9]*)/', $value->OfferSummaryTop, $match);
			$totalClippedSaving += $match[1];
			
			$output .= '<div class="col-md-6 col-lg-4 col-xl-4 cat'.$value->CategoryName.' dataHide">
				<div class="couponsItems">
				<div class="proImg">
					<img src="'.$value->ImageUrl.'" class="customcouponimgheight img-fluid" style="width: auto; max-height: 100%; max-width: 100%;">
				</div>
				<div class="proDetails">
					<h3>'.substr($value->OfferSummaryTop,0,11).'</h3>
					<p>'.substr($value->OfferShortDesc,0,70).'".."</p>';

					$timestamp = strtotime($value->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);

                                 if($diff->format("%a")<7){
			$output .= '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }
			$output .= '</div>
				</div>
				<div class="CoupAction">
				<div class="ActionBtn">
					<a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-coupons="Clipped" data-coupon-id="'.$value->id.'" class="coupDetails"  id="coupon_details">Details</a>
					
					<a href="javascript:void(0)" style="cursor: not-allowed;" class="coupSinup">Clipped</a>';
					if(empty($_SESSION['ShopperToken'])){	
			$output .='<a href="'.site_url().'/login" class="coupSinup">Sign in To Clip </a>';
			$output .= '<a href="javascript:void(0)" class="coupSinup">Clipped</a>';
					} 		
			$output .= '</div>
				<div class="ShareFB loginBtn--facebook">
				<a fb-data-URL="'.$current_url.'" fb-data-image="'.$data->ImageUrl.'" fb-data-title="'.$data->OfferShortDesc.'" href="javascript:void(0);" class="ShareFB">Share on Facebook</a>
				</div>
				</div>';
			$output .= '</div>';
		 }	
		 $output .= '</div>';
		$responseData['output'] = $output;
		$responseData['Availablecount'] = $count_category;
		$responseData['ClippedCount'] = $count_category;
		$responseData['ClippedSaving'] =  number_format($totalClippedSaving, 2);
	    wp_send_json($responseData);
}	

add_action('wp_ajax_getMyclubData', 'getMyclubData');
add_action('wp_ajax_nopriv_getMyclubData', 'getMyclubData');

function getMyclubData()
{  
	// echo "fdsafdsa";

	include(get_template_directory().'/loyalityLane/functions.php');

	$url = BASE_URL.'/Balance';

	$header = array(
		'ClientToken: '.CLIENT_TOKEN,
		 'ShopperToken: '.$_SESSION['ShopperToken'],
		 'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000b0210ac00005000'
	 );

	 $curl = curl_init();

	 $curlArray = array(
	   CURLOPT_URL => $url,
	   CURLOPT_RETURNTRANSFER => true,
	   CURLOPT_ENCODING => '',
	   CURLOPT_MAXREDIRS => 10,
	   CURLOPT_TIMEOUT => 0,
	   CURLOPT_FOLLOWLOCATION => true,
	   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	   CURLOPT_CUSTOMREQUEST => 'GET',
	   CURLOPT_HTTPHEADER => $header,
	 );

	 curl_setopt_array($curl, $curlArray );
	 $response = curl_exec($curl);
	 
	 curl_close($curl);
	 $jsonData = json_decode($response);
	 $output = "";
	 
	 $newData = $jsonData->data->offer_balances;
	//  print_r($newData);
	
	 $output .= '<div class="row">
	 <div class="col-md-12">
	 <div class="box-panel">';
	 if($_POST['myclubData'] == 'myclub-count-mobile'){
	$output .= '<img src="'.get_template_directory_uri().'/templates/images/bread-milk-mobile.jpg" height="auto" width="100%"/>';
	 }else{
	$output .= '<img src="'.get_template_directory_uri().'/templates/images/bread-milk.jpg" height="auto" width="100%"/>';
	 }
	 $output .= '</div></div>';
		foreach($newData as $key => $offer){
			// print_r($offer);
		  if($offer->IsSpend == false){

	 $output .= '<div class="col-md-12">
	              
				   <div class="box-panel">
				   '.$offer->Name.'
                     <div class="color-box-panel">';

					 (int)$balance = $offer->Balance;
					 (int)$target = $offer->Target;
					 $backToGo = $target-$balance;
                     $blank=0;
                     for($i=0;$i<$target;$i++){
					   
						if($i<$balance){
						  $clolor = 'red_box';
						}else{
						  $clolor = 'gry_box';
						}

	    $output .= '<div class="colorboxmain '.$clolor.'"></div>';
                      }  
                       
			$output .= '</div>
                     <div class="mt-2 text-center">
                       <h6>Just '.$backToGo.' to go!</6>
                     </div>
					 <div class="mt-3 box_content rewards_message">';
					 if($offer->MaxUsage<0){
	$output .= '<p>This offer can be redeemed an unlimited number of times while offer exists.</p>';
					 }else{
	$output .= '<p>You have completed this offer '.$offer->NumTimesOfferUsed.' times you may complete this offer a total of '.$offer->MaxUsage.' time.</p>';
					 }
	$output .= '</div>
                     <div class="mt-3  box_content">
                       <p><strong>Offer end '.date("m-d-Y",strtotime($offer->ExpireDate)).' </strong> <span><!-- (116 days remaining) --></span> </p>
                   </div>
                   
                     </div>
                  </div>';
			}else{ 

	$output .= '<div class="box-panel ">
                        <div class="barPanel">
                        <div class="mt-2 mb-3">
                       <h6>Spend $27 for a free Broom!</6>
                     </div>
                        <div class="progress">
                              <div class="progress-bar" role="progressbar" style=" width: 60%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                              <div class="bar-caption">
                                 <h4>$4582</h4>
                                 <p>RewardId</p>
                              </div>
                              </div>
                              <small>You have completed this offer 3 times, you may complete this offer a total of 5 times.</small>
                        </div>
                        <div class="mt-3  box_content">
                       <p><strong>Offer end Oct 10, 2020</strong> <span>(116 days remaining)</span> </p>
                     </div>
                     </div>                  
                  </div>';
		      }		  
		}

	$output .= '</div>';
	$myclubData['output'] = $output;
	wp_send_json($myclubData);
}	 

add_action('wp_ajax_getAvailableCoupons', 'getAvailableCoupons');
add_action('wp_ajax_nopriv_getAvailableCoupons', 'getAvailableCoupons');
 
function getAvailableCoupons()
{
	//print_r($_POST);
	include(get_template_directory().'/loyalityLane/functions.php');
	//$url = BASE_URL.'/Coupon'; 
	$url = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];
	$header = array(
		"ClientToken : ".CLIENT_TOKEN,
	 );
	$curl = curl_init(); 
	$curlArray = array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_HTTPHEADER => $header,
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
  
	curl_close($curl);
	$jsonData = json_decode($response);
	$newData = $jsonData->data->coupons;
	$count_category=0;
	$count_brand=0;
	$totalAvailableSaving = 0;
	$responseData = [];
	$output = "";

	$output .= '<div class="row">';
	foreach($newData as $key => $value) {
		if($_POST['category'] == '' && $_POST['brand'] == ''){
					$count_category++;
					preg_match('/\$([0-9]+[\.,0-9]*)/', $value->OfferSummaryTop, $match);
					$totalAvailableSaving += $match[1];
					$output .= '<div class="col-md-6 col-lg-4 col-xl-4 cat'.$value->CategoryName.' dataHide">
					<div class="couponsItems">
					<div class="proImg">
						<img src="'.$value->ImageUrl.'" class="customcouponimgheight img-fluid" style="width: auto; max-height: 100%; max-width: 100%;">
					</div>
					<div class="proDetails">
						<h3>'.substr($value->OfferSummaryTop,0,11).'</h3>
						<p>'.substr($value->OfferShortDesc,0,70).'".."</p>';
						$timestamp = strtotime($value->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);

                                 if($diff->format("%a")<7){
			$output .= '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }
		$output .= '</div>
					</div>
					<div class="CoupAction">
					<div class="ActionBtn">
						<a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-available-id="Available" data-coupon-id="'.$value->id.'" class="coupDetails"  id="coupon_details">Details</a>';
						if(empty($_SESSION['ShopperToken'])){	
						$output .='<a href="'.site_url().'/login" class="coupSinup">Sign in To Clip </a>';
										}else{ 
										if($_GET['type']=="Clipped") {
											echo "";
										} else {  
						$output .= '<a id="clipCoupon" href="javascript:void(0);" data-coupons-id="'.$value->id.'" class="coupSinup">Clip Coupon</a>';

										} } 		
						$output .= '</div>
									<div class="ShareFB loginBtn--facebook">
									<a fb-data-URL="'.$current_url.'" fb-data-image="'.$data->ImageUrl.'" fb-data-title="'.$data->OfferShortDesc.'" href="javascript:void(0);" class="ShareFB">Share on Facebook</a>
									</div>
									</div>';
						$output .= '</div>';
			  		
		}else if($_POST['category'] == '' && $value->Brand == $_POST['brand']){

            $count_category++;
					preg_match('/\$([0-9]+[\.,0-9]*)/', $value->OfferSummaryTop, $match);
					$totalAvailableSaving += $match[1];
					$output .= '<div class="col-md-6 col-lg-4 col-xl-4 cat'.$value->CategoryName.' dataHide">
					<div class="couponsItems">
					<div class="proImg">
						<img src="'.$value->ImageUrl.'" class="customcouponimgheight img-fluid">
					</div>
					<div class="proDetails">
						<h3>'.substr($value->OfferSummaryTop,0,11).'</h3>
						<p>'.substr($value->OfferShortDesc,0,70).'".."</p>';
						$timestamp = strtotime($value->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);

                                 if($diff->format("%a")<7){
			$output .= '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }

			$output .= '</div>
					</div>
					<div class="CoupAction">
					<div class="ActionBtn">
						<a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-coupon-id="'.$value->id.'" class="coupDetails"  id="coupon_details">Details</a>';
						if(empty($_SESSION['ShopperToken'])){	
						$output .='<a href="'.site_url().'/login" class="coupSinup">Sign in To Clip </a>';
										}else{ 
										if($_GET['type']=="Clipped") {
											echo "";
										} else {  
						$output .= '<a id="clipCoupon" href="javascript:void(0);" data-coupons-id="'.$value->id.'" class="coupSinup">Clip Coupon</a>';

										} } 		
						$output .= '</div>
									<div class="ShareFB loginBtn--facebook">
										<a href="">Share on Facebook</a>
									</div>
									</div>';
						$output .= '</div>';
		}else if($value->CategoryName == $_POST['category'] && $_POST['brand'] == ''){
			$count_category++;
			preg_match('/\$([0-9]+[\.,0-9]*)/', $value->OfferSummaryTop, $match);
			$totalAvailableSaving += $match[1];
			$output .= '<div class="col-md-6 col-lg-4 col-xl-4 cat'.$value->CategoryName.' dataHide">
			<div class="couponsItems">
			<div class="proImg">
				<img src="'.$value->ImageUrl.'" class="customcouponimgheight img-fluid">
			</div>
			<div class="proDetails">
				<h3>'.substr($value->OfferSummaryTop,0,11).'</h3>
				<p>'.substr($value->OfferShortDesc,0,70).'".."</p>';
				$timestamp = strtotime($value->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);

                                 if($diff->format("%a")<7){
			$output .= '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }
		$output .= '</div>
			</div>
			<div class="CoupAction">
			<div class="ActionBtn">
				<a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-coupon-id="'.$value->id.'" class="coupDetails"  id="coupon_details">Details</a>';
				if(empty($_SESSION['ShopperToken'])){	
				$output .='<a href="'.site_url().'/login" class="coupSinup">Sign in To Clip </a>';
								}else{ 
								if($_GET['type']=="Clipped") {
									echo "";
								} else {  
				$output .= '<a id="clipCoupon" href="javascript:void(0);" data-coupons-id="'.$value->id.'" class="coupSinup">Clip Coupon</a>';

								} } 		
				$output .= '</div>
							<div class="ShareFB loginBtn--facebook">
								<a href="">Share on Facebook</a>
							</div>
							</div>';
				$output .= '</div>';
		} else if($value->CategoryName == $_POST['category'] && $value->Brand == $_POST['brand']){
			$count_category++;
			preg_match('/\$([0-9]+[\.,0-9]*)/', $value->OfferSummaryTop, $match);
			$totalAvailableSaving += $match[1];
			$output .= '<div class="col-md-6 col-lg-4 col-xl-4 cat'.$value->CategoryName.' dataHide">
			<div class="couponsItems">
			<div class="proImg">
				<img src="'.$value->ImageUrl.'" class="customcouponimgheight img-fluid">
			</div>
			<div class="proDetails">
				<h3>'.substr($value->OfferSummaryTop,0,11).'</h3>
				<p>'.substr($value->OfferShortDesc,0,70).'".."</p>';
				$timestamp = strtotime($value->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);

                                 if($diff->format("%a")<7){
			$output .= '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }
		$output .= '</div>
			</div>
			<div class="CoupAction">
			<div class="ActionBtn">
				<a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-coupon-id="'.$value->id.'" class="coupDetails"  id="coupon_details">Details</a>';
				if(empty($_SESSION['ShopperToken'])){	
				$output .='<a href="'.site_url().'/login" class="coupSinup">Sign in To Clip </a>';
								}else{ 
								if($_GET['type']=="Clipped") {
									echo "";
								} else {  
				$output .= '<a id="clipCoupon" href="javascript:void(0);" data-coupons-id="'.$value->id.'" class="coupSinup">Clip Coupon</a>';

								} } 		
				$output .= '</div>
							<div class="ShareFB loginBtn--facebook">
								<a href="">Share on Facebook</a>
							</div>
							</div>';
				$output .= '</div>';
		 } 
				
		}
		 $output .= '<div>';
		 $responseData['output'] = $output;
		$responseData['Availablecount'] = $count_category;
		$responseData['AvailableSaving'] = number_format($totalAvailableSaving, 2);
		//$responseData['ClippedCount'] = $_SESSION['countClipped'];
	     wp_send_json($responseData);
}

add_action('wp_ajax_getMyReward', 'getMyReward');
add_action('wp_ajax_nopriv_getMyReward', 'getMyReward');

function getMyReward()
{
	include(get_template_directory().'/loyalityLane/functions.php');
	$output = "";

	$output .= '<div class="row"></div>';
	wp_send_json($output);
}

add_action('wp_ajax_getEditProfile', 'getEditProfile');
add_action('wp_ajax_nopriv_getEditProfile', 'getEditProfile');

function getEditProfile()
{

	include(get_template_directory().'/loyalityLane/functions.php');
	$url = BASE_URL.'/States';
	$curl = curl_init();
	$curlArray = array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_HTTPHEADER => array(
			'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000d0210ac00005000'
		),
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($response);
	$states = (object)$res->data->states;

	$urlHomeStore = BASE_URL.'/Store?showDisabled=true';
	$curl = curl_init();
	$curlArray = array(
		CURLOPT_URL => $urlHomeStore,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_HTTPHEADER => array(
		  'ClientToken: '.CLIENT_TOKEN,
		  'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000d0210ac00005000'
		),
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($response);
	$homestore = (object)$res->data->stores;

	$urlShopper = BASE_URL.'/Shopper?shopperid='.$_SESSION['shopperid'];
	$curl = curl_init();
	$curlArray = array(
		CURLOPT_URL => $urlShopper,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_POSTFIELDS => 'shopperid=22',
		CURLOPT_HTTPHEADER => array(
		  'ClientToken: '.CLIENT_TOKEN,
		  'ShopperToken: '.$_SESSION['ShopperToken'],
		  'Content-Type: application/x-www-form-urlencoded',
		  'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000d0210ac00005000'
		 ),
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($response);
	
	$useDetails = (object)$res->data->shopper;

	$urlAccount = BASE_URL.'/Account?accountid='.$_SESSION['accountid'];
	$curl = curl_init();
	$curlArray = array(
		CURLOPT_URL => $urlAccount,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_POSTFIELDS => 'shopperid=22',
		CURLOPT_HTTPHEADER => array(
		  'ClientToken: '.CLIENT_TOKEN,
		  'ShopperToken: '.$_SESSION['ShopperToken'],
		  'Content-Type: application/x-www-form-urlencoded',
		  'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000b0210ac00005000'
		),
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($response);
	
	$useHomestore = (object)$res->data->account;
	$shopperid = $_SESSION['shopperid'];
	$output = "";
	
	$output .= '<div class="container">
	<div class="registerSec">
		<div class="row">
		<div class="col-md-10 col-offset-2 m-auto">	
		<!-- <center><span class="alert alert-danger" style="color:red">Your password & Confirm password is not same please try again.</span></center><Br> -->
		<h2 class="mb-5 edit_pro">Edit User Profile
		<div class="subtReg text-right">';
       if($_GET['tab'] == 'edit-profile-mobile'){
		$output .= '<a href="'.site_url().'/forget-password/?tab=forget-password-mobile" class="btn" id="change-passs" style="font-size:15px">Change Password</a>';
	   }else{
		$output .= '<a href="'.site_url().'/forget-password/" class="btn" id="change-passs" style="font-size:15px">Change Password</a>';
	   }
	   $output .= '</div>
		</h2>
		 <form role="search" method="post" class="w-100" action="" id="commentForm">
		 
			<div class="row">
				<div class="form-group col-md-6">
					<label>First Name<span style="color:rgb(255, 38, 0)">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="hidden" name="register-coupon" value="">
					<input type="" name="firstname" value="'.$useDetails->FirstName.'" class="form-control" id="fname" required>
					<span style="color:red" id="fnameError"></span>
				</div>
				<input type="hidden" value="'.$shopperid.'" id="shopper_id">
				<div class="form-group col-md-6">
					<label>Last Name<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="" name="lastname"  value="'.$useDetails->LastName.'" class="form-control" id="lname" required>
					<span style="color:red" id="lnameError"></span>
				</div>
				<div class="form-group col-md-12">
					<label>Phone Number<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="" name="mobilephone"  value="'.$useDetails->MobilePhone.'" class="form-control" id="pcontact" required>
					<span style="color:rgb(255, 0, 0)" id="pcontactError"></span>
				</div>
				<div class="form-group col-md-10">
					<label>Address<span style="color:rgb(255, 0, 0)">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="" name="streetaddress1" value="'.$useDetails->StreetAddress1.'" class="form-control" id="address" required>
					<span style="color:red" id="addressError"></span>
				</div>
				<div class="form-group col-md-2">
					<label>Unit</label>
					<input type="" name="streetaddress2" value="'.$useDetails->StreetAddress2.'" class="form-control" id="unit">
				</div>
				<div class="form-group col-md-6">
					<label>City<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="" name="city" value="'.$useDetails->City.'" class="form-control" id="city" required>
					<span style="color:red" id="cityError"></span>
				</div>
				<div class="form-group col-md-3">
					<label>State<span style="color:red">*</span></label>
					
					<select name="state" class="form-control" id="state" required>
						<option value="">--Select States--</option>';
				foreach($states as $state){ 
					if($state->Abbreviation == $useDetails->State){
		$output .= '<option value="'.$state->Abbreviation.'" selected>'.$state->FullName.'</option>';
					}else{
		$output .= '<option value="'.$state->Abbreviation.'">'.$state->FullName.'</option>';				
					}
				} 
		$output .= '</select>
					<span style="color:red" id="stateError"></span>
				</div>
				<div class="form-group col-md-3">
					<label>Zip Code<span style="color:red">*</span></label>
					<input type="" name="zipcode" value="'.$useDetails->Zipcode.'" class="form-control" id="zcode" required>
					<span style="color:red" id="zcodeError"></span>
				</div>
				
				<div class="form-group col-md-6">
					<label>Birthday <span class="reqOp">REQUIRED</span></label>
					<input type="date" name="birthdate" value="'.substr($useDetails->BirthDate,0,-9).'" class="form-control" id="birthdate" required>
					<span style="color:red" id="birthdateError"></span>
				</div>
				<div class="form-group col-md-6">
					<label>Home Store <span class="reqOp">REQUIRED</span></label>
					<select name="homestore" id="homestore" class="form-control" required>
					<option value="">-------- Select Home Store --------</option>';
				foreach($homestore as $store){ 
					    if($store->ID == $useHomestore->HomeStoreID){
		$output .= '<option value="'.$store->ID.'" selected>'.$store->StoreName.'</option>';
						}else{
		$output .= '<option value="'.$store->ID.'">'.$store->StoreName.'</option>';					
						}
					 } 
		$output .= '</select>
					<span style="color:red" id="homestoreError"></span>
				</div>
               <br><br>
				<div class="form-group col-md-12">
					<div class="subtReg text-right">
						<a href="javascript:void(0);" class="btn" id="accountButton" onclick="return formValidate()">Update Account</a>
					</div>
				</div>
				<div class="col-md-12" id="successData">
				
					   <hr>
				</div>
				
			</div>
		  </form>
		 </div>
		</div>
	  </div>
	</div>';
	
	wp_send_json($output);
}

add_action('wp_ajax_getFaqPage', 'getFaqPage');
add_action('wp_ajax_nopriv_getFaqPage', 'getFaqPage');

function getFaqPage()
{
	include(get_template_directory().'/loyalityLane/functions.php');
	$output = "";

	$output .= '<div class="row"></div>';
	wp_send_json($output);
}

add_action('wp_ajax_getMemberId', 'getMemberId');
add_action('wp_ajax_nopriv_getMemberId', 'getMemberId');

function getMemberId()
{
	   include(get_template_directory().'/loyalityLane/functions.php');

        $url = BASE_URL.'/PhoneCardLookup?phone='.$_SESSION['loyalityLaneUserDetails']->data->shopper->MobilePhone;

		$curl = curl_init();

		curl_setopt_array($curl, array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_HTTPHEADER => array(
			'ClientToken: '.CLIENT_TOKEN,
			'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000d0210ac00005000'
		  ),
		));

      $response = curl_exec($curl);
	  curl_close($curl);
      $res = json_decode($response);
	  $cardDetails = (object)$res->data->Cards[0];
	  

	$output = "";

	$output .= '<div id="generator" style="display:none">
	Please fill in the code : <input type="text" id="barcodeValue" value="'.$cardDetails->CardNumber.'">
	<div id="config">
	  <div class="config">
		<div class="title">Type</div>
		<input type="radio" name="btype" id="ean8" value="ean8"><label for="ean8">EAN 8</label><br />
		<input type="radio" name="btype" id="ean13" value="ean13"><label for="ean13">EAN 13</label><br />
		<input type="radio" name="btype" id="upc" value="upc"><label for="upc">UPC</label><br />
		<input type="radio" name="btype" id="std25" value="std25"><label for="std25">standard 2 of 5 (industrial)</label><br />
		<input type="radio" name="btype" id="int25" value="int25"><label for="int25">interleaved 2 of 5</label><br />
		<input type="radio" name="btype" id="code11" value="code11"><label for="code11">code 11</label><br />
		<input type="radio" name="btype" id="code39" value="code39"><label for="code39">code 39</label><br />
		<input type="radio" name="btype" id="code93" value="code93"><label for="code93">code 93</label><br />
		<input type="radio" name="btype" id="code128" value="code128" checked="checked"><label for="code128">code 128</label><br />
		<input type="radio" name="btype" id="codabar" value="codabar"><label for="codabar">codabar</label><br />
		<input type="radio" name="btype" id="msi" value="msi"><label for="msi">MSI</label><br />
		<input type="radio" name="btype" id="datamatrix" value="datamatrix"><label for="datamatrix">Data Matrix</label><br /><br />
	  </div>
		  
	  <div class="config">
		<div class="title">Misc</div>
		  Background : <input type="text" id="bgColor" value="#FFFFFF" size="7"><br />
		  "1" Bars : <input type="text" id="color" value="#000000" size="7"><br />
		<div class="barcode1D">
		  bar width: <input type="text" id="barWidth" value="4" size="3"><br />
		  bar height: <input type="text" id="barHeight" value="100" size="3"><br />
		</div>
		<div class="barcode2D">
		  Module Size: <input type="text" id="moduleSize" value="5" size="3"><br />
		  Quiet Zone Modules: <input type="text" id="quietZoneSize" value="1" size="3"><br />
		  Form: <input type="checkbox" name="rectangular" id="rectangular"><label for="rectangular">Rectangular</label><br />
		</div>
		<div id="miscCanvas">
		  x : <input type="text" id="posX" value="10" size="3"><br />
		  y : <input type="text" id="posY" value="20" size="3"><br />
		</div>
	  </div>
		  
	  <div class="config">
		<div class="title">Format</div>
		<input type="radio" id="css" name="renderer" value="css" checked="checked"><label for="css">CSS</label><br />
		<input type="radio" id="bmp" name="renderer" value="bmp"><label for="bmp">BMP (not usable in IE)</label><br />
		<input type="radio" id="svg" name="renderer" value="svg"><label for="svg">SVG (not usable in IE)</label><br />
		<input type="radio" id="canvas" name="renderer" value="canvas"><label for="canvas">Canvas (not usable in IE)</label><br />
	  </div>
	</div>
	  
	<div id="submit">
	  <input type="button" onclick="generateBarcode();" value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Generate the barcode&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;">
	</div>
	  
  </div>
  
  <div id="barcodeTarget" class="barcodeTarget"></div>
  <canvas id="canvasTarget" width="150" height="150"></canvas>';
	
	wp_send_json($output);
}

add_action('wp_ajax_occuredClipCoupon', 'occuredClipCoupon');
add_action('wp_ajax_nopriv_occuredClipCoupon', 'occuredClipCoupon');

function occuredClipCoupon()
{
	include(get_template_directory().'/loyalityLane/functions.php');
	$url = BASE_URL.'/ClippedCoupon';
	$clippedCount = $_POST['clippedCount']+1;
	unset($_POST['action']);
	unset($_POST['clippedCount']);
    $_POST['accountid'] = $_SESSION['accountid'];
	$_POST['couponidlist'] = '['.$_POST['couponidlist'].']';
	
	//$response = requestToLL($url, "POST", $_POST);
    $header = array("ClientToken: ".CLIENT_TOKEN,"Content-Type: application/json");	

    $submissionData = '{';
		$sets = array();
		if (array_key_exists('couponidlist', $_POST)) {
			foreach($_POST as $column => $value){
				if($value != ""){
					$sets[] = "'".$column."'".":".$value;
				}
			} 
		} else {
			foreach($_POST as $column => $value){
				if($value != ""){
					$sets[] = "'".$column."'".":"."'".$value."'";
				}
			}
		}
		
		$submissionData .= implode(",", $sets);
		$submissionData .= "}";
		//wp_send_json($submissionData);
		 $curl = curl_init();
		$curlArray = [];
		
			$curlArray = array(
				CURLOPT_URL => $url,
				CURLOPT_RETURNTRANSFER => true,                     
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => 'POST',
				CURLOPT_POSTFIELDS => $submissionData,
				CURLOPT_HTTPHEADER => $header,
			);
			curl_setopt_array($curl, $curlArray );
			$response = curl_exec($curl);
			curl_close($curl);

			$responseData['clippedCountValue'] = $clippedCount;

			$url1 = BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid']; // clip

			$header1 = array(
				"ClientToken : ".CLIENT_TOKEN,
			 );
			$curl = curl_init(); 
			$curlArray = array(
				CURLOPT_URL => $url1,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => 'GET',
				CURLOPT_HTTPHEADER => $header1,
			);
			curl_setopt_array($curl, $curlArray );
			$response = curl_exec($curl);
		  
			curl_close($curl);
            $jsonData = json_decode($response);
	        $newData = $jsonData->data->coupons;
			//$clippedCouponsValue  = (object)$countClipped->data->coupons;
			$totalClippedSaving = 0;
			foreach($newData as $key => $value){
				preg_match('/\$([0-9]+[\.,0-9]*)/', $value->OfferSummaryTop, $match);
				$totalClippedSaving += $match[1];
			}
			
			$responseData['totalClippedSaving'] = number_format($totalClippedSaving, 2);


    wp_send_json($responseData); 
    
	
}

add_action('wp_ajax_editProfileToSaveData', 'editProfileToSaveData');
add_action('wp_ajax_nopriv_editProfileToSaveData', 'editProfileToSaveData');

function editProfileToSaveData(){

	include(get_template_directory().'/loyalityLane/functions.php');

	  
	$url = BASE_URL.'/Shopper';
	unset($_POST['action']);
	
	//$response = requestToLL($url, "POST", $_POST);
   
    $submissionData = '{';
		$sets = array();
			foreach($_POST as $column => $value){
				if($value != ""){
					$sets[] = "'".$column."'".":"."'".$value."'";
				}
			} 
		$submissionData .= implode(",", $sets);
		$submissionData .= "}";
	
	 $curl = curl_init();
		
		$curlArray = array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'PUT',
			CURLOPT_POSTFIELDS => $submissionData,
			CURLOPT_HTTPHEADER => array(
				'ClientToken: '.CLIENT_TOKEN,
				'ShopperToken: '.$_SESSION['ShopperToken'],
				'Content-Type: application/json',
				'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000b0210ac00005000'
			),
		);
		curl_setopt_array($curl, $curlArray );
		$response = curl_exec($curl);
		curl_close($curl);
	    $res = json_decode($response);
		 if($res->result == 'OK'){
			$message = 'Account Updated Successfully..';
		    $msg = '<span class="alert alert-success" style="color:Green">"'.$message.'"</span>';
		}else{
			$message = 'Account Not Updated..';
		    $msg = '<span class="alert alert-danger" style="color:red">"'.$message.'"</span>';
		} 
        wp_send_json($msg); 
}

/*==============Get Edit Profile For Mobile Template By Chetu INC =================*/ 
add_action('wp_ajax_getEditProfileForMobile', 'getEditProfileForMobile');
add_action('wp_ajax_nopriv_getEditProfileForMobile', 'getEditProfileForMobile');

function getEditProfileForMobile()
{

	include(get_template_directory().'/loyalityLane/functions.php');
	$url = BASE_URL.'/States';
	$curl = curl_init();
	$curlArray = array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_HTTPHEADER => array(
			'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000d0210ac00005000'
		),
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($response);
	$states = (object)$res->data->states;

	$urlHomeStore = BASE_URL.'/Store?showDisabled=true';
	$curl = curl_init();
	$curlArray = array(
		CURLOPT_URL => $urlHomeStore,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_HTTPHEADER => array(
		  'ClientToken: '.CLIENT_TOKEN,
		  'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000d0210ac00005000'
		),
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($response);
	$homestore = (object)$res->data->stores;

	$urlShopper = BASE_URL.'/Shopper?shopperid='.$_SESSION['shopperid'];
	$curl = curl_init();
	$curlArray = array(
		CURLOPT_URL => $urlShopper,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_POSTFIELDS => 'shopperid=22',
		CURLOPT_HTTPHEADER => array(
		  'ClientToken: '.CLIENT_TOKEN,
		  'ShopperToken: '.$_SESSION['ShopperToken'],
		  'Content-Type: application/x-www-form-urlencoded',
		  'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000d0210ac00005000'
		 ),
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($response);
	
	$useDetails = (object)$res->data->shopper;

	$urlAccount = BASE_URL.'/Account?accountid='.$_SESSION['accountid'];
	$curl = curl_init();
	$curlArray = array(
		CURLOPT_URL => $urlAccount,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'GET',
		CURLOPT_POSTFIELDS => 'shopperid=22',
		CURLOPT_HTTPHEADER => array(
		  'ClientToken: '.CLIENT_TOKEN,
		  'ShopperToken: '.$_SESSION['ShopperToken'],
		  'Content-Type: application/x-www-form-urlencoded',
		  'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000b0210ac00005000'
		),
	);
	curl_setopt_array($curl, $curlArray );
	$response = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($response);
	
	$useHomestore = (object)$res->data->account;
	$shopperid = $_SESSION['shopperid'];
	$output = "";
	
	$output .= '<div class="container">
	<div class="registerSec">
		<div class="row">
		<div class="col-md-10 col-offset-2 m-auto">	
		<!-- <center><span class="alert alert-danger" style="color:red">Your password & Confirm password is not same please try again.</span></center><Br> -->
		<h2 class="mb-5 edit_pro">Edit User Profile
		<div class="subtReg text-right">';
       
		$output .= '<a href="'.site_url().'/forget-password-mobile/" class="btn" id="change-passs" style="font-size:15px">Change Password</a>';
	   $output .= '</div>
		</h2>
		 <form role="search" method="post" class="w-100" action="" id="commentForm">
		 
			<div class="row">
				<div class="form-group col-md-6">
					<label>First Name<span style="color:rgb(255, 38, 0)">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="hidden" name="register-coupon" value="">
					<input type="" name="firstname" value="'.$useDetails->FirstName.'" class="form-control" id="fname" required>
					<span style="color:red" id="fnameError"></span>
				</div>
				<input type="hidden" value="'.$shopperid.'" id="shopper_id">
				<div class="form-group col-md-6">
					<label>Last Name<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="" name="lastname"  value="'.$useDetails->LastName.'" class="form-control" id="lname" required>
					<span style="color:red" id="lnameError"></span>
				</div>
				<div class="form-group col-md-12">
					<label>Phone Number<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="" name="mobilephone"  value="'.$useDetails->MobilePhone.'" class="form-control" id="pcontact" required>
					<span style="color:rgb(255, 0, 0)" id="pcontactError"></span>
				</div>
				<div class="form-group col-md-10">
					<label>Address<span style="color:rgb(255, 0, 0)">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="" name="streetaddress1" value="'.$useDetails->StreetAddress1.'" class="form-control" id="address" required>
					<span style="color:red" id="addressError"></span>
				</div>
				<div class="form-group col-md-2">
					<label>Unit</label>
					<input type="" name="streetaddress2" value="'.$useDetails->StreetAddress2.'" class="form-control" id="unit">
				</div>
				<div class="form-group col-md-6">
					<label>City<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
					<input type="" name="city" value="'.$useDetails->City.'" class="form-control" id="city" required>
					<span style="color:red" id="cityError"></span>
				</div>
				<div class="form-group col-md-3">
					<label>State<span style="color:red">*</span></label>
					
					<select name="state" class="form-control" id="state" required>
						<option value="">--Select States--</option>';
				foreach($states as $state){ 
					if($state->Abbreviation == $useDetails->State){
		$output .= '<option value="'.$state->Abbreviation.'" selected>'.$state->FullName.'</option>';
					}else{
		$output .= '<option value="'.$state->Abbreviation.'">'.$state->FullName.'</option>';				
					}
				} 
		$output .= '</select>
					<span style="color:red" id="stateError"></span>
				</div>
				<div class="form-group col-md-3">
					<label>Zip Code<span style="color:red">*</span></label>
					<input type="" name="zipcode" value="'.$useDetails->Zipcode.'" class="form-control" id="zcode" required>
					<span style="color:red" id="zcodeError"></span>
				</div>
				
				<div class="form-group col-md-6">
					<label>Birthday <span class="reqOp">REQUIRED</span></label>
					<input type="date" name="birthdate" value="'.substr($useDetails->BirthDate,0,-9).'" class="form-control" id="birthdate" required>
					<span style="color:red" id="birthdateError"></span>
				</div>
				<div class="form-group col-md-6">
					<label>Home Store <span class="reqOp">REQUIRED</span></label>
					<select name="homestore" id="homestore" class="form-control" required>
					<option value="">-------- Select Home Store --------</option>';
				foreach($homestore as $store){ 
					    if($store->ID == $useHomestore->HomeStoreID){
		$output .= '<option value="'.$store->ID.'" selected>'.$store->StoreName.'</option>';
						}else{
		$output .= '<option value="'.$store->ID.'">'.$store->StoreName.'</option>';					
						}
					 } 
		$output .= '</select>
					<span style="color:red" id="homestoreError"></span>
				</div>
               <br><br>
				<div class="form-group col-md-12">
					<div class="subtReg text-right">
						<a href="javascript:void(0);" class="btn" id="accountButton" onclick="return formValidate()">Update Account</a>
					</div>
				</div>
				<div class="col-md-12" id="successData">
				
					   <hr>
				</div>
				
			</div>
		  </form>
		 </div>
		</div>
	  </div>
	</div>';
	
	wp_send_json($output);
}

?>
