<?php/*Template Name: myclubmobile*/ ?>

<div id="page-loader" class="loading">Loading&#8230;</div>
<div class="main container">
   <!---body conteent----->
   <div class="maincontent">
      <div class="welcomeUser text-center">
      	<?php 
     echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login-mobile?logout=true&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>"; ?>

     </div> 
         
<div id="Available"></div>

</div></div></div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/templates/css/style.css">
<link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/templates/css/responsive.css">
<style>
#img_data{
   display:none;
}
/* Absolute Center Spinner */
.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.loading:before {
  content: '';
  display: hide;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
    background: radial-gradient(rgba(20, 20, 20,.8), rgba(0, 0, 0, .8));

  background: -webkit-radial-gradient(rgba(20, 20, 20,.8), rgba(0, 0, 0,.8));
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}

.loading:not(:required):after {
  content: '';
  display: block;
  font-size: 10px;
  width: 1em;
  height: 1em;
  margin-top: -0.5em;
  -webkit-animation: spinner 150ms infinite linear;
  -moz-animation: spinner 150ms infinite linear;
  -ms-animation: spinner 150ms infinite linear;
  -o-animation: spinner 150ms infinite linear;
  animation: spinner 150ms infinite linear;
  border-radius: 0.5em;
  -webkit-box-shadow: rgba(255,255,255, 0.75) 1.5em 0 0 0, rgba(255,255,255, 0.75) 1.1em 1.1em 0 0, rgba(255,255,255, 0.75) 0 1.5em 0 0, rgba(255,255,255, 0.75) -1.1em 1.1em 0 0, rgba(255,255,255, 0.75) -1.5em 0 0 0, rgba(255,255,255, 0.75) -1.1em -1.1em 0 0, rgba(255,255,255, 0.75) 0 -1.5em 0 0, rgba(255,255,255, 0.75) 1.1em -1.1em 0 0;
box-shadow: rgba(255,255,255, 0.75) 1.5em 0 0 0, rgba(255,255,255, 0.75) 1.1em 1.1em 0 0, rgba(255,255,255, 0.75) 0 1.5em 0 0, rgba(255,255,255, 0.75) -1.1em 1.1em 0 0, rgba(255,255,255, 0.75) -1.5em 0 0 0, rgba(255,255,255, 0.75) -1.1em -1.1em 0 0, rgba(255,255,255, 0.75) 0 -1.5em 0 0, rgba(255,255,255, 0.75) 1.1em -1.1em 0 0;
}

/* Animation */

@-webkit-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@-moz-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@-o-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
 
      #config{
          overflow: auto;
          margin-bottom: 10px;
      }
      .config{
          float: left;
          width: 200px;
          height: 250px;
          border: 1px solid #000;
          margin-left: 10px;
      }
      .config .title{
          font-weight: bold;
          text-align: center;
      }
      .config .barcode2D,
      #miscCanvas{
        display: none;
      }
      #submit{
          clear: both;
      }
      #barcodeTarget,
      #canvasTarget{
        margin-top: 20px;
      }
    


      @media(max-width:992px){
         #barcodeTarget {
    margin-top: 20px;
    TOP: 0;
    BACKGROUND: white;
    WIDTH: 100%;
    HEIGHT: 100%;

}


        }
        @media only screen and (min-device-width: 320px) and (max-device-width: 767px){
.registerSec {
    padding: 0;

   
   }
   #barcodeTarget p {
    font-size: 39px !important;
}
   .maincontent {

    padding: 0px;
}

   span.alert.alert-success {
    font-size: 12px;
}
   .edit_pro{
      font-size: 18px;
   }
}


      @media(max-width:1199px){
         .couponsTab .nav-item{
            margin-bottom:10px;
         }
         .colorboxmain{
            height:80px;
         }
      }
      @media(max-width:1000px){ 
         .colorboxmain{
            height:75px;
         }
      }
      @media(max-width:900px){ 
         .colorboxmain{
            height:50px;
         }
      }
      @media(max-width:800px){ 
         .colorboxmain{
            height:45px;
         }
      }
      @media(max-width:700px){ 
         .colorboxmain{
            height:30px;
         }
      }
      @media(max-width:600px){ 
         .colorboxmain{
            height:25px;
         }
      }
      @media(max-width:500px){ 
         .colorboxmain{
            height:25px;
         }
         #barcodeTarget{
            zoom:80%;
            margin:auto;
         }




      }
      @media(max-width:400px){ 
         .colorboxmain{
            height:20px;
            margin:5px;
         }
         #barcodeTarget{
            zoom:75%;
            margin:auto;
         }
      }
      @media(max-width:300px){ 
         .colorboxmain{
            height:15px; 
         } 
         #barcodeTarget{
            zoom:50%;
            margin:auto;
         }
      }
      
      .sfsiplus_footerLnk{
    display: none;
}

      
</style>
<script>
	$( document ).ready(function() {
	//console.log("Hello");
   var myclubData = 'myclub-count-mobile';
		$(".couponsTab").hide();
		$("#colophon").hide();
		$(".header-container_wrap").hide();
		$(".sfsiplus_footerLnk").hide();
		$(".guidContent").hide();
		$(".saving-data").hide();
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getMyclubData', myclubData : myclubData},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data.output;
				$("#page-loader").hide(); 
			}
		});

});
</script>