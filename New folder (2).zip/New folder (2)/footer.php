<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Latify
 */

?>

	</div><!-- #content -->
	<?php
	$ua = strtolower($_SERVER['HTTP_USER_AGENT']); 
	if(is_numeric(strpos($ua, "mobile"))){
		
	}
     ?>

	<footer id="colophon" <?php latify_footer_class() ?> role="contentinfo">
		<?php get_template_part( 'template-parts/footer/footer-area' ); ?>
		<?php get_template_part( apply_filters( 'latify_footer_layout_template_slug', 'template-parts/footer/layout' ), get_theme_mod( 'footer_layout_type' ) ); ?>

		<script>
$ = jQuery;


$(".loading").hide();
	$(document).on("click", '.coupDetails', function(e) { 
		$("#modal-loader").show();
		var coupon_id = $(this).attr("data-coupon-id");
		var availableORclipped = $(this).attr("data-available-id");
		 
			jQuery.ajax({
				type:'POST',
				url : '<?php echo admin_url('admin-ajax.php'); ?>',
				data : {action : 'getCouponDetails', coupon_id : coupon_id, availableORclipped : availableORclipped },
				success:function(res){
					
					var today = new Date(res.ExpirationDate);
					var dd = String(today.getDate()).padStart(2, '0');
					var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
					var yyyy = today.getFullYear();

					today =   mm + '-'+dd+ '-' + yyyy;
					let UPC = '';
					res.ItemUPCs.forEach(data=>{
						UPC +=data+'<br>';
					})
					$("#act_date").html(res.ActivationDate);
					$("#brand_data").html(res.Brand);
					$("#category_data").html(res.CategoryName);
					$("#short_data").html(res.OfferShortDesc);
					$("#summary_data").html(res.OfferSummaryDetail);
					$("#source_data").html(res.SourceName);
					$("#value_data").html(res.Value);
					$("#expiration_data").html(today);
					$("#ItemUPCs").html(UPC);
					$("#img_data").attr('src',res.ImageUrl);
					$('#img_data').show();
					$("#modal-loader").hide();
				}
		});
		
	})

	

	$('.brandCatCoupon').on('change', function(e) {
		$('#available-count').addClass('active');
		$('#clipped-count').removeClass('active');
		$('#myclub-count').removeClass('active');
		$('#my-reward').removeClass('active');
		$('#edit-profile').removeClass('active');
		$('#faq-page').removeClass('active');
		$('#member-id').removeClass('active');
		$('#my-reward').removeClass('active');
	
		$("#page-loader").show();
			var searchByOption = $(this).val();
			//var get_id = $('option:selected').attr("id");
			
			jQuery.ajax({
				type: "POST",
				url : '<?php echo admin_url('admin-ajax.php'); ?>',
				data: {action : 'getCategoryByCoupons', searchByOption : searchByOption},

				success:function( data ) {
					document.getElementById('Available').innerHTML=data.output;
					<?php 
				if(array_key_exists('accountid',$_SESSION)) { ?>
					document.getElementById('available_saving').innerHTML='$'+data.AvailableSaving;
					document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
					document.getElementById('clipped-count').innerHTML='Clipped (<span id="clippedCountData">'+data.ClippedCount+'</span>)';
				<?php } ?>
					
					$("#page-loader").hide();
				}
			});
	});

	$('#clipped-count').on('click', function(e) {
	
		$(this).addClass('active');
		$('#available-count').removeClass('active');
		$('#myclub-count').removeClass('active');
		$('#my-reward').removeClass('active');
		$('#edit-profile').removeClass('active');
		$('#faq-page').removeClass('active');
		$('#member-id').removeClass('active');
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getClippedCoupons'},
			success:function( data ) {
				$('.serachCoupen').show();
				document.getElementById('Available').innerHTML=data.output;
				<?php 
				if(array_key_exists('accountid',$_SESSION)) { ?>
				document.getElementById('clipped_saving').innerHTML='$'+data.ClippedSaving;
				//document.getElementById('available_saving').innerHTML='$'+data.ClippedSaving;
				//document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				document.getElementById('clipped-count').innerHTML='Clipped (<span id="clippedCountData">'+data.ClippedCount+'</span>)';
				<?php } ?>
				
				$("#page-loader").hide();
			}
		});
	});

	$('#myclub-count').on('click', function(e) {

		$(this).addClass('active');
		$('#available-count').removeClass('active');
		$('#clipped-count').removeClass('active');
		$('#my-reward').removeClass('active');
		$('#edit-profile').removeClass('active');
		$('#faq-page').removeClass('active');
		$('#member-id').removeClass('active');
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getMyclubData'},
			success:function( data ) {
				 $('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data.output;
				$("#page-loader").hide(); 
			}
		});
	});

	$('#myclub-count-mobile').on('click', function(e) {
		var myclubData = 'myclub-count-mobile';
		$(".couponsTab").hide();
		$("#colophon").hide();
		$(".header-container_wrap").hide();
		$(".sfsiplus_footerLnk").hide();
		$(".guidContent").hide();
		$(".saving-data").hide();
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getMyclubData', myclubData : myclubData},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data.output;
				$("#page-loader").hide(); 
			}
		});
	});


	$('#available-count').on('click', function(e) {
		var category = '';
		var brand = '';
		if($('#categoryOption')[0].value != ''){
			var category = $('#categoryOption')[0].value;
		}
		if($('#brandSelected')[0].value != ''){
			var brand = $('#brandSelected')[0].value;
		}
		
		$(this).addClass('active');
		$('#clipped-count').removeClass('active');
		$('#myclub-count').removeClass('active');
		$('#my-reward').removeClass('active');
		$('#edit-profile').removeClass('active');
		$('#faq-page').removeClass('active');
		$('#member-id').removeClass('active');
		$('#my-reward').removeClass('active');
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getAvailableCoupons', 'category': category, 'brand' : brand},
			success:function( data ) {
				$('.serachCoupen').show();
				document.getElementById('Available').innerHTML=data.output;
				<?php 
				if(array_key_exists('accountid',$_SESSION)) { ?>
				document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				document.getElementById('available_saving').innerHTML='$'+data.AvailableSaving;
				<?php } ?>
				//document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
				$("#page-loader").hide();
			}
		});
	});


$('#home-mobile').on('click', function(e) {
		var category = '';
		var brand = '';
		if($('#categoryOption')[0].value != ''){
			var category = $('#categoryOption')[0].value;
		}
		if($('#brandSelected')[0].value != ''){
			var brand = $('#brandSelected')[0].value;
		}
		$(this).addClass('active');
		$('#clipped-count-mobile').removeClass('active');
		$(".myclubs").hide();
		$(".my-rewards").hide();
		$(".edit-profiles").hide();
		$(".member-ids").hide();
		$(".faq-pages").hide();
		$("#colophon").hide();
		$(".header-container_wrap").hide();
		$(".sfsiplus_footerLnk").hide();
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getAvailableCoupons', 'category': category, 'brand' : brand},
			success:function( data ) {
				$('.serachCoupen').show();
				document.getElementById('Available').innerHTML=data.output;
				<?php 
				if(array_key_exists('accountid',$_SESSION)) { ?>
				document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				document.getElementById('available_saving').innerHTML='$'+data.AvailableSaving;
				<?php } ?>
				//document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
				$("#page-loader").hide();
			}
		});
	});



	$('#clipped-count-mobile').on('click', function(e) {
	
	$(this).addClass('active');
	$('#home-mobile').removeClass('active');
		$(".myclubs").hide();
		$(".my-rewards").hide();
		$(".edit-profiles").hide();
		$(".member-ids").hide();
		$(".faq-pages").hide();
		$("#colophon").hide();
		$(".header-container_wrap").hide();
		$(".sfsiplus_footerLnk").hide();
	$("#page-loader").show();
	jQuery.ajax({
		type: "POST",
		url : '<?php echo admin_url('admin-ajax.php'); ?>',
		data: {action : 'getClippedCoupons'},
		success:function( data ) {
			$('.serachCoupen').show();
			document.getElementById('Available').innerHTML=data.output;
			<?php 
			if(array_key_exists('accountid',$_SESSION)) { ?>
			document.getElementById('clipped_saving').innerHTML='$'+data.ClippedSaving;
			//document.getElementById('available_saving').innerHTML='$'+data.ClippedSaving;
			//document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
			document.getElementById('clipped-count').innerHTML='Clipped (<span id="clippedCountData">'+data.ClippedCount+'</span>)';
			<?php } ?>
			
			$("#page-loader").hide();
		}
	});
});

	
	$(document).on("click", '.ShareFB', function(e) { 
		
		//var totalurl=encodeURIComponent(url+'?img='+img);
		var title = $(this).attr("fb-data-title");       
		var imgURL = $(this).attr("fb-data-image");
		var siteURL = $(this).attr("fb-data-URL");
		
	   
		window.open('http://www.facebook.com/sharer.php?u='+imgURL+'&quote='+title+', '+siteURL,'','width=500, height=500, scrollbars=yes, resizable=no');
	})
	/* $('#my-reward').on('click', function(e) {
		$(this).addClass('active');
		$('#clipped-count').removeClass('active');
		$('#myclub-count').removeClass('active');
		$('#available-count').removeClass('active');
		$('#edit-profile').removeClass('active');
		$('#faq-page').removeClass('active');
		$('#member-id').removeClass('active');
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php //echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getMyReward'},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data.output;
				
				$("#page-loader").hide();
			}
		});
	});	 */

	$('#edit-profile').on('click', function(e) {
		$(this).addClass('active');
		$('#clipped-count').removeClass('active');
		$('#myclub-count').removeClass('active');
		$('#available-count').removeClass('active');
		$('#faq-page').removeClass('active');
		$('#member-id').removeClass('active');
		$('#my-reward').removeClass('active');
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getEditProfile'},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data;
				//document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				//document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
				$("#page-loader").hide();
				
			}
		});
	});


	$('#edit-profile-mobile').on('click', function(e) {
		$(".couponsTab").hide();
		$("#colophon").hide();
		$(".faqavalaiblehide").hide();
		$(".header-container_wrap").hide();
		$(".sfsiplus_footerLnk").hide();
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getEditProfile'},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data;
				//document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				//document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
				$("#page-loader").hide();
				
			}
		});
	});

	$('#member-id-mobile').on('click', function(e) {
		$(".couponsTab").hide();
		$("#colophon").hide();
		$(".faqavalaiblehide").hide();
		$(".header-container_wrap").hide();
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getMemberId'},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data;
				generateBarcode();
				//document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				//document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
				$("#page-loader").hide();
			}
		});
	});



	$('.nav-link').click(function(){
		const url = new URL(window.location);
		url.searchParams.set('tab', this.id);
		window.history.pushState({}, '', url);
	})
	/* $('#faq-page').on('click', function(e) {
		$(this).addClass('active');
		$('#clipped-count').removeClass('active');
		$('#myclub-count').removeClass('active');
		$('#available-count').removeClass('active');
		$('#edit-profile').removeClass('active');
		$('#member-id').removeClass('active');
		$('#my-reward').removeClass('active');
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php //echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getFaqPage'},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data.output;
				//document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				//document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
				$("#page-loader").hide();
			}
		});
	}); */

	$('#member-id').on('click', function(e) {
		$(this).addClass('active');
		$('#clipped-count').removeClass('active');
		$('#myclub-count').removeClass('active');
		$('#available-count').removeClass('active');
		$('#edit-profile').removeClass('active');
		$('#faq-page').removeClass('active');
		$('#my-reward').removeClass('active');
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getMemberId'},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data;
				generateBarcode();
				//document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				//document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
				$("#page-loader").hide();
			}
		});
	});


	$(document).on("click", '#clipCoupon', function(e) { 
		// alert(e);
		var coupon_ids = $(this).attr("data-coupons-id");
		// alert(coupon_ids);
		var clippedCount = $('#clippedCountData').text();
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: { action : 'occuredClipCoupon', couponidlist: coupon_ids, clippedCount: clippedCount},
			success:function( data ) {
				<?php
				if(array_key_exists('accountid',$_SESSION)) { ?>
					document.getElementById('clipped_saving').innerHTML='$'+data.totalClippedSaving;
				<?php } ?>
				document.getElementById('clippedCountData').innerHTML=data.clippedCountValue;
				document.getElementById('clippedCountValue').innerHTML=data.clippedCountValue;
				$('.error').stop().fadeIn(400).delay(3000).fadeOut(400);	
				//$('#available-count').click();
				const urlParams = new URLSearchParams(window.location.search);
                const myParam = urlParams.get('tab');
				if(myParam != 'home-mobile'){
					$('#available-count').click();
				}else{
					$('#'+myParam).click();
				}
                
				// $("#page-loader").hide();
			}
		});
	});

	$(document).on("click", '#accountButton', function(e) { 
	   if(formValidate()){
		var fname = $("#fname").val();
		var lname = $("#lname").val();
		var pcontact = $("#pcontact").val();
		var address = $("#address").val();
		var city = $("#city").val();
		var state = $('#state :selected').val();
		var zcode = $("#zcode").val();
		var dateData = $("#birthdate").val();
		var homestore = $('#homestore :selected').val();
		var shopperid = $("#shopper_id").val();

		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: { action : 'editProfileToSaveData', 'shopperid' : shopperid, 'firstname' : fname, 'lastname' : lname, 'mobilephone' : pcontact, 'streetaddress1' : address, 'city' : city, 'state' : state, 'zipcode' : zcode, 'birthdate' : dateData, 'homestore' : homestore},
			success:function( data ) {
				document.getElementById('successData').innerHTML=data;
				$("#page-loader").hide();
			}
		});
	   }
	});

	$(document).on("click", '#change-pass', function(e) {
		$('#member-id').removeClass('active');
		$('#clipped-count').removeClass('active');
		$('#myclub-count').removeClass('active');
		$('#available-count').removeClass('active');
		$('#edit-profile').removeClass('active');
		$('#faq-page').removeClass('active');
		$('#my-reward').removeClass('active');
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'changePassword'},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data;
				//document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				//document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
				$("#page-loader").hide();
			}
		});
	});


	$(document).on("click", '#resetEmailButtom', function(e) {
		var email= $("#email-data").val();
		
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'verifyEmail', 'email' : email},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('resetPassLink').innerHTML=data;
				//document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
				//document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
				$("#page-loader").hide();
			}
		});
	});

function formValidate(){
	var count = true;
	var fname = document.getElementById("fname").value;
	var lname = document.getElementById("lname").value;
	var pcontact = document.getElementById("pcontact").value;
	var address = document.getElementById("address").value;
	var city = document.getElementById("city").value;
	var state = document.getElementById("state").value;
	var zcode = document.getElementById("zcode").value;
	var homestore = document.getElementById("homestore").value;
	if(fname==""){
		document.getElementById("fnameError").innerHTML="First Name is required.";
		document.documentElement.scrollTop = 450;
		count = false;
	}
	else{
		document.getElementById("fnameError").innerHTML="";
	}
	if(lname==""){
		document.getElementById("lnameError").innerHTML="Last Name is required.";
		document.documentElement.scrollTop = 450;
		count = false;
	}
	else{
		document.getElementById("lnameError").innerHTML="";
	}
	if(pcontact==""){
		document.getElementById("pcontactError").innerHTML="Phone Number is required.";
		document.documentElement.scrollTop = 450;
		count = false;
	}else if(!/^[0-9]+$/.test(pcontact)){
		document.getElementById("pcontactError").innerHTML="Phone Number must be numeric value.";
		document.documentElement.scrollTop = 450;
		count = false;
	}
	else{
		document.getElementById("pcontactError").innerHTML="";
	}
	if(address==""){
		document.getElementById("addressError").innerHTML="Address Number is required.";
		document.documentElement.scrollTop = 450;
		count = false;
	}else{
		document.getElementById("addressError").innerHTML="";
	}
	if(city==""){
		document.getElementById("cityError").innerHTML="City is required.";
		document.documentElement.scrollTop = 450;
		count = false;
	}
	else{
		document.getElementById("cityError").innerHTML="";
	}
	if(state==""){
		document.getElementById("stateError").innerHTML="State is required.";
		document.documentElement.scrollTop = 450;
		count = false;
	}else{
		document.getElementById("stateError").innerHTML="";
	}
	if(zcode==""){
		document.getElementById("zcodeError").innerHTML="Zip code is required.";
		document.documentElement.scrollTop = 450;
		count = false;
	}else if(zcode.length>5 || zcode.length<5){
		document.getElementById("zcodeError").innerHTML="Zip code must be five digit number.";
		document.documentElement.scrollTop = 450;
		count = false;
	}
	else{
		document.getElementById("zcodeError").innerHTML="";
	}
	if(homestore==""){
		document.getElementById("homestoreError").innerHTML="Home Store is required.";
		document.documentElement.scrollTop = 750;
		count = false;
	}else{
		document.getElementById("homestoreError").innerHTML="";
	}
	if(count==false){
		return count;				
	}else{
		return count;
	}
}
<?php
if(array_key_exists('accountid',$_SESSION)) { ?>
const urlParams = new URLSearchParams(window.location.search);
const myParam = urlParams.get('tab');
$('#'+myParam).click();
<?php } ?>

</script>


	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
