<?php

/*
Plugin Name: EpicSolution Slider
Description: This Plugin for EpicSolution Slider.
Version:1.0
Author: Chetu Inc.
*/

if(!defined('ABSPATH')){
  exit;
}

/* Function For Custom Post Type slider */

function cptui_register_my_slider() {

  $labels = [
		"name" => __( "Slider", "monstroid2" ),
		"singular_name" => __( "Slider", "monstroid2" ),
		"menu_name" => __( "EpicSolution Slider", "monstroid2" ),
		"all_items" => __( "All Slider", "monstroid2" ),
		"add_new" => __( "Add Slider", "monstroid2" ),
		"add_new_item" => __( "Add New Slider", "monstroid2" ),
	];

	$args = [
		"label" => __( "Slider", "monstroid2" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => false,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => true,
		"rewrite" => [ "slug" => "slider", "with_front" => true ],
		"query_var" => true,
		"supports" => [ "title" ],
		"show_in_graphql" => false,
		'menu_icon' => 'dashicons-format-gallery',
		'menu_position' => 59,
	];

	register_post_type( "slider", $args );
}
add_action( 'init', 'cptui_register_my_slider' );


/* Plugin deactivation Code */

function myplugin_flush_rewrites() {
    cptui_register_my_slider();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'myplugin_flush_rewrites' );


/* plugin Deactivation code */

function my_plugin_uninstall() {
  
  unregister_post_type( 'slider' );
}
register_uninstall_hook( __FILE__, 'my_plugin_uninstall' );



/* Add js file in Theme Footer*/

function epic_slider_enqueue_footer_script() {
  
  wp_enqueue_script( 'slider_flex_min', plugin_dir_url( __FILE__ ) . 'assets/js/jquery.min.js', array(), '1.0' );

  wp_enqueue_script( 'slider_flex', plugin_dir_url( __FILE__ ) . 'assets/js/jquery.flexslider.js', array(), '1.0' );

  wp_enqueue_script( 'slider_flex_custom', plugin_dir_url( __FILE__ ) . 'assets/js/flex_slider.js', array(), '1.0' );
}
add_action( 'wp_footer', 'epic_slider_enqueue_footer_script' );


/* Add css and js in Admin panel*/

function epic_slider_enqueue_admin_script() {
    

    if ( ! did_action( 'wp_enqueue_media' ) ) {
      wp_enqueue_media();
    }

    wp_enqueue_script( 'datepicker_script', plugin_dir_url( __FILE__ ) .'assets/js/jquery-ui.js', array(), '1.0' );

    wp_enqueue_style( 'datepicker_style', plugin_dir_url( __FILE__ ) .'assets/css/jquery-ui.css', array(), '1.0' );

    wp_enqueue_style( 'slider_custom_style', plugin_dir_url( __FILE__ ) .'assets/css/slider_custom.css', array(), '1.0' );

    wp_enqueue_script( 'slider_custom_script', plugin_dir_url( __FILE__ ) .'assets/js/slider_custom.js', array(), '1.0' );

    wp_enqueue_script( 'slider_custom_script1', plugin_dir_url( __FILE__ ) .'assets/js/wp_media_uploader.js', array(), '1.0' );
}
add_action( 'admin_enqueue_scripts', 'epic_slider_enqueue_admin_script' );


/* Add slider style in Theme Header */

function epic_slider_enqueue_head_script() {

  wp_enqueue_style( 'slider_flex', plugin_dir_url( __FILE__ ) . 'assets/css/flexslider.css', array(), '1.0' );
}

add_action( 'wp_head', 'epic_slider_enqueue_head_script' );


/* Include slide metabox.php */

include plugin_dir_path(__FILE__).'slider_metabox.php';



/* Modify columns of All slider in post type epicsolutions slider */

add_filter( 'manage_slider_posts_columns', 'set_custom_edit_slider_columns' );

function set_custom_edit_slider_columns($columns) {

  unset( $columns['date'] );
  $columns['slider_id'] = __( 'Slider Id', 'your_text_domain' );
  $columns['image_count'] = __( 'Image', 'your_text_domain' );
  $columns['short'] = __( 'Shortcode', 'your_text_domain' );

  return $columns;
}


/* Add the data to the custom columns for the book post type */

add_action( 'manage_slider_posts_custom_column' , 'custom_slider_column', 10, 2 );

function custom_slider_column( $column, $post_id ) {

  switch ( $column ) {

    case 'slider_id' :
      $terms = get_post( $post_id , 'slider_id' , '' , ',' , '' );
      $postid = $terms->ID;
      if (!empty( $postid ) ){
        echo $postid;
      }
    break;

    case 'image_count':
      $image = get_post_meta($post_id, 'slider_image_group',true);

      $i = 0;
      foreach($image as $images=>$item) {

       $slider_number = $item['sliderItemImage'];
       $i++;
      }
      if(!empty($slider_number)){
        echo $i;
      }
    break;

    case 'short' :
      $terms = get_post( $post_id , 'short' , '' , ',' , '' );
      $postid = $terms->ID;
      if (!empty( $postid ) ){
        echo '[epicsolution Id="'.$postid.'"]';
      }
    break;
  }
}


/*  functions of slider short code */

function epic_slider_shortcode( $atts, $content = null) { 

  $atts = shortcode_atts(
    array(
      'id' => ''
  ), $atts );

 $epicslotion = $atts['id'];

 $post_id = $epicslotion;

 $slider_post_meta = get_post_meta($post_id, 'slider_image_group',true);

 $sliderhtml = '<div class="flexslider"><ul class="slides">';

  foreach ($slider_post_meta as  $slider) {

   $sliderImageId =  $slider['sliderItemImage'];
   $getImage = wp_get_attachment_image_src($sliderImageId);
   $sliderStartDate  = $slider['sliderStartDate'];
   $sliderEndDate = $slider['sliderEndDate'];
   $sliderhtml .='<li><img src="'.$getImage[0].'" /></li>';
  }

 $sliderhtml .='</ul></div>';

 return $sliderhtml;
} 
add_shortcode('epicsolution', 'epic_slider_shortcode');