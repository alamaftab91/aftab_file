$ = jQuery;
$(function() {

  $('.datepicker').datepicker();

  $('#add-row').click(function() {

    var name = 'date_' + ($('.datepicker').length + 1);

    $('.addmoredate').append('<div id="slider_image"><a href="#" id="button" class="epic-upl" >Upload Image</a><input type="hidden" name="slider-img[]" value=""></div>')

    $('.addmoredate').append('<div class="startdate f-div">Start Date ');
     $('.addmoredate').append(
      $('<input/>', {name: 'startdate[]', type: 'text',placeholder:'mm/dd/yyyy', class: 'datepicker start-date start-inp'}).datepicker()
    );
    $('.addmoredate').append('</div>');

    $('.addmoredate').append('<div class="enddate s-div">End Date').append(
      $('<input/>', {name: 'enddate[]', type: 'text',placeholder:'mm/dd/yyyy', class: 'datepicker end-date end-inp'}).datepicker()
    ).append('</div>');

    $(".addmoredate").append('<div><a href="#" class= "button remove-row">Remove</a></div>');
  });
});