<?php

global $post;
if (!defined('ABSPATH'))
{
  exit;
}

/* Add meta box in Epic Solution Slider post type */

add_action('admin_init', 'pre_add_meta_boxes', 2);

function pre_add_meta_boxes()
{
    add_meta_box(
        'preinvoice-group', 
        'EpicSolution Slider', 
        'pre_repeatable_meta_box_display', 
        'slider',
        'normal',
        'default'
    );
}


function pre_repeatable_meta_box_display()
{
    global $post;
    $preinvoice_group = get_post_meta($post->ID, 'slider_image_group', true);
    wp_nonce_field('pre_repeatable_meta_box_nonce', 'pre_repeatable_meta_box_nonce');
?>

<form>
 <div id="repeatable-fieldset-one" width="100%">
  <div>
    <?php
    if ($preinvoice_group):

        foreach ($preinvoice_group as $field){
           $img = $field['sliderItemImage'];
           $image = wp_get_attachment_image_src($img);
    ?>
    <div class='sliderdataset'>
        <div class="sliderimage">
      <a href="#" class="epic-upl" ><img src="<?php if(!empty($image)){ echo $image[0];} ?>" /></a>
      <input type="hidden" name="slider-img[]" height="50px"; width="50px" value="<?php if($field['sliderItemImage'] != '') echo esc_attr( $field['sliderItemImage'] ); ?>">
        </div>
      <div class="startdate"><label>Start Date</label>
        <input type="text" class="datepicker" name="startdate[]" placeholder="mm/dd/yyyy" autocomplete="off" value="<?php if($field['sliderStartDate'] != '') echo esc_attr( $field['sliderStartDate'] ); ?>" />
      </div>
      <div class="enddate"><label>End Date</label>
        <input type="text"  id="input" class="datepicker" name="enddate[]"  placeholder="mm/dd/yyyy" autocomplete="off" value="<?php if($field['sliderEndDate'] != '') echo esc_attr( $field['sliderEndDate'] ); ?>" /></div>
    </div>
    <?php
        }
        else:
            // show a blank one

?>
    <div class='slider_blank'>
        <div id= slider_image>

          <a href="#" id="button" class="epic-upl" >Upload Image</a>
          <input type="hidden" name="slider-img[]" height="50px"; width="50px">

        </div>
      <div class="startdate1"><label>Start Date</label>
        <input type="text" id= "input_startdate" class="datepicker" name="startdate[]" placeholder="mm/dd/yyyy" autocomplete="off" />
      </div>
      <div class="enddate1"><label>End Date</label>
        <input type="text"  id="input_enddate" class="datepicker" name="enddate[]"  placeholder="mm/dd/yyyy" autocomplete="off" /></div>
    </div>
    <?php
        endif; ?>
        <div class='addmoredate'>

        </div>



  </div>
</div>

</form>
<p><a id="add-row" class="button" href="#">Add More Slide</a></p>
<?php
    }


/*Save meta box value in database*/

add_action('save_post', 'pre_repeatable_meta_box_save');
function pre_repeatable_meta_box_save($post_id)
{
    if (!isset($_POST['pre_repeatable_meta_box_nonce']) || !wp_verify_nonce($_POST['pre_repeatable_meta_box_nonce'], 'pre_repeatable_meta_box_nonce')) return;

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    if (!current_user_can('edit_post', $post_id)) return;

    $old = get_post_meta($post_id, 'slider_image_group', true);

    $new = array();

    $sliderItems = $_POST['slider-img'];

    $startdate = $_POST['startdate'];

    $enddate = $_POST['enddate'];

    $count = count($sliderItems);

    for ($i=0 ;$i < $count;$i++)
    {
        if ($sliderItems[$i] != ''):

            $new[$i]['sliderItemImage'] = stripslashes($sliderItems[$i]);
            $new[$i]['sliderStartDate'] = stripslashes($startdate[$i]);
            $new[$i]['sliderEndDate'] = stripslashes($enddate[$i]);

        endif;
    }
    update_post_meta($post_id, 'slider_image_group', $new);


    if (!empty($new) && $new != $old) update_post_meta($post_id, 'slider_image_group', $new);

    elseif (empty($new) && $old) delete_post_meta($post_id, 'slider_image_group', $old);
}

