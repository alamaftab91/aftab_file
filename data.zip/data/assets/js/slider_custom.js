$ = jQuery;
$(function() {

  $('.datepicker').datepicker();

  $('#add-row').click(function() {

    var name = 'date_' + ($('.datepicker').length + 1);

    // APPEND NEW DATE AND BIND IT AT THE SAME TIME
    //$(".addmoredate").clone().insertAfter(".addmoredate");
    $('.addmoredate').append('<a href="#" class="epic-upl" >Upload Image</a><input type="hidden" name="slider-img[]" value="">')

    $('.addmoredate').append('<div class="startdate">Start Date').append(
      $('<input/>', {name: 'startdate[]', type: 'text',placeholder:'mm/dd/yyyy', class: 'datepicker'}).datepicker()
    ).append('</div>');

    $('.addmoredate').append('<div class="enddate">End Date').append(
      $('<input/>', {name: 'enddate[]', type: 'text', placeholder:'mm/dd/yyyy', class: 'datepicker'}).datepicker()
    ).append('</div>');
  });
});


