jQuery(document).ready()
jQuery(window).load(function() {
  jQuery('.flexslider').flexslider({
    animation: "slide",
     slideshow: true,
     slideshowSpeed: 4000,
    //animationSpeed: 600,
  });
});