<?php

global $wpdb;

if(isset($_POST['save'])){

  $apiurl = $_POST['url'];
  $apiuser = $_POST['user'];
  $apipass = $_POST['pass'];
  $apitoken = $_POST['token'];
  $adminuser = $_POST['adminuser'];
  $adminpass = $_POST['adminpass'];

  $wpdb->insert( 'wp_api_detail', 
    array( 
    'api' => $apiurl,
    'client_username'=> $apiuser,
    'client_password'=> $apipass,
    'token'=> $apitoken,
    'admin_username'=> $adminuser,
    'admin_password'=> $adminpass
  ));
}
$results = $wpdb->get_results("SELECT * FROM wp_api_detail ORDER BY id DESC");

$api_id = $results[0]->id;
$api_url = $results[0]->api;
$api_token = $results[0]->token;
$api_user = $results[0]->client_username;
$api_pass = $results[0]->client_password;
$admin_user = $results[0]->admin_username;
$admin_pass = $results[0]->admin_password;

if($_GET['getid']){

  $wpdb->delete( 'wp_api_detail', array( 'id' => $_GET['getid'] ) );
  ?>
  <script>
  jQuery(document).ready( function() {
      window.location.href = "<?php echo get_admin_url();?>options-general.php?page=epicplugin";
  });
  </script>
  <?php
}

?>

<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__); ?>templates/css/form_style.css">
</head>
<body>

<h1>Loyalty Lane API</h1>

<div id="Loyaltylane">
 <?php  if($results== false){?>
  <form action="" method="post">
    <label for="api" id="api_head">Loyalty Lane API Endpoint<span style="color:rgb(255, 38, 0)">*</span></label>
    <input type="text" id="api" name="url" placeholder="Enter Your API EndPoint.." value="" autocomplete="off">
    <span style="color:red" id="apiError"></span><br>

    <label for="user" id="user_head">Client Username<span style="color:rgb(255, 38, 0)">*</span></label>
    <input type="text" id="user" name="user" placeholder="Enter Your Client Username.." value="" autocomplete="off">
    <span style="color:red" id="userError"></span><br>

    <label for="api" id="pass_head">Client Password<span style="color:rgb(255, 38, 0)">*</span></label>
    <input type="text" id="pass" name="pass" placeholder="Enter Your Client Password.." value="" autocomplete="off">
    <span style="color:red" id="passError"></span><br>

    <label for="adminuser" id="adminuser_head">Admin Username<span style="color:rgb(255, 38, 0)">*</span></label>
    <input type="text" id="adminuser" name="adminuser" placeholder="Enter Your Admin Username.." value="" autocomplete="off">
    <span style="color:red" id="adminuserError"></span><br>

    <label for="api" id="adminpass_head">Admin Password<span style="color:rgb(255, 38, 0)">*</span></label>
    <input type="text" id="adminpass" name="adminpass" placeholder="Enter Your Admin Password.." value="" autocomplete="off">
    <span style="color:red" id="adminpassError"></span><br>

    <label for="token" id="token_head">EpicSolutions ClientId</label>
    <input type="text" id="token" name="token" placeholder="Enter Your ClientId.." value="" autocomplete="off">
  
    <input type="submit" id="api_submit" onclick="return form_valid()" name="save" value="Submit">
  </form>
  <?php  }?>
  <?php if(!empty($results)){ ?>
<form action="" method="post">
    <label for="api" id="api_head">Loyalty Lane API Endpoint</label>
    <input type="text" id="api" name="url" value="<?php echo $api_url; ?>" autocomplete="off" disabled>

    <label for="api" id="user_head">Client Username</label>
    <input type="text" id="user" name="user" value="<?php echo $api_user ?>" autocomplete="off" disabled>

    <label for="api" id="pass_head">Client Password</label>
    <input type="text" id="pass" name="pass" value="<?php echo $api_pass ?>" autocomplete="off" disabled>

    <label for="adminuser" id="adminuser_head">Admin Username</label>
    <input type="text" id="adminuser" name="adminuser" value="<?php echo $admin_user; ?>" autocomplete="off" disabled>

    <label for="api" id="adminpass_head">Admin Password</label>
    <input type="text" id="adminpass" name="adminpass" value="<?php echo $admin_pass; ?>" autocomplete="off" disabled>

    <label for="token" id="token_head">EpicSolutions ClientId</label>
    <input type="text" id="token" name="token" value="<?php echo $api_token; ?>" autocomplete="off" disabled>
  
    <input type="submit" id="api_submit" formaction="<?php echo get_admin_url();?>options-general.php?page=epicplugin&getid=<?php echo $api_id; ?>" name="delete" value="Delete">
  </form>
  <?php }?>  
</div>

</body>
</html>

<script >
  function form_valid(){
    var count = true;
    var api = document.getElementById("api").value;
    var user = document.getElementById("user").value;
    var pass = document.getElementById("pass").value;
    var adminuser = document.getElementById("adminuser").value;
    var adminpass = document.getElementById("adminpass").value;

    if(api == ""){
      document.getElementById("apiError").innerHTML="Loyalty Lane API Endpoint is required.";
      count = false;
    }else{
      document.getElementById("apiError").innerHTML="";
    }
    if(user == ""){
      document.getElementById("userError").innerHTML="Client Username is required.";
      count = false;
    }else{
      document.getElementById("userError").innerHTML="";

    }
    if(pass == ""){
      document.getElementById("passError").innerHTML="Client Password is required.";
      count = false;
    }else{
      document.getElementById("passError").innerHTML="";
    }
    if(adminuser == ""){
      document.getElementById("adminuserError").innerHTML="Admin Username is required.";
      count = false;
    }else{
      document.getElementById("adminuserError").innerHTML="";
    }
    if(adminpass == ""){
      document.getElementById("adminpassError").innerHTML="Admin Password is required.";
      count = false;
    }else{
      document.getElementById("adminpassError").innerHTML="";
    }

    if(count==false){
      return count;       
    }else{
      return count;
    }
  }
</script>
