<?php/* Template Name: myclubmobile */ ?>

<div id="page-loader" class="loading">Loading&#8230;</div>
<div class="main container">
   <!---body conteent----->
    <div class="maincontent">
      <div class="welcomeUser text-center">
        <?php 
        include(plugin_dir_path(__FILE__).'loyalityLane/functions-mobile.php');
        
        if(!array_key_exists('accountid',$_SESSION)){
          if(isset($_COOKIE["member_login"])) {
            $remember = 'on';
            loyaltyLanLoginForMobileEditProfile($_COOKIE["member_login"],$_COOKIE["member_password"],$remember);
          }
        }  

        $enter = $_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName;

        if(!empty($enter)){
         echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login-mobile?logout=true&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>"; 
        }?>
     </div> 
         
<div id="Available"></div>

</div></div></div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/style.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/responsive.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/custom.css">
<script>
  $( document ).ready(function() {
   var myclubData = 'myclub-count-mobile';
    $(".couponsTab").hide();
    $("#colophon").hide();
    $(".header-container_wrap").hide();
    $(".sfsiplus_footerLnk").hide();
    $(".guidContent").hide();
    $(".saving-data").hide();
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getMyclubData', myclubData : myclubData},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data.output;
        $("#page-loader").hide(); 
      }
    });
 });
</script>