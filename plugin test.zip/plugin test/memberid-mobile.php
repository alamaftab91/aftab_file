<?php
/*Template Name: memberidmobile*/
?>

<div id="page-loader" class="loading">Loading&#8230;</div>
<div class="main container">
   <!---body conteent----->
  <div class="maincontent">
    <div id="Available"></div>
  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/style.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/responsive.css">
<script type="text/javascript" src="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/jquery-barcode.js"></script>
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/custom.css">

<script>
	$( document ).ready(function() {
    $(".couponsTab").hide();
		$("#colophon").hide();
		$(".faqavalaiblehide").hide();
		$(".header-container_wrap").hide();
		$("#page-loader").show();
		jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getMemberIdmobile'},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data;
				generateBarcode();
				$("#page-loader").hide();
			}
		});
  });

	function generateBarcode(){
    var value = $("#barcodeValue").val();
    var btype = $("input[name=btype]:checked").val();
    var renderer = $("input[name=renderer]:checked").val();

    var settings = {
      output:renderer,
      bgColor: $("#bgColor").val(),
      color: $("#color").val(),
      barWidth: $("#barWidth").val(),
      barHeight: $("#barHeight").val(),
      moduleSize: $("#moduleSize").val(),
      posX: $("#posX").val(),
      posY: $("#posY").val(),
      addQuietZone: $("#quietZoneSize").val()
    };
    if ($("#rectangular").is(':checked') || $("#rectangular").attr('checked')){
      value = {code:value, rect: true};
    }
    if (renderer == 'canvas'){
      clearCanvas();
      $("#barcodeTarget").hide();
      $("#canvasTarget").show().barcode(value, btype, settings);
    } else {
      $("#canvasTarget").hide();
      $("#barcodeTarget").html("").show().barcode(value, btype, settings);
    }
  }
          
  function showConfig1D(){
    $('.config .barcode1D').show();
    $('.config .barcode2D').hide();
  }
      
  function showConfig2D(){
    $('.config .barcode1D').hide();
    $('.config .barcode2D').show();
  }
      
  function clearCanvas(){
    var canvas = $('#canvasTarget').get(0);
    var ctx = canvas.getContext('2d');
    ctx.lineWidth = 1;
    ctx.lineCap = 'butt';
    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle  = '#000000';
    ctx.clearRect (0, 0, canvas.width, canvas.height);
    ctx.strokeRect (0, 0, canvas.width, canvas.height);
  }

  $(function(){
    $('input[name=btype]').click(function(){
      if ($(this).attr('id') == 'datamatrix') showConfig2D(); else showConfig1D();
    });
    $('input[name=renderer]').click(function(){
      if ($(this).attr('id') == 'canvas') $('#miscCanvas').show(); else $('#miscCanvas').hide();
    });
    generateBarcode();
  });
</script>     
