<?php

$pages = array(
  $rewards_browser = array(
    'author_id' => 1,
    'title' => 'Rewards',
    'tpl' => 'rewardsTemplate.php',
    'option' => 'rewards_epic',
  ),
  $login_browser = array(
    'author_id' => 1,
    'title' => 'Login',
    'tpl' => 'loginTemplate.php',
    'option' => 'login_epic',
  ),
  $signup_browser = array(
    'author_id' => 1,
    'title' => 'Register-an-account',
    'tpl' => 'signup.php',
    'option' => 'signup_epic',
  ),
  $reward_special_browser = array(
    'author_id' => 1,
    'title' => 'Reward-Special',
    'tpl' => 'reward_specialTemplate.php',
    'option' => 'special_epic',
  ),
  $forget_password_browser = array(
    'author_id' => 1,
    'title' => 'Forget-Password',
    'tpl' => 'Forget_Password.php',
    'option' => 'forget_epic',
  ),
  $reset_password_browser = array(
    'author_id' => 1,
    'title' => 'Reset-Password',
    'tpl' => 'password_resetTemplate.php',
    'option' => 'reset_epic',
  ),
  $frequent_browser = array(
    'author_id' => 1,
    'title' => 'FAQs',
    'tpl' => 'faqTemplate.php',
    'option' => 'faq_page_epic',
  ),
  $rewards_mobile = array(
    'author_id' => 1,
    'title' => 'Rewards-home-Mobile',
    'tpl' => 'rewards-mobile.php',
    'option' => 'rewards_mobile_epic',
  ),
  $login_mobile = array(
    'author_id' => 1,
    'title' => 'Login-Mobile',
    'tpl' => 'login-mobile.php',
    'option' => 'login_mobile_epic',
  ),
  $forget_mobile = array(
    'author_id' => 1,
    'title' => 'Forget-Password-Mobile',
    'tpl' => 'Forget_Password_mobile.php',
    'option' => 'forget_mobile_epic',
  ),
  $signup_mobile = array(
    'author_id' => 1,
    'title' => 'Signup-Mobile',
    'tpl' => 'signup-mobile.php',
    'option' => 'signup_mobile_epic',
  ),
  $reward_special_mobile = array(
    'author_id' => 1,
    'title' => 'Rewards-Special-Mobile',
    'tpl' => 'reward_specialMobile.php',
    'option' => 'special_mobile_epic',
  ),
  $myclub_mobile = array(
    'author_id' => 1,
    'title' => 'Myclub-Mobile',
    'tpl' => 'myclub-mobile.php',
    'option' => 'myclub_mobile_epic',
  ),
  $mymember_mobile = array(
    'author_id' => 1,
    'title' => 'Mymember-Mobile',
    'tpl' => 'memberid-mobile.php',
    'option' => 'member_mobile_epic',
  ),
  $editprofile_mobile = array(
    'author_id' => 1,
    'title' => 'Editprofile-Mobile',
    'tpl' => 'editprofile-mobile.php',
    'option' => 'profile_mobile_epic',
  ),
  $passwordreset_mobile = array(
    'author_id' => 1,
    'title' => 'Reset-password-Mobile',
    'tpl' => 'password_resetMobile.php',
    'option' => 'reset_mobile_epic',
  ),
);

foreach($pages as $pinfo){
 // print_r($pinfo);die();
  $author_id = $pinfo['author'];
  $title = $pinfo['title'];
  $tpl = $pinfo['tpl'];
  $option = $pinfo['option'];
  $page_id = wp_insert_post(array(
      'post_author' => $author_id,
      'post_title' => $title,
      'post_status' => 'publish',
      'post_type' => 'page',
    )
  );      
 update_post_meta($page_id, '_wp_page_template', $tpl);
 update_option($option, $page_id);
}
?>