<?php/*Template Name: editprofilemobile*/?>
<style>
.header-container_wrap{
display:none;
}
#colophon{
display:none;
}

</style>

<div id="page-loader" class="loading">Loading&#8230;</div>
<div class="main container">
   <!---body conteent----->
  <div class="maincontent">
             
      <div id="Available"></div>
    </div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/style.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/responsive.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/custom.css">
<script>
	$( document ).ready(function() {
        $("#page-loader").show();
		 jQuery.ajax({
			type: "POST",
			url : '<?php echo admin_url('admin-ajax.php'); ?>',
			data: {action : 'getEditProfileForMobile'},
			success:function( data ) {
				$('.serachCoupen').hide();
				document.getElementById('Available').innerHTML=data;
				$("#page-loader").hide();		
			}
		});

		 $(document).on("click", '#accountButton', function(e) { 
     if(formValidate()){
    var fname = $("#fname").val();
    var lname = $("#lname").val();
    var pcontact = $("#pcontact").val();
    var address = $("#address").val();
    var city = $("#city").val();
    var state = $('#state :selected').val();
    var zcode = $("#zcode").val();
    var dateData = $("#birthdate").val();
    var homestore = $('#homestore :selected').val();
    var shopperid = $("#shopper_id").val();

    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: { action : 'editProfileToSaveData', 'shopperid' : shopperid, 'firstname' : fname, 'lastname' : lname, 'mobilephone' : pcontact, 'streetaddress1' : address, 'city' : city, 'state' : state, 'zipcode' : zcode, 'birthdate' : dateData, 'homestore' : homestore},
      success:function( data ) {
        document.getElementById('successData').innerHTML=data;
        $("#page-loader").hide();
      }
    });
     }
  });
	function formValidate(){
    var count = true;
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var pcontact = document.getElementById("pcontact").value;
    var address = document.getElementById("address").value;
    var city = document.getElementById("city").value;
    var state = document.getElementById("state").value;
    var zcode = document.getElementById("zcode").value;
    var homestore = document.getElementById("homestore").value;
    if(fname==""){
      document.getElementById("fnameError").innerHTML="First Name is required.";
      document.documentElement.scrollTop = 450;
      count = false;
    }
    else{
      document.getElementById("fnameError").innerHTML="";
    }
    if(lname==""){
      document.getElementById("lnameError").innerHTML="Last Name is required.";
      document.documentElement.scrollTop = 450;
      count = false;
    }
    else{
      document.getElementById("lnameError").innerHTML="";
    }
    if(pcontact==""){
      document.getElementById("pcontactError").innerHTML="Phone Number is required.";
      document.documentElement.scrollTop = 450;
      count = false;
    }else if(!/^[0-9]+$/.test(pcontact)){
      document.getElementById("pcontactError").innerHTML="Phone Number must be numeric value.";
      document.documentElement.scrollTop = 450;
      count = false;
    }
    else{
      document.getElementById("pcontactError").innerHTML="";
    }
    if(address==""){
      document.getElementById("addressError").innerHTML="Address Number is required.";
      document.documentElement.scrollTop = 450;
      count = false;
    }else{
      document.getElementById("addressError").innerHTML="";
    }
    if(city==""){
      document.getElementById("cityError").innerHTML="City is required.";
      document.documentElement.scrollTop = 450;
      count = false;
    }
    else{
      document.getElementById("cityError").innerHTML="";
    }
    if(state==""){
      document.getElementById("stateError").innerHTML="State is required.";
      document.documentElement.scrollTop = 450;
      count = false;
    }else{
      document.getElementById("stateError").innerHTML="";
    }
    if(zcode==""){
      document.getElementById("zcodeError").innerHTML="Zip code is required.";
      document.documentElement.scrollTop = 450;
      count = false;
    }else if(zcode.length>5 || zcode.length<5){
      document.getElementById("zcodeError").innerHTML="Zip code must be five digit number.";
      document.documentElement.scrollTop = 450;
      count = false;
    }
    else{
      document.getElementById("zcodeError").innerHTML="";
    }
    if(homestore==""){
      document.getElementById("homestoreError").innerHTML="Home Store is required.";
      document.documentElement.scrollTop = 750;
      count = false;
    }else{
      document.getElementById("homestoreError").innerHTML="";
    }
    if(count==false){
      return count;       
    }else{
      return count;
    }
  }
    });
</script>