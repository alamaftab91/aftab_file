<?php

$rewards =array(
   get_option('rewards_epic'),
   get_option('login_epic'),
   get_option('signup_epic'),
   get_option('special_epic'), 
   get_option('forget_epic'),
   get_option('reset_epic'),
   get_option('faq_page_epic'),
   get_option('rewards_mobile_epic'),
   get_option('login_mobile_epic'),
   get_option('forget_mobile_epic'),
   get_option('signup_mobile_epic'),
   get_option('special_mobile_epic'),
   get_option('myclub_mobile_epic'),
   get_option('member_mobile_epic'),
   get_option('profile_mobile_epic'),
   get_option('reset_mobile_epic'),
);

foreach ($rewards as $value) {
	wp_delete_post($value);
}

?>