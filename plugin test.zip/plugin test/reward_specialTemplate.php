<?php /* Template Name: specialRewardPage */ 

include(plugin_dir_path(__FILE__).'loyalityLane/functions.php');
echo do_shortcode('[epic_header]');

$header = array(
 "ClientToken : ".CLIENT_TOKEN,
 "ShopperToken :".$_SESSION['ShopperToken'],
 "Content-Type : application/json"
);
$urlbalance = BASE_URL.'/Balance';
$offer_Value = requestToLL($urlbalance,"GET", $_POST, $header);
$reward_value = (object)$offer_Value->data->balances;
 
?>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/style.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/responsive.css">


<li class="nav-item myclubs" style="display:none;">
  <a id="reward-special-mobile" class="nav-link" href="javascript:void(0);" role="tab">My Clubs</a>
</li>
<!---- Home page start ----->
<div class="main container product-responsive">
<!---body conteent----->
  <div class="text-center">
    <h1 class="special" style="font-size:100px;"><strong>Reward Specials</strong></h1>
    <h3 class="redeem" style="line-height: 1.4em;"><strong>Redeem your Reward Points for these products!</strong></h3>
  </div>
  <div class="maincontent">
    <div class="row mt-3 faqavalaiblehide">  
      <div class="welcomeUser text-center">
        <?php
        if($_SESSION['loyalityLaneUserDetails'] != ''){
          if(!empty($_GET['tab'])){
            $mobileApp = substr($_GET['tab'],-6);
            if($mobileApp == 'mobile'){
              echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login?logout=true&tab=home-mobile&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>";
            }else{
              echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login?logout=true&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>";
            }    
          }else{
            echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login?logout=true&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>";
          }
        }else{
         echo ($_GET['tab'] == 'reward-special-mobile') ? '<a href="'.site_url().'/login/?tab=login-mobile" ><button  class="btn mb-3">Sign in</button></a>' : '<a href="'.site_url().'/login" ><button  class="btn mb-3">Sign in</button></a>';
        }

        ?>
      </div>
    </div>
    <?php
    $isLoggedIn = false;
    if(array_key_exists('accountid',$_SESSION)){
      $isLoggedIn = true;
    }
    if($isLoggedIn){ ?>
      <div class="col-md-8 text-md-right">
         <div class="userreward myreward" style="margin-right:25px;">
            My Reward Points: <?php foreach($reward_value as $reward){ if($reward->BalanceDescription=='Points Balance'){ echo $reward->BalanceAmount; } }?>
         </div>
      </div>  
    <?php } ?>
   <?php the_content(); ?>      
  </div>   
<!---body conteent end----->
</div>
