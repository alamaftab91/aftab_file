<?php /* couponssignuppage */
error_reporting(0);
include(plugin_dir_path(__FILE__).'loyalityLane/functions.php');
echo do_shortcode('[epic_header]');

$url = BASE_URL.'/Store?showDisabled=true';
$response = requestToLL($url,"GET");
$homestore = (object)$response->data->stores;

$state_url = BASE_URL.'/States';
//print_r($state_url);
$response = requestToLL($state_url,"GET");
$states = (object)$response->data->states;
?>
<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
<script type="text/javascript" src="http://flesler-plugins.googlecode.com/files/jquery.scrollTo-1.4.2.js"></script>


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/style.css">
  <link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/responsive.css">
<!---- Signup page start ----->
<section class="registerPage">
    	<div class="container">
    		<div class="registerSec">
    			<div class="row">
    			<div class="col-md-10 col-offset-2 m-auto">	
				<?php
                     if(!empty($_SESSION['successMsg']))
                     {
                        
                        echo "<center><span class='alert alert-success' style='color:Green'>".$_SESSION['successMsg']."</span></center><br>";
                        unset($_SESSION['successMsg']);
                     } 
                     else 
                     {
                        if(!empty($_SESSION['errorMsg'])){
							$valid = $_SESSION['errorMsg'];
							$break = explode(' ',$valid);
							$dupli_error = $break[3];
							if($dupli_error == 'Duplicate'){
								echo "<center><span class='alert alert-danger' style='color:red'>".'Account already exists,Please Sign in'."</span></center> <br>";
						  unset($_SESSION['errorMsg']);
							}else{
                             echo "<center><span class='alert alert-danger' style='color:red'>".$_SESSION['errorMsg']."</span></center> <br>";
						     unset($_SESSION['errorMsg']);
						  }
                        }
                     }
                 ?>
    			<h3 style="font-size:20px" class="mb-5">Create a New Account</h3>
         		<form role="search" method="post" class="w-100" action="" id="commentForm">
				 
    				<div class="row">
    					<div class="form-group col-md-6">
							<label>First Name<span style="color:rgb(255, 38, 0)">*</span> <span class="reqOp">REQUIRED</span></label>
							<input type="hidden" name="register-coupon" value="">
							<input type="" name="firstname" value="<?php echo $_POST['firstname']?>" class="form-control" id="fname">
							<span style="color:red" id="fnameError"></span>
    					</div>
    					<div class="form-group col-md-6">
    						<label>Last Name<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
							<input type="" name="lastname"  value="<?php echo $_POST['lastname']?>" class="form-control" id="lname">
							<span style="color:red" id="lnameError"></span>
    					</div>
    					<div class="form-group col-md-12">
    						<label>Phone Number<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
							<input type="" name="mobilephone"  value="<?php echo $_POST['mobilephone']?>" class="form-control" id="pcontact">
							<span style="color:rgb(255, 0, 0)" id="pcontactError"></span>
    					</div>
    					<div class="form-group col-md-10">
    						<label>Address<span style="color:rgb(255, 0, 0)">*</span> <span class="reqOp">REQUIRED</span></label>
							<input type="" name="streetaddress1" value="<?php echo $_POST['streetaddress1']?>" class="form-control" id="address">
							<span style="color:red" id="addressError"></span>
    					</div>
    					<div class="form-group col-md-2">
    						<label>Unit</label>
    						<input type="" name="streetaddress2" value="<?php echo $_POST['streetaddress2']?>" class="form-control" id="unit">
    					</div>
    					<div class="form-group col-md-6">
    						<label>City<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
							<input type="" name="city" value="<?php echo $_POST['city']?>" class="form-control" id="city">
							<span style="color:red" id="cityError"></span>
    					</div>
    					<div class="form-group col-md-3">
    						<label>State<span style="color:red">*</span></label>
							
							<select name="state" class="form-control" id="state">
								<option value="">--Select States--</option>
								<?php foreach($states as $state){ ?>
								<option value="<?php echo $state->Abbreviation; ?>"><?php echo $state->FullName; ?></option>
								<?php } ?>
							</select>
							<span style="color:red" id="stateError"></span>
    					</div>
    					<div class="form-group col-md-3">
    						<label>Zip Code<span style="color:red">*</span></label>
							<input type="" name="zipcode" value="<?php echo $_POST['zipcode']?>" class="form-control" id="zcode">
							<span style="color:red" id="zcodeError"></span>
    					</div>
    					<div class="form-group col-md-12">
    						<label>Email<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
							<input type="" name="email" value="<?php echo $_POST['email']?>" class="form-control" id="email">
							<span style="color:red" id="emailError"></span>
    					</div>
						
						<div class="form-group col-md-6">
							<label>Password<span style="color:rgb(255, 38, 0)">*</span> <span class="reqOp">REQUIRED</span></label>
							<input type="password" name="password" class="form-control" id="password" class="form-control">
							<span style="color:red" id="passwordError"></span>
    					</div>
    					<div class="form-group col-md-6">
    						<label>Confirm Password<span style="color:red">*</span> <span class="reqOp">REQUIRED</span></label>
							<input type="password" name="cnf_pass" class="form-control" id="cnf_pass">
							<span style="color:red" id="cnf_passError"></span>
    					</div>
						<div class="form-group col-md-6">
    						<label>Birthday <span class="reqOp">REQUIRED</span></label>
							<input type="date" name="birthdate" class="form-control" id="birthdate" max= "<?php echo date("Y-m-d"); ?>">
							<span style="color:red" id="birthdateError"></span>
						</div>
						<div class="form-group col-md-6">
    						<label>Home Store <span class="reqOp">REQUIRED</span></label>
							<select name="homestore" id="homestore" class="form-control">
							<option value="">-------- Select Home Store --------</option>
							<?php foreach($homestore as $store){ ?>
							<option value="<?php echo $store->ID; ?>"><?php echo $store->StoreName; ?></option>
							<?php } ?>
							</select>
							<span style="color:red" id="homestoreError"></span>
    					</div>

    					 <!-- <div class="form-group col-md-12 subtext">
    						<h2>Email Subscription</h2>
    						<p>Subscribe to our email by checking the box below.</p>
    						<div class="pl-3">
    						<input type="checkbox" class="form-check-input" id="alret">
						    <label class="form-check-label" for="alret">Weekly ad alret</label>
						    </div>
    					</div> -->
    					<div class="form-group col-md-12">
    						<div class="subtReg text-right">
    							<button name="register-coupon" class="btn" id="accountButton" onclick="return form_valid()">Save Account</button>
    						</div>
    					</div>
    					<div class="col-md-12">
    						   <hr>
    					</div>
    					<div class="col-md-12 text-center">
						<?php if($_GET['tab'] == 'signup-mobile'){ ?>
    						<p>Already have an account? <a href="<?php echo site_url()?>/login/?tab=login-mobile">Login</a></p>
                        <?php 
                       }else{ ?>
							<p>Already have an account? <a href="<?php echo site_url()?>/login">Login</a></p>
						<?php }
						?>    
    					</div>
    				</div>
    			</form>
    		</div>
    		</div>
    		</div>
    	</div>
	</section>
	<script>
     function form_valid(){
		var count = true;
		var fname = document.getElementById("fname").value;
		var lname = document.getElementById("lname").value;
		var pcontact = document.getElementById("pcontact").value;
		var address = document.getElementById("address").value;
		var city = document.getElementById("city").value;
		var state = document.getElementById("state").value;
		var zcode = document.getElementById("zcode").value;
		var email = document.getElementById("email").value;
		var password = document.getElementById("password").value;
		var cnf_pass = document.getElementById("cnf_pass").value;
		var homestore = document.getElementById("homestore").value;
		var filter = /^([a-zA-Z])+([a-zA-Z0-9_.+-])+\@(([a-zA-Z])+\.+?(com|co|in|org|net|edu|info|gov|vekomy))\.?(com|co|in|org|net|edu|info|gov)?$/;
		var charValue = /^[a-zA-Z]*$/;
		
		if(fname==""){
			document.getElementById("fnameError").innerHTML="First Name is required.";
			document.documentElement.scrollTop = 450;
			count = false;
		}
		else if(!fname.match(/^[a-zA-Z]+$/)){
			document.getElementById("fnameError").innerHTML="First Name should be in character.";
			document.documentElement.scrollTop = 450;
			count = false;
		}
		else{
            document.getElementById("fnameError").innerHTML="";
		}
		if(lname==""){
			document.getElementById("lnameError").innerHTML="Last Name is required.";
			document.documentElement.scrollTop = 450;
			count = false;
		}else if(!lname.match(/^[a-zA-Z]+$/)){
			document.getElementById("lnameError").innerHTML="Last Name should be in character.";
			document.documentElement.scrollTop = 450;
			count = false;
		}
		else{
            document.getElementById("lnameError").innerHTML="";
		}
		if(pcontact==""){
			document.getElementById("pcontactError").innerHTML="Phone Number is required.";
			document.documentElement.scrollTop = 450;
			count = false;
		}else if(!/^[0-9]+$/.test(pcontact)){
			document.getElementById("pcontactError").innerHTML="Phone Number must be numeric value.";
			document.documentElement.scrollTop = 450;
			count = false;
		}
		else{
            document.getElementById("pcontactError").innerHTML="";
		}
		if(address==""){
			document.getElementById("addressError").innerHTML="Address Number is required.";
			document.documentElement.scrollTop = 450;
			count = false;
		}else{
            document.getElementById("addressError").innerHTML="";
		}
		if(city==""){
			document.getElementById("cityError").innerHTML="City is required.";
			document.documentElement.scrollTop = 450;
			count = false;
		}else{
            document.getElementById("cityError").innerHTML="";
		}
		if(state==""){
			document.getElementById("stateError").innerHTML="State is required.";
			document.documentElement.scrollTop = 450;
			count = false;
		}else{
            document.getElementById("stateError").innerHTML="";
		}
		if(zcode==""){
			document.getElementById("zcodeError").innerHTML="Zip code is required.";
			document.documentElement.scrollTop = 450;
			count = false;
		}else if(zcode.length>5 || zcode.length<5){
			document.getElementById("zcodeError").innerHTML="Zip code must be five digit number.";
			document.documentElement.scrollTop = 450;
			count = false;
		}
		else{
            document.getElementById("zcodeError").innerHTML="";
		}
		if(email==""){
			document.getElementById("emailError").innerHTML="Email is required.";
			document.documentElement.scrollTop = 750;
			count = false;
		}else{
            document.getElementById("emailError").innerHTML="";
		}
		if(password==""){
			document.getElementById("passwordError").innerHTML="Password is required.";
			document.documentElement.scrollTop = 750;
			count = false;
		}else{
            document.getElementById("passwordError").innerHTML="";
		}
		if(cnf_pass==""){
			document.getElementById("cnf_passError").innerHTML="Confirm Password is required.";
			document.documentElement.scrollTop = 750;
			count = false;
		}else{
            document.getElementById("cnf_passError").innerHTML="";
		}
		if(homestore==""){
			document.getElementById("homestoreError").innerHTML="Home Store is required.";
			document.documentElement.scrollTop = 750;
			count = false;
		}else{
            document.getElementById("homestoreError").innerHTML="";
		}
		
		if(count==false){
			return count;				
		}else{
			return count;
		}
	 }
    </script>