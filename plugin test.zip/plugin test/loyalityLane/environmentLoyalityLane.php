<?php
// error_reporting(0);

if(!session_id()) {
    session_start();
}
global $wpdb;
$results = $wpdb->get_results("SELECT * FROM wp_api_detail ORDER BY id DESC");
$api_url = $results[0]->api;
$client_user = $results[0]->client_username;
$client_pass = $results[0]->client_password;
$admin_user = $results[0]->admin_username;
$admin_pass = $results[0]->admin_password;

define("BASE_URL", $api_url);

//ClientSession Token

$urlClientSession = BASE_URL.'/ClientSession';
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $urlClientSession,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'username='.$client_user.'&password='.$client_pass.'',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded',
    //'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000b0210ac00005000'
  ),
));
        
$responseData1 = curl_exec($curl);
curl_close($curl);
$token = json_decode($responseData1);
$clie_token =  $token->data->ClientToken;


 //AdminSession Token

$urlAdminSession = BASE_URL.'/AdminSession';
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => $urlAdminSession,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'clientusername='.$client_user.'&clientpassword='.$client_pass.'&adminusername='.$admin_user.'&adminpassword='.$admin_pass.'',
    CURLOPT_HTTPHEADER => array(
     'Content-Type: application/x-www-form-urlencoded',
    ),
));

$responsedata2 = curl_exec($curl);
curl_close($curl);
$token1 = json_decode($responsedata2);
$admin_token =  $token1->data->ClientToken;

if(!empty($clie_token)){
    $client = $clie_token;
}else{
    $client = $admin_token;
}


define("CLIENT_TOKEN",$client);

define("ADMIN_TOKEN", $admin_token);

?>