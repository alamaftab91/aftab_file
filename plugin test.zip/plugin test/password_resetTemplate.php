<?php /* Template Name: Reset Password*/
include(plugin_dir_path(__FILE__).'loyalityLane/functions.php');
?>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/style.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/responsive.css">
<!---- Forget page start ----->
<section class="loginPage">
   <div class="container">
      <div class="logSec">
      <?php
        if(!empty($_SESSION['errorMsg']))
        {
         echo "<center><span class='alert alert-danger' style='color:red'>".$_SESSION['errorMsg']."</span></center> <br>";
         unset($_SESSION['errorMsg']);
         ?>
         <style>
         .m-auto{
            display:none;
         }
         </style>
         <?php
        }    
      ?>
         <div class="row">
         
         <div class="col-md-10 col-offset-2 m-auto">
          <form role="search" method="POST" class="w-100" action="">
                
               <div class="col-md-6 m-auto">
     
                  <div class="formTitle">                    
                    <h2 class="loginText">Reset Password</h2>
                  </div>
                  <div class="form-group row mb-3">
                     <label for="" class="col-sm-4 col-form-label">New Password<span style="color:red">*</span></label>
                      <div class="col-sm-8">
                        <input type="hidden" name="shopperid" value="<?php echo $_POST['shopperid']; ?>">
                        <input type="hidden" name="token" value="<?php echo $_POST['token']; ?>">
                        <input type="password" class="form-control" name="newpass" id="newpass">
                        <span style="color:red" id="newpassError"></span>
                      </div>
                  </div>
                  <div class="form-group row mb-3">
                     <label for="" class="col-sm-4 col-form-label">Confirm Password<span style="color:red">*</span></label>
                      <div class="col-sm-8">
                        <input type="password" class="form-control" name="password" id="password">
                        <span style="color:red" id="passwordError"></span>
                      </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-md-12 signBtn text-center">
                      <button class="btn" type="submit" name="resetpass" onclick="return form_valid()">Submit</button>
                    </div>
                  </div>
                  <div class="col-md-12">
    						   <hr>
    					</div>
    					<div class="col-md-12 text-center">
    						<p>Already have an account? <a href="<?php echo site_url();?>/login">Login</a></p>
    					</div>
                  <div class="copyContent">
                    <p>&#169; 2020 Loyalty Lane, Inc V.3.63.21</p>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</section>
<script>
  function form_valid(){
    var count = true;
    var newpass = document.getElementById("newpass").value;
	  var password = document.getElementById("password").value;
    if(newpass==""){
  		document.getElementById("newpassError").innerHTML="New Password is required.";
  		document.documentElement.scrollTop = 450;
  		count = false;
	  }else{
     document.getElementById("newpassError").innerHTML="";
	  }
		if(password==""){
			document.getElementById("passwordError").innerHTML="Confirm password is required.";
			document.documentElement.scrollTop = 450;
			count = false;
		}else{
     document.getElementById("passwordError").innerHTML="";
		}
    if(count==false){
			return count;				
		}else{
			return count;
		}
  }
</script>        