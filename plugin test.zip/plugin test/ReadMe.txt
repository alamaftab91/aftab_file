
Click on plugin setting the enter your credential.

Example For API Credential:-

API URL should be small letter.
Url exp:- xxxxxxx/webapi/api
client username:- 
client password:- 
admin usename:- 
admin password:- 



Browser Page:-

Rewards               :- Home Page
Register-an-account   :- Signup Page
Login                 :- Sign in page
Forget Password       :- Forget Password
Reward Special        :- Reward-Special
Reset Password        :- Reset password
FAQ                   :- FAQs (Enter your detail through admin panel)


Mobile page:-

rewards-home-mobile       :- rewards home page
mymember-mobile           :- member id page
myclub-mobile             :- myclub rewards
editprofile-mobile        :- Edit Profile
reward-special-mobile     :- reward special
forget-password-mobile    :- forget password
signup-mobile             :- signup page


Example for mobile pages:- 

https://xxxxxxxx.com/rewards-home-mobile
https://xxxxxxxx.com/editprofile-mobile
https://xxxxxxxx.com/myclub-mobile
https://xxxxxxxx.com/mymember-mobile
