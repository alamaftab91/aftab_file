<?php
global $wp;
$smtpdetail = get_option('wp_smtp_options'); 
$from_smtp = $smtpdetail['from'];

include('environmentLoyalityLane.php');
    //login method request passed here 
    if (isset($_POST['digital-login']))
    {
        loyaltyLanLogin($_POST['username'],$_POST['password'],$_POST["remember"]);
    }

    function loyaltyLanLogin($username, $password,$remember)    
    {
        
        $post = [];
        $post = array('username' => $username,'password' => $password);

        $url = BASE_URL.'/ShopperSession';
        
        $response = requestToLL($url,"POST", $post);
        if($response->data->isfulllogin){

            $url = BASE_URL.'/Shopper?shopperid='.$response->data->shopperid;
            $header = array(
                "ClientToken : ".CLIENT_TOKEN,
                "ShopperToken :".$response->data->token,
                "Content-Type : application/json"
            );
            
            $balanceUrl = BASE_URL.'/Balance?accountid='.$response->data->accountid;

            $userResponse = requestToLL($url,"GET", $post, $header);
            
            $_SESSION['loyalityLaneUserDetails'] = $userResponse;

            $_SESSION['ShopperToken'] = $response->data->token;
            $_SESSION['accountid'] = $response->data->accountid;
            $_SESSION['shopperid'] = $response->data->shopperid;

            //print_r($_POST["remember"]);die();
            if($remember == 'on') {
                $_SESSION['member_login'] = $username;
                $_SESSION['member_password'] = $password;
            } 
           
            unset($_SESSION['errorMsg']);
            if($_GET['tab'] == 'login-mobile'){
                echo "<script>window.location.href='".site_url()."/rewards/?tab=home-mobile'</script>";
            }else{
                echo "<script>window.location.href='".site_url()."/rewards'</script>";
            }
            

        } else {
            $_SESSION['errorMsg'] = $response->message;
        }
    }

    // when we click on the register button this method wil call 
    if (isset($_POST['register-coupon']))
    {
        $url = BASE_URL.'/FullAccount'; // loyalty lane url where we are going to request for a new account
        $_POST['registered'] = true;
        $_POST['istestaccount'] = true;
        if($_POST['password']==$_POST['cnf_pass'])
        {
        $response = requestToLL($url,"POST", $_POST); // execute the CURL operation
      
            if($response->result=='OK'){
                
                $_SESSION['successMsg'] = $response->message;
                if($_GET['tab'] == 'signup-mobile'){
                    echo "<script> window.location.href='".site_url()."/login/?tab=login-mobile&success=1'</script>";
                }else{
                    echo "<script> window.location.href='".site_url()."/login?success=1'</script>";
                }
            }else{
                $_SESSION['errorMsg'] = $response->message;
           }
        }
        else{
            $_SESSION['errorMsg'] = 'Your password and confirm password is not matching..';
        }
    }
    //logout method used here
    if (isset($_GET['logout'])){
        if ($_GET['token']==$_SESSION['ShopperToken'])
        {
            session_unset();  
            if($_GET['tab'] == 'home-mobile'){
                echo "<script> window.location.href='".site_url()."/rewards/?tab=home-mobile'</script>";
            }else{
                echo "<script> window.location.href='".site_url()."/rewards'</script>";
            }
            
        }
    } 

    if (isset($_POST['contactInfo'])) {
        
        $postPasswordUrl = BASE_URL.'/PasswordResetToken';
        $getPasswordUrl = BASE_URL.'/PasswordResetToken?contactInfo='.$_POST['contactInfo'];
        $response = requestToLL($getPasswordUrl,"GET");
        
        if ($response->result == 'OK') {
            //echo returnMessage('success','Please click here to change your password.'.
            $siteUrl = site_url()."/reset-password?nonce=".$response->data->password_reset_details->nonce;
            //$url = "";

            $from = $from_smtp;
            $to = $_POST['contactInfo'];
            $subject = "Reset Password Link";
            $headers = "From: " . strip_tags($from) . "\r\n"; 
            $headers .= "CC: ramm2@chetu.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            $txt = "<html><body><a href=".$siteUrl.">click here</a> to change your password.</body></html>";
            mail($to,$subject,$txt,$headers);
            echo "<center><b style='color:green;'>Password reset link has been sent to your email address. Please follow link and reset  your password.</b></center>";
            ?>
            <style>
            .m-auto{
                display:none;
            }
            </style>
            <?php
        } else {
            echo returnMessage('error','Entered email id is not correct. Please check and try again');
        }     
    } 

    if(wp_parse_url($wp->request)['path'] == 'reset-password'){
        
        if (isset($_POST['resetpass'])) {
            if($_POST['password'] != $_POST['newpass']){
                $_SESSION['errorMsg'] = 'Your password do not match..';
                echo "<script> window.location.href='".site_url()."/reset-password'</script>";
            }else{
                $response_data = updatePassword($_POST['shopperid'],$_POST['password'],$_POST['token']);
                $ff = json_decode($response_data, true);
                            
                if($ff['result'] == "OK"){
                    $_SESSION['successMsg'] = 'Your password reset successfully...';
                    
                    echo "<script> window.location.href='".site_url()."/login'</script>";
            }
          }
        }
       else{
        if(!empty($_GET['nonce'])){
            $url = BASE_URL.'/PasswordResetToken';
            $response = requestToLL($url, 'POST', $_GET);

            if($response->result == "OK"){
                $_POST['shopperid'] = $response->data->shopperid;
                $_POST['token']     = $response->data->token;
                $_SESSION['errorMsg'] = '';
            } 
            else {
                $_SESSION['errorMsg'] = 'Your Token Expired Try again.';

            }
        }
      }
    }

    

function requestToLL($url, $method, $data=array(),$header = array("ClientToken: ".CLIENT_TOKEN,"Content-Type: application/json")){

    $submissionData = '{';
    $sets = array();
    if (array_key_exists('couponidlist', $_POST)) {
        foreach($data as $column => $value){
            if($value != ""){
                $sets[] = "'".$column."'".":".$value;
            }
        } 
    } else {
        foreach($data as $column => $value){
            if($value != ""){
                $sets[] = "'".$column."'".":"."'".$value."'";
            }
        }
    }
    $submissionData .= implode(",", $sets);
    $submissionData .= "}";
    $curl = curl_init();
    $curlArray = [];
    if($method == "POST"){
        $curlArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,                     
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_POSTFIELDS => $submissionData,
            CURLOPT_HTTPHEADER => $header,
        );
    }
    elseif($method == "PUT"){
        $curlArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_POSTFIELDS => $submissionData,
            CURLOPT_HTTPHEADER => $header,
        );
    }
     else {
        $curlArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $header,
        );
    }
    curl_setopt_array($curl, $curlArray );
    $response = curl_exec($curl);
    curl_close($curl);
    $res = json_decode($response);
   
    return $res;
}

function returnMessage($type, $message) {
    $messageOuterHtml='<p class=" '. $type .'returnMessageContainer">'.$message.'</p>';
    return $messageOuterHtml;
}

function updatePassword($id, $pass, $token){
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => BASE_URL.'/Shopper',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'PUT',
      CURLOPT_POSTFIELDS =>'{"shopperid":"'.$id.'","password":"'.$pass.'"}',
      CURLOPT_HTTPHEADER => array(
        'ClientToken: '.CLIENT_TOKEN,
        'ShopperToken: '.$token,
        'Content-Type: application/json',
        'Cookie: BNI_BARRACUDA_LB_COOKIE=0000000000000000000000000d0210ac00005000'
      ),
    ));
    
    $response = curl_exec($curl);
    
    curl_close($curl);
    return $response;
    
}
?>
