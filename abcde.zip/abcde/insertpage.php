<?php

//forget Password page
$forget_pass = array(
   'post_type'     => 'page',
   'post_title'    => 'Forget Password',
   //'post_content'  => 'This is my post.',
   'post_status'   => 'publish',
   'post_author'   => 1,
 );

$forget_id= wp_insert_post( $forget_pass );
 if ($forget_id) {
       
        update_post_meta($forget_id, '_wp_page_template', 'Forget_Password.php');
		update_option('forget_pass_teet',$forget_id);
}

//signup page
$Signup_page = array(
   'post_type'     => 'page',
   'post_title'    => 'Register-An-Account',
   //'post_content'  => 'This is my post.',
   'post_status'   => 'publish',
   'post_author'   => 1,
 );

$signup_id= wp_insert_post( $Signup_page );
 if ($signup_id) {
       
        update_post_meta($signup_id, '_wp_page_template', 'signup.php');
		update_option('signup_page_teet',$signup_id);
}

//login page

$login_page = array(
   'post_type'     => 'page',
   'post_title'    => 'Login',
   //'post_content'  => 'This is my post.',
   'post_status'   => 'publish',
   'post_author'   => 1,
 );

$login_id= wp_insert_post( $login_page );
 if ($login_id) {
       
        update_post_meta($login_id, '_wp_page_template', 'loginTemplate.php');
		update_option('login_page_teet',$login_id);
}

//Rewards home Page
$rewards_page = array(
   'post_type'     => 'page',
   'post_title'    => 'Rewards',
   //'post_content'  => 'This is my post.',
   'post_status'   => 'publish',
   'post_author'   => 1,
 );

$rewards_id= wp_insert_post( $rewards_page );
 if ($rewards_id) {
       
    update_post_meta($rewards_id, '_wp_page_template', 'rewardsTemplate.php');
		update_option('rewards_page_teet',$rewards_id);
}

//Reset Password
$reset_password_page = array(
   'post_type'     => 'page',
   'post_title'    => 'Reset Password',
   //'post_content'  => 'This is my post.',
   'post_status'   => 'publish',
   'post_author'   => 1,
 );

$reset_id= wp_insert_post( $reset_password_page );
 if ($reset_id) {
       
    update_post_meta($reset_id, '_wp_page_template', 'password_resetTemplate.php');
		update_option('reset_page_teet',$reset_id);
}


//special rewards
$rwrads_special_page = array(
   'post_type'     => 'page',
   'post_title'    => 'Reward Special',
   //'post_content'  => 'This is my post.',
   'post_status'   => 'publish',
   'post_author'   => 1,
 );

$special_id= wp_insert_post( $rwrads_special_page );
 if ($special_id) {
       
        update_post_meta($special_id, '_wp_page_template', 'reward_specialTemplate.php');
		update_option('special_rewrads_page_teet',$special_id);
}

//faq page
$faq_page = array(
   'post_type'     => 'page',
   'post_title'    => 'FAQ',
   //'post_content'  => 'This is my post.',
   'post_status'   => 'publish',
   'post_author'   => 1,
 );

$faq_id= wp_insert_post( $faq_page );
 if ($faq_id) {
       
        update_post_meta($faq_id, '_wp_page_template', 'faqTemplate.php');
    update_option('faq_page_teet',$faq_id);
}


?>