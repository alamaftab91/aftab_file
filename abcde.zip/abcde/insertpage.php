<?php
//Insert Page using 

//Rewards Page

$rewards_epic = array(
        'post_title' => 'Rewards',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_type' => 'page',
    );
$rewards_id = wp_insert_post($rewards_epic);
if ($rewards_id) {
    update_post_meta($rewards_id, '_wp_page_template', 'rewardsTemplate.php');
    update_option( 'rewards_epic', $rewards_id );
}

//Login Page

$login_epic = array(
        'post_title' => 'Login',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_type' => 'page',
    );
$login_id = wp_insert_post($login_epic);
if ($login_id) {
    update_post_meta($login_id, '_wp_page_template', 'loginTemplate.php');
    update_option( 'login_epic', $login_id );
}

//Signup Page
$signup_epic = array(
        'post_title' => 'Register-an-account',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_type' => 'page',
    );
$signup_id = wp_insert_post($signup_epic);
if ($signup_id) {
    update_post_meta($signup_id, '_wp_page_template', 'signup.php');
    update_option( 'signup_epic', $signup_id );
}

//Reward Special Page

$reward_special_epic = array(
        'post_title' => 'Reward-Special',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_type' => 'page',
    );
$special_id = wp_insert_post($reward_special_epic);
if ($special_id) {
    update_post_meta($special_id, '_wp_page_template', 'reward_specialTemplate.php');
    update_option( 'special_epic', $special_id );
}

//Forget Password Page

$forget_password_epic = array(
        'post_title' => 'Forget Password',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_type' => 'page',
    );
$forget_id = wp_insert_post($forget_password_epic);
if ($forget_id) {
    update_post_meta($forget_id, '_wp_page_template', 'Forget_Password.php');
    update_option( 'forget_epic', $forget_id );
}

// Reset Password Page

$reset_password_epic = array(
        'post_title' => 'Reset Password',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_type' => 'page',
    );
$reset_id = wp_insert_post($reset_password_epic);
if ($reset_id) {
    update_post_meta($reset_id, '_wp_page_template', 'password_resetTemplate.php');
    update_option( 'reset_epic', $reset_id );
}

//Faq Page
$faq_page = array(
        'post_title' => 'FAQs',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_type' => 'page',
    );
$faq_id= wp_insert_post( $faq_page );
 if ($faq_id) {
       
    update_post_meta($faq_id, '_wp_page_template', 'faqTemplate.php');
    update_option('faq_page_teet',$faq_id);
}

?>