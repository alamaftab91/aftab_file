<?php /* couponsrewardspage */

error_reporting(0);
include(plugin_dir_path(__FILE__).'loyalityLane/functions.php');
echo do_shortcode('[epic_header]');

if(!array_key_exists('accountid',$_SESSION)){
   if(isset($_COOKIE["member_login"])) {
      $remember = 'on';
      loyaltyLanLogin($_COOKIE["member_login"],$_COOKIE["member_password"],$remember);
   }
}

$current_url = home_url(add_query_arg(array(), $wp->request));

   $header = array(
      "ClientToken : ".CLIENT_TOKEN,
      "ShopperToken :".$_SESSION['ShopperToken'],
      "Content-Type : application/json"
   );

   $isLoggedIn = false;
   if(array_key_exists('accountid',$_SESSION)){
      $isLoggedIn = true;

      $urlbalance = BASE_URL.'/Balance';

      $offer_Value = requestToLL($urlbalance,"GET", $_POST, $header);

      if($_GET['type'] == 'Available' || 'Clipped')
      {
            $urlAvailable = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];
            $respAvailable = requestToLL($urlAvailable,"GET");
         if($_GET['type'] == 'Clipped'){
            $url = BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'];
         }else{
            $url = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];   
         }
      } else if($_GET['type'] == 'Clipped'){
         $url = BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'];
      } else if($_GET['type'] == 'MyClubs'){
         $url = BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'];
         
      } else {
        echo "<script> window.location.href='".site_url()."/rewards?type=Available'</script>";
      }
      $response = requestToLL( BASE_URL.'/AvailableCoupon?accountid='.$_SESSION['accountid'],"GET"); // avl
      $countClipped = requestToLL(BASE_URL.'/ClippedCoupon?accountid='.$_SESSION['accountid'],"GET"); // clip
      $clippedCouponsValue  = (object)$countClipped->data->coupons;
      $_SESSION['countClipped'] = count($countClipped->data->coupons);
      
      $reward_value = (object)$offer_Value->data->balances;
      
      //echo $reward_value->BalanceAmount;
   } else {
      $url = BASE_URL.'/Coupon';
      
   }

   $response = requestToLL($url,"GET"); 
   $coupons_value = (object)$response->data->coupons;
   
   $totalAvailableSaving = 0;

   foreach($coupons_value as $data){
      preg_match('/\$([0-9]+[\.,0-9]*)/', $data->OfferSummaryTop, $match);
      $totalAvailableSaving += $match[1];
   }
   $totalClippedSaving = 0;
   foreach($clippedCouponsValue as $data){
      preg_match('/\$([0-9]+[\.,0-9]*)/', $data->OfferSummaryTop, $match);
      $totalClippedSaving += $match[1];
   }

   ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/style.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/responsive.css">
<style>
#img_data{
   display:none;
}
/* Absolute Center Spinner */
.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.loading:before {
  content: '';
  display: hide;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
    background: radial-gradient(rgba(20, 20, 20,.8), rgba(0, 0, 0, .8));

  background: -webkit-radial-gradient(rgba(20, 20, 20,.8), rgba(0, 0, 0,.8));
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}

.loading:not(:required):after {
  content: '';
  display: block;
  font-size: 10px;
  width: 1em;
  height: 1em;
  margin-top: -0.5em;
  -webkit-animation: spinner 150ms infinite linear;
  -moz-animation: spinner 150ms infinite linear;
  -ms-animation: spinner 150ms infinite linear;
  -o-animation: spinner 150ms infinite linear;
  animation: spinner 150ms infinite linear;
  border-radius: 0.5em;
  -webkit-box-shadow: rgba(255,255,255, 0.75) 1.5em 0 0 0, rgba(255,255,255, 0.75) 1.1em 1.1em 0 0, rgba(255,255,255, 0.75) 0 1.5em 0 0, rgba(255,255,255, 0.75) -1.1em 1.1em 0 0, rgba(255,255,255, 0.75) -1.5em 0 0 0, rgba(255,255,255, 0.75) -1.1em -1.1em 0 0, rgba(255,255,255, 0.75) 0 -1.5em 0 0, rgba(255,255,255, 0.75) 1.1em -1.1em 0 0;
box-shadow: rgba(255,255,255, 0.75) 1.5em 0 0 0, rgba(255,255,255, 0.75) 1.1em 1.1em 0 0, rgba(255,255,255, 0.75) 0 1.5em 0 0, rgba(255,255,255, 0.75) -1.1em 1.1em 0 0, rgba(255,255,255, 0.75) -1.5em 0 0 0, rgba(255,255,255, 0.75) -1.1em -1.1em 0 0, rgba(255,255,255, 0.75) 0 -1.5em 0 0, rgba(255,255,255, 0.75) 1.1em -1.1em 0 0;
}

/* Animation */

@-webkit-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@-moz-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@-o-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    -o-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    -moz-transform: rotate(360deg);
    -ms-transform: rotate(360deg);
    -o-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
 
      #config{
          overflow: auto;
          margin-bottom: 10px;
      }
      .config{
          float: left;
          width: 200px;
          height: 250px;
          border: 1px solid #000;
          margin-left: 10px;
      }
      .config .title{
          font-weight: bold;
          text-align: center;
      }
      .config .barcode2D,
      #miscCanvas{
        display: none;
      }
      #submit{
          clear: both;
      }
      #barcodeTarget,
      #canvasTarget{
        margin-top: 20px;
      }
    


      @media(max-width:992px){
         #barcodeTarget {
    margin-top: 20px;
    TOP: 0;
    BACKGROUND: white;
    WIDTH: 100%;
    HEIGHT: 100%;

}


        }
        @media only screen and (min-device-width: 320px) and (max-device-width: 767px){
.registerSec {
    padding: 0;

   
   }
   #barcodeTarget p {
    font-size: 39px !important;
}
   .maincontent {

    padding: 0px;
}

   span.alert.alert-success {
    font-size: 12px;
}
   .edit_pro{
      font-size: 18px;
   }
}


      @media(max-width:1199px){
         .couponsTab .nav-item{
            margin-bottom:10px;
         }
         .colorboxmain{
            height:80px;
         }
      }
      @media(max-width:1000px){ 
         .colorboxmain{
            height:75px;
         }
      }
      @media(max-width:900px){ 
         .colorboxmain{
            height:50px;
         }
      }
      @media(max-width:800px){ 
         .colorboxmain{
            height:45px;
         }
      }
      @media(max-width:700px){ 
         .colorboxmain{
            height:30px;
         }
      }
      @media(max-width:600px){ 
         .colorboxmain{
            height:25px;
         }
      }
      @media(max-width:500px){ 
         .colorboxmain{
            height:25px;
         }
         #barcodeTarget{
            zoom:80%;
            margin:auto;
         }




      }
      @media(max-width:400px){ 
         .colorboxmain{
            height:20px;
            margin:5px;
         }
         #barcodeTarget{
            zoom:75%;
            margin:auto;
         }
      }
      @media(max-width:300px){ 
         .colorboxmain{
            height:15px; 
         } 
         #barcodeTarget{
            zoom:50%;
            margin:auto;
         }
      }
      
      .sfsiplus_footerLnk{
    display: none;
}

      
</style>
<div id="page-loader" class="loading">Loading&#8230;</div>
<!---- Home page start ----->
<div class="main container">
   <!---body conteent----->
   <div class="maincontent">
      <div class="row mt-3 faqavalaiblehide">
         <div class="welcomeUser text-center">
         
         <?php
/*global $current_user; wp_get_current_user(); 
if ( is_user_logged_in() ) { 
 echo 'Username: ' . $current_user->user_login . "\n"; echo 'User display name: ' . $current_user->display_name . "\n"; } 
else { wp_loginout(); }*/
 


         if($_SESSION['loyalityLaneUserDetails'] != ''){
            if(!empty($_GET['tab'])){
               $mobileApp = substr($_GET['tab'],-6);
               if($mobileApp == 'mobile'){
                  echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login?logout=true&tab=home-mobile&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>";
               }else{
                  echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login?logout=true&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>";
               }
               
            }else{
               echo "<h2>Welcome ".strtolower($_SESSION['loyalityLaneUserDetails']->data->shopper->FirstName)." <span style='margin-left:80%; color:red; font-size:16px; margin-top:40px;'> <a href='".site_url()."/login?logout=true&token=".$_SESSION['ShopperToken']."'>Logout</a></span> </h2>";
            }
              
         }else{
          echo ($_GET['tab'] == 'home-mobile') ? '<a href="'.site_url().'/login/?tab=login-mobile" ><button  class="btn mb-3">Sign in</button></a>' : '<a href="'.site_url().'/login" ><button  class="btn mb-3">Sign in</button></a>';
         }

         ?>

         </div>
         
         <div class="col-md-12 mb-2">
            <div class="guidContent">
               <p>To redeem coupons:</p>
               <p>1. Click on the coupons that you want to use.</p>
               <p>2. Your coupons will automatically be applied to qualifying purchases when you give your phone number at the register</p>
            </div>
         </div>
         <div class="col-md-12 mt-2">
            <div class="serachCoupen">

               <select class="form-control selectOp1 brandCatCoupon" id="categoryOption">
               <option value="">Categories</option>
                  <option value="">All</option>
                  <?php 
                     $catData = $response->data->coupons;
                     $cat  = array();  
                     $brand = array();              
                     foreach($catData as $category){									
                     $cat[]   = $category->CategoryName;
                     $brand[] = $category->Brand;									
                     }
                     $cat_array = array_unique($cat);
                     $brand_array = array_unique($brand);
                     sort($cat_array);
                     sort($brand_array);
                     
                     foreach($cat_array as $cat){
                        
                     ?>
                  <option value="<?php echo $cat; ?>"><?php echo $cat; ?></option>
                  <?php 
                    
                     }
                     ?>	
               </select>


               <p id="mssg"></p>
               <select class="form-control selectOp2 brandCatCoupon" id="brandSelected">
                  <option value="">Brands</option>
                  <option value="">All</option>
                  <?php
                     foreach($brand_array as $band){ ?>
                  <option value="<?php echo $band; ?>"><?php echo $band; ?></option>
                  <?php } ?>
               </select>
              
            </div>
           
         </div>
      </div>
      
	  <?php
			if($isLoggedIn){ ?>
      <div class="row mt-3 faqavalaiblehide saving-data">
         <div class="col-md-4">
            <div class="userreward myreward">
               Available Savings: <span id="available_saving">$<?php echo number_format($totalAvailableSaving, 2);?></span>
            </div>
         </div>
         <div class="col-md-4 text-md-center">
            <div class="userreward myreward">
               Clipped Savings: <span id="clipped_saving">$<?php echo number_format($totalClippedSaving, 2); ?></span>
            </div>
         </div>
         <div class="col-md-4 text-md-right">
            <div class="userreward myreward">
               My Reward Points: <?php foreach($reward_value as $reward){ if($reward->BalanceDescription=='Points Balance'){ echo $reward->BalanceAmount; } }?>
            </div>
         </div>
      </div>



			<?php } ?>
      <div class="mt-3">
         <ul class="nav nav-tabs couponsTab" role="tablist">
         <?php
			if($isLoggedIn){

            $url = BASE_URL.'/Balance';
            $response = requestToLL($url,"GET",$_POST,$header); 
            
            ?>
         <li class="nav-item availables">
               <a <?php if($_GET['tab'] == 'home-mobile' || $_GET['tab'] == 'clipped-count-mobile'){?>style="display:none;" <?php }?> id="available-count" class="nav-link <?php echo ($_GET['type']=="Available" || $_GET['type']=="") ? 'active':'none' ?>" href="javascript:void(0);" role="tab">Available (<?php echo count($respAvailable->data->coupons) ?>)</a>
         </li>
         <li class="nav-item availables" <?php if($_GET['tab'] == 'home-mobile' || $_GET['tab'] == 'clipped-count-mobile'){ }else{?> style="display:none;" <?php } ?>>
         <a id="home-mobile" class="nav-link <?php echo ($_GET['type']=="Available" || $_GET['type']=="") ? 'active':'none' ?>" href="javascript:void(0);" role="tab">Available (<?php echo count($respAvailable->data->coupons) ?>)</a>
         </li>
			<li class="nav-item clipeds">
				<a <?php if($_GET['tab'] == 'home-mobile' || $_GET['tab'] == 'clipped-count-mobile'){?>style="display:none;" <?php }?> id="clipped-count" class="nav-link <?php echo ($_GET['type']=="Clipped") ? 'active':'none' ?>"  href="javascript:void(0);" role="tab">Clipped (<span id="clippedCountData"><?php echo count($countClipped->data->coupons) ?></span>)</a>
			</li>
         <li class="nav-item clipeds" <?php if($_GET['tab'] == 'home-mobile' || $_GET['tab'] == 'clipped-count-mobile'){ }else{?> style="display:none;" <?php } ?>>
				<a id="clipped-count-mobile" class="nav-link <?php echo ($_GET['type']=="Clipped") ? 'active':'none' ?>"  href="javascript:void(0);" role="tab">Clipped (<span id="clippedCountValue"><?php echo count($countClipped->data->coupons) ?></span>)</a>
			</li>
			<li class="nav-item myclubs">
				<a id="myclub-count" class="nav-link <?php echo ($_GET['type']=="MyClubs") ? 'active':'none' ?>" href="javascript:void(0);" role="tab">My Clubs (<?php echo count($response->data->offer_balances); ?>)</a>
			</li>
         <li class="nav-item my-rewards">
				<a id="my-reward" class="nav-link <?php echo ($_GET['type']=="MyReward") ? 'active':'none' ?>" href="<?php echo site_url()?>/reward-special/" role="tab">Reward Specials</a>
			</li>
         <li class="nav-item edit-profiles">
				<a id="edit-profile" class="nav-link" href="javascript:void(0);" role="tab">Edit Profile </a>
			</li>
         <li class="nav-item member-ids">
				<a id="member-id" class="nav-link" href="javascript:void(0);" role="tab">Member Id </a>
         </li>
         <li class="nav-item faq-pages">
				<a id="faq-page" class="nav-link" href="<?php echo site_url()?>/faqs/" role="tab">FAQs</a>
			</li>
         <li class="nav-item edit-profiles" style="display:none;">
				<a id="edit-profile-mobile" class="nav-link" href="javascript:void(0);" role="tab">Edit Profile </a>
			</li>
         <li class="nav-item member-ids" style="display:none;">
				<a id="member-id-mobile" class="nav-link" href="javascript:void(0);" role="tab">Member Id </a>
         </li>
         <li class="nav-item myclubs" style="display:none;">
				<a id="myclub-count-mobile" class="nav-link" href="javascript:void(0);" role="tab">My Clubs</a>
			</li>
         
			<?php } ?>
            
         </ul>
         <!-- Tab panes -->
         
         <div class="tab-content">
            <div class="tab-pane active" id="Available" role="tabpanel">
      
               <div class="row">
                  <?php 
                     foreach($coupons_value as $data){
                     ?>
                   <div class="col-md-6 col-lg-4 col-xl-4 <?php echo 'cat'.$data->CategoryName; ?> dataHide">
                     <div class="couponsItems">
                        <div class="proImg">
                           <img src="<?php echo $data->ImageUrl; ?>" class="customcouponimgheight img-fluid" style="width: auto; max-height: 100%; max-width: 100%;">
                        </div>
                        <div class="proDetails">
                           <h3><?php echo substr($data->OfferSummaryTop,0,11); ?></h3>
                           <p><?php echo substr($data->OfferShortDesc,0,70).'..'; ?></p>
                           <?php

                                $timestamp = strtotime($data->ExpirationDate);
                                $month = date("m", $timestamp);
                                $day = date("d", $timestamp);
                                $year = date("Y", $timestamp);
                                 $date1=date_create(date("Y-m-d"));
                                 $date2=date_create($year.'-'.$month.'-'.$day);
                                 $diff=date_diff($date1,$date2);
                                 if($diff->format("%a")<7){
                                    echo '<b style="color:red">'.$diff->format("%a").' Days left!</b>';
                                }
                              
                           ?>
                        </div>
                     </div>
                     <div class="CoupAction">
                        <div class="<?php if($_GET['type']=='Clipped'){?>ActionBtnLarge<?php }else{?>ActionBtn<?php } ?>">
                       
                          <a data-toggle="modal" data-target="#myModal" href="javascript:void(0)" data-available-id="Available" data-coupon-id="<?php echo $data->id ?>" class="coupDetails" id="coupon_details">Details</a>
                          
                           <?php if(empty($_SESSION['ShopperToken'])){ ?>	
                           <a href="<?php echo site_url();?>/login" class="coupSinup">Sign in To Clip </a>
                           <?php } else{ 
                           if($_GET['type']=="Clipped") {
                              echo "";
                           } else {
                              ?>
                           <!-- <a id="clipCoupon" href="<?php //echo site_url()?>/coupon?couponId=<?php //echo $data->id?>" class="coupSinup">Clip Coupon</a> -->
                           <a id="clipCoupon" href="javascript:void(0);" data-coupons-id='<?php echo $data->id; ?>' class="coupSinup">Clip Coupon</a>
                           <?php } } ?>		
                        </div>
                        <div class="ShareFB loginBtn--facebook">
                        <a fb-data-URL="<?php echo $current_url; ?>" fb-data-image="<?php echo $data->ImageUrl?>" fb-data-title="<?php echo $data->OfferShortDesc ?>" href="javascript:void(0);" class="ShareFB">Share on Facebook</a><br>
                        
                        </div>
                     </div>
                   </div>
                   <?php 
                  }              
               ?>
               </div>
            </div>
         </div>
      </div>
   </div>

   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
	<script type="text/javascript" src="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/jquery-barcode.js"></script>
 

   
   <!---body conteent end----->
</div>
<!---- Home page end ----->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
 <div id="modal-loader" class="loading">Loading&#8230;</div>
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Product Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
      <div class="modal-body">

         <div class="row">
           <div class="col-md-6"><b>Product image</b></div>
           <div class="col-md-6"><img src="" id="img_data" height="90px" width="90px"/></div>
           <div class="col-md-6"><b>Brand</b></div>
           <div class="col-md-6" id="brand_data"></div>
           <div class="col-md-6"><b>Category</b></div>
           <div class="col-md-6" id="category_data"></div>
           <div class="col-md-6"><b>Short Description</b></div>
           <div class="col-md-6" id="short_data"></div>
           <div class="col-md-6"><b>Expiration Date</b></div>
           <div class="col-md-6" id="expiration_data"></div>
           <div class="col-md-6"><b>UPCs</b></div>
           <div class="col-md-6" id="ItemUPCs" style="max-height: 150px; overflow-y: scroll;"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
      </div>
    </div>
  </div>
</div>
<div class='error' style="display:none;">Coupon has been clipped successfully!</div>

<script type="text/javascript">
$( document ).ready(function() {
    $(".loading").hide();

 $(document).on("click", '.coupDetails', function(e) { 
    $("#modal-loader").show();
    var coupon_id = $(this).attr("data-coupon-id");
    var availableORclipped = $(this).attr("data-available-id");
     
      jQuery.ajax({
        type:'POST',
        url : '<?php echo admin_url('admin-ajax.php'); ?>',
        data : {action : 'getCouponDetails', coupon_id : coupon_id, availableORclipped : availableORclipped },
        success:function(res){
          
          var today = new Date(res.ExpirationDate);
          var dd = String(today.getDate()).padStart(2, '0');
          var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
          var yyyy = today.getFullYear();

          today =   mm + '-'+dd+ '-' + yyyy;
          let UPC = '';
          res.ItemUPCs.forEach(data=>{
            UPC +=data+'<br>';
          })
          $("#act_date").html(res.ActivationDate);
          $("#brand_data").html(res.Brand);
          $("#category_data").html(res.CategoryName);
          $("#short_data").html(res.OfferShortDesc);
          $("#summary_data").html(res.OfferSummaryDetail);
          $("#source_data").html(res.SourceName);
          $("#value_data").html(res.Value);
          $("#expiration_data").html(today);
          $("#ItemUPCs").html(UPC);
          $("#img_data").attr('src',res.ImageUrl);
          $('#img_data').show();
          $("#modal-loader").hide();
        }
    });
    
  })

  

  $('.brandCatCoupon').on('change', function(e) {
    $('#available-count').addClass('active');
    $('#clipped-count').removeClass('active');
    $('#myclub-count').removeClass('active');
    $('#my-reward').removeClass('active');
    $('#edit-profile').removeClass('active');
    $('#faq-page').removeClass('active');
    $('#member-id').removeClass('active');
    $('#my-reward').removeClass('active');
  
    $("#page-loader").show();
      var searchByOption = $(this).val();
      //var get_id = $('option:selected').attr("id");
      
      jQuery.ajax({
        type: "POST",
        url : '<?php echo admin_url('admin-ajax.php'); ?>',
        data: {action : 'getCategoryByCoupons', searchByOption : searchByOption},

        success:function( data ) {
          document.getElementById('Available').innerHTML=data.output;
          <?php 
        if(array_key_exists('accountid',$_SESSION)) { ?>
          document.getElementById('available_saving').innerHTML='$'+data.AvailableSaving;
          document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
          document.getElementById('clipped-count').innerHTML='Clipped (<span id="clippedCountData">'+data.ClippedCount+'</span>)';
        <?php } ?>
          
          $("#page-loader").hide();
        }
      });
  });

  $('#clipped-count').on('click', function(e) {
  
    $(this).addClass('active');
    $('#available-count').removeClass('active');
    $('#myclub-count').removeClass('active');
    $('#my-reward').removeClass('active');
    $('#edit-profile').removeClass('active');
    $('#faq-page').removeClass('active');
    $('#member-id').removeClass('active');
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getClippedCoupons'},
      success:function( data ) {
        $('.serachCoupen').show();
        document.getElementById('Available').innerHTML=data.output;
        <?php 
        if(array_key_exists('accountid',$_SESSION)) { ?>
        document.getElementById('clipped_saving').innerHTML='$'+data.ClippedSaving;
        //document.getElementById('available_saving').innerHTML='$'+data.ClippedSaving;
        //document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        document.getElementById('clipped-count').innerHTML='Clipped (<span id="clippedCountData">'+data.ClippedCount+'</span>)';
        <?php } ?>
        
        $("#page-loader").hide();
      }
    });
  });

  $('#myclub-count').on('click', function(e) {

    $(this).addClass('active');
    $('#available-count').removeClass('active');
    $('#clipped-count').removeClass('active');
    $('#my-reward').removeClass('active');
    $('#edit-profile').removeClass('active');
    $('#faq-page').removeClass('active');
    $('#member-id').removeClass('active');
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getMyclubData'},
      success:function( data ) {
         $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data.output;
        $("#page-loader").hide(); 
      }
    });
  });

  $('#myclub-count-mobile').on('click', function(e) {
    var myclubData = 'myclub-count-mobile';
    $(".couponsTab").hide();
    $("#colophon").hide();
    $(".header-container_wrap").hide();
    $(".sfsiplus_footerLnk").hide();
    $(".guidContent").hide();
    $(".saving-data").hide();
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getMyclubData', myclubData : myclubData},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data.output;
        $("#page-loader").hide(); 
      }
    });
  });


  $('#available-count').on('click', function(e) {
    var category = '';
    var brand = '';
    if($('#categoryOption')[0].value != ''){
      var category = $('#categoryOption')[0].value;
    }
    if($('#brandSelected')[0].value != ''){
      var brand = $('#brandSelected')[0].value;
    }
    
    $(this).addClass('active');
    $('#clipped-count').removeClass('active');
    $('#myclub-count').removeClass('active');
    $('#my-reward').removeClass('active');
    $('#edit-profile').removeClass('active');
    $('#faq-page').removeClass('active');
    $('#member-id').removeClass('active');
    $('#my-reward').removeClass('active');
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getAvailableCoupons', 'category': category, 'brand' : brand},
      success:function( data ) {
        $('.serachCoupen').show();
        document.getElementById('Available').innerHTML=data.output;
        <?php 
        if(array_key_exists('accountid',$_SESSION)) { ?>
        document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        document.getElementById('available_saving').innerHTML='$'+data.AvailableSaving;
        <?php } ?>
        //document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
        $("#page-loader").hide();
      }
    });
  });


$('#home-mobile').on('click', function(e) {
    var category = '';
    var brand = '';
    if($('#categoryOption')[0].value != ''){
      var category = $('#categoryOption')[0].value;
    }
    if($('#brandSelected')[0].value != ''){
      var brand = $('#brandSelected')[0].value;
    }
    $(this).addClass('active');
    $('#clipped-count-mobile').removeClass('active');
    $(".myclubs").hide();
    $(".my-rewards").hide();
    $(".edit-profiles").hide();
    $(".member-ids").hide();
    $(".faq-pages").hide();
    $("#colophon").hide();
    $(".header-container_wrap").hide();
    $(".sfsiplus_footerLnk").hide();
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getAvailableCoupons', 'category': category, 'brand' : brand},
      success:function( data ) {
        $('.serachCoupen').show();
        document.getElementById('Available').innerHTML=data.output;
        <?php 
        if(array_key_exists('accountid',$_SESSION)) { ?>
        document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        document.getElementById('available_saving').innerHTML='$'+data.AvailableSaving;
        <?php } ?>
        //document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
        $("#page-loader").hide();
      }
    });
  });



  $('#clipped-count-mobile').on('click', function(e) {
  
  $(this).addClass('active');
  $('#home-mobile').removeClass('active');
    $(".myclubs").hide();
    $(".my-rewards").hide();
    $(".edit-profiles").hide();
    $(".member-ids").hide();
    $(".faq-pages").hide();
    $("#colophon").hide();
    $(".header-container_wrap").hide();
    $(".sfsiplus_footerLnk").hide();
  $("#page-loader").show();
  jQuery.ajax({
    type: "POST",
    url : '<?php echo admin_url('admin-ajax.php'); ?>',
    data: {action : 'getClippedCoupons'},
    success:function( data ) {
      $('.serachCoupen').show();
      document.getElementById('Available').innerHTML=data.output;
      <?php 
      if(array_key_exists('accountid',$_SESSION)) { ?>
      document.getElementById('clipped_saving').innerHTML='$'+data.ClippedSaving;
      //document.getElementById('available_saving').innerHTML='$'+data.ClippedSaving;
      //document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
      document.getElementById('clipped-count').innerHTML='Clipped (<span id="clippedCountData">'+data.ClippedCount+'</span>)';
      <?php } ?>
      
      $("#page-loader").hide();
    }
  });
});

  
  $(document).on("click", '.ShareFB', function(e) { 
    
    //var totalurl=encodeURIComponent(url+'?img='+img);
    var title = $(this).attr("fb-data-title");       
    var imgURL = $(this).attr("fb-data-image");
    var siteURL = $(this).attr("fb-data-URL");
    
     
    window.open('http://www.facebook.com/sharer.php?u='+imgURL+'&quote='+title+', '+siteURL,'','width=500, height=500, scrollbars=yes, resizable=no');
  })
  /* $('#my-reward').on('click', function(e) {
    $(this).addClass('active');
    $('#clipped-count').removeClass('active');
    $('#myclub-count').removeClass('active');
    $('#available-count').removeClass('active');
    $('#edit-profile').removeClass('active');
    $('#faq-page').removeClass('active');
    $('#member-id').removeClass('active');
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php //echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getMyReward'},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data.output;
        
        $("#page-loader").hide();
      }
    });
  });  */

  $('#edit-profile').on('click', function(e) {
    $(this).addClass('active');
    $('#clipped-count').removeClass('active');
    $('#myclub-count').removeClass('active');
    $('#available-count').removeClass('active');
    $('#faq-page').removeClass('active');
    $('#member-id').removeClass('active');
    $('#my-reward').removeClass('active');
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getEditProfile'},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data;
        //document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        //document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
        $("#page-loader").hide();
        
      }
    });
  });


  $('#edit-profile-mobile').on('click', function(e) {
    $(".couponsTab").hide();
    $("#colophon").hide();
    $(".faqavalaiblehide").hide();
    $(".header-container_wrap").hide();
    $(".sfsiplus_footerLnk").hide();
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getEditProfile'},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data;
        //document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        //document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
        $("#page-loader").hide();
        
      }
    });
  });

  $('#member-id-mobile').on('click', function(e) {
    $(".couponsTab").hide();
    $("#colophon").hide();
    $(".faqavalaiblehide").hide();
    $(".header-container_wrap").hide();
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getMemberId'},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data;
        generateBarcode();
        //document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        //document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
        $("#page-loader").hide();
      }
    });
  });



  $('.nav-link').click(function(){
    const url = new URL(window.location);
    url.searchParams.set('tab', this.id);
    window.history.pushState({}, '', url);
  })
  /* $('#faq-page').on('click', function(e) {
    $(this).addClass('active');
    $('#clipped-count').removeClass('active');
    $('#myclub-count').removeClass('active');
    $('#available-count').removeClass('active');
    $('#edit-profile').removeClass('active');
    $('#member-id').removeClass('active');
    $('#my-reward').removeClass('active');
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php //echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getFaqPage'},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data.output;
        //document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        //document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
        $("#page-loader").hide();
      }
    });
  }); */

  $('#member-id').on('click', function(e) {
    $(this).addClass('active');
    $('#clipped-count').removeClass('active');
    $('#myclub-count').removeClass('active');
    $('#available-count').removeClass('active');
    $('#edit-profile').removeClass('active');
    $('#faq-page').removeClass('active');
    $('#my-reward').removeClass('active');
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'getMemberId'},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data;
        generateBarcode();
        //document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        //document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
        $("#page-loader").hide();
      }
    });
  });


  $(document).on("click", '#clipCoupon', function(e) { 
    // alert(e);
    var coupon_ids = $(this).attr("data-coupons-id");
    // alert(coupon_ids);
    var clippedCount = $('#clippedCountData').text();
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: { action : 'occuredClipCoupon', couponidlist: coupon_ids, clippedCount: clippedCount},
      success:function( data ) {
        <?php
        if(array_key_exists('accountid',$_SESSION)) { ?>
          document.getElementById('clipped_saving').innerHTML='$'+data.totalClippedSaving;
        <?php } ?>
        document.getElementById('clippedCountData').innerHTML=data.clippedCountValue;
        document.getElementById('clippedCountValue').innerHTML=data.clippedCountValue;
        $('.error').stop().fadeIn(400).delay(3000).fadeOut(400);  
        //$('#available-count').click();
        const urlParams = new URLSearchParams(window.location.search);
                const myParam = urlParams.get('tab');
        if(myParam != 'home-mobile'){
          $('#available-count').click();
        }else{
          $('#'+myParam).click();
        }
                
        // $("#page-loader").hide();
      }
    });
  });

  $(document).on("click", '#accountButton', function(e) { 
     if(formValidate()){
    var fname = $("#fname").val();
    var lname = $("#lname").val();
    var pcontact = $("#pcontact").val();
    var address = $("#address").val();
    var city = $("#city").val();
    var state = $('#state :selected').val();
    var zcode = $("#zcode").val();
    var dateData = $("#birthdate").val();
    var homestore = $('#homestore :selected').val();
    var shopperid = $("#shopper_id").val();

    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: { action : 'editProfileToSaveData', 'shopperid' : shopperid, 'firstname' : fname, 'lastname' : lname, 'mobilephone' : pcontact, 'streetaddress1' : address, 'city' : city, 'state' : state, 'zipcode' : zcode, 'birthdate' : dateData, 'homestore' : homestore},
      success:function( data ) {
        document.getElementById('successData').innerHTML=data;
        $("#page-loader").hide();
      }
    });
     }
  });

  $(document).on("click", '#change-pass', function(e) {
    $('#member-id').removeClass('active');
    $('#clipped-count').removeClass('active');
    $('#myclub-count').removeClass('active');
    $('#available-count').removeClass('active');
    $('#edit-profile').removeClass('active');
    $('#faq-page').removeClass('active');
    $('#my-reward').removeClass('active');
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'changePassword'},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('Available').innerHTML=data;
        //document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        //document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
        $("#page-loader").hide();
      }
    });
  });


  $(document).on("click", '#resetEmailButtom', function(e) {
    var email= $("#email-data").val();
    
    $("#page-loader").show();
    jQuery.ajax({
      type: "POST",
      url : '<?php echo admin_url('admin-ajax.php'); ?>',
      data: {action : 'verifyEmail', 'email' : email},
      success:function( data ) {
        $('.serachCoupen').hide();
        document.getElementById('resetPassLink').innerHTML=data;
        //document.getElementById('available-count').innerHTML='Available ('+data.Availablecount+')';
        //document.getElementById('clipped-count').innerHTML='Clipped ('+data.ClippedCount+')';
        $("#page-loader").hide();
      }
    });
  });

function formValidate(){
  var count = true;
  var fname = document.getElementById("fname").value;
  var lname = document.getElementById("lname").value;
  var pcontact = document.getElementById("pcontact").value;
  var address = document.getElementById("address").value;
  var city = document.getElementById("city").value;
  var state = document.getElementById("state").value;
  var zcode = document.getElementById("zcode").value;
  var homestore = document.getElementById("homestore").value;
  if(fname==""){
    document.getElementById("fnameError").innerHTML="First Name is required.";
    document.documentElement.scrollTop = 450;
    count = false;
  }
  else{
    document.getElementById("fnameError").innerHTML="";
  }
  if(lname==""){
    document.getElementById("lnameError").innerHTML="Last Name is required.";
    document.documentElement.scrollTop = 450;
    count = false;
  }
  else{
    document.getElementById("lnameError").innerHTML="";
  }
  if(pcontact==""){
    document.getElementById("pcontactError").innerHTML="Phone Number is required.";
    document.documentElement.scrollTop = 450;
    count = false;
  }else if(!/^[0-9]+$/.test(pcontact)){
    document.getElementById("pcontactError").innerHTML="Phone Number must be numeric value.";
    document.documentElement.scrollTop = 450;
    count = false;
  }
  else{
    document.getElementById("pcontactError").innerHTML="";
  }
  if(address==""){
    document.getElementById("addressError").innerHTML="Address Number is required.";
    document.documentElement.scrollTop = 450;
    count = false;
  }else{
    document.getElementById("addressError").innerHTML="";
  }
  if(city==""){
    document.getElementById("cityError").innerHTML="City is required.";
    document.documentElement.scrollTop = 450;
    count = false;
  }
  else{
    document.getElementById("cityError").innerHTML="";
  }
  if(state==""){
    document.getElementById("stateError").innerHTML="State is required.";
    document.documentElement.scrollTop = 450;
    count = false;
  }else{
    document.getElementById("stateError").innerHTML="";
  }
  if(zcode==""){
    document.getElementById("zcodeError").innerHTML="Zip code is required.";
    document.documentElement.scrollTop = 450;
    count = false;
  }else if(zcode.length>5 || zcode.length<5){
    document.getElementById("zcodeError").innerHTML="Zip code must be five digit number.";
    document.documentElement.scrollTop = 450;
    count = false;
  }
  else{
    document.getElementById("zcodeError").innerHTML="";
  }
  if(homestore==""){
    document.getElementById("homestoreError").innerHTML="Home Store is required.";
    document.documentElement.scrollTop = 750;
    count = false;
  }else{
    document.getElementById("homestoreError").innerHTML="";
  }
  if(count==false){
    return count;       
  }else{
    return count;
  }
}
<?php
if(array_key_exists('accountid',$_SESSION)) { ?>
const urlParams = new URLSearchParams(window.location.search);
const myParam = urlParams.get('tab');
$('#'+myParam).click();
<?php } ?>

 function generateBarcode(){
        var value = $("#barcodeValue").val();
        var btype = $("input[name=btype]:checked").val();
        var renderer = $("input[name=renderer]:checked").val();

        var settings = {
          output:renderer,
          bgColor: $("#bgColor").val(),
          color: $("#color").val(),
          barWidth: $("#barWidth").val(),
          barHeight: $("#barHeight").val(),
          moduleSize: $("#moduleSize").val(),
          posX: $("#posX").val(),
          posY: $("#posY").val(),
          addQuietZone: $("#quietZoneSize").val()
        };
        if ($("#rectangular").is(':checked') || $("#rectangular").attr('checked')){
          value = {code:value, rect: true};
        }
        if (renderer == 'canvas'){
          clearCanvas();
          $("#barcodeTarget").hide();
          $("#canvasTarget").show().barcode(value, btype, settings);
        } else {
          $("#canvasTarget").hide();
          $("#barcodeTarget").html("").show().barcode(value, btype, settings);
        }
      }
          
      function showConfig1D(){
        $('.config .barcode1D').show();
        $('.config .barcode2D').hide();
      }
      
      function showConfig2D(){
        $('.config .barcode1D').hide();
        $('.config .barcode2D').show();
      }
      
      function clearCanvas(){
        var canvas = $('#canvasTarget').get(0);
        var ctx = canvas.getContext('2d');
        ctx.lineWidth = 1;
        ctx.lineCap = 'butt';
        ctx.fillStyle = '#FFFFFF';
        ctx.strokeStyle  = '#000000';
        ctx.clearRect (0, 0, canvas.width, canvas.height);
        ctx.strokeRect (0, 0, canvas.width, canvas.height);
      }
      
      $(function(){
        $('input[name=btype]').click(function(){
          if ($(this).attr('id') == 'datamatrix') showConfig2D(); else showConfig1D();
        });
        $('input[name=renderer]').click(function(){
          if ($(this).attr('id') == 'canvas') $('#miscCanvas').show(); else $('#miscCanvas').hide();
        });
        generateBarcode();
      });


      (function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
      fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
  });
    </script>

