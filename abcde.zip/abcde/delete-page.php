<?php
$forget = get_option('forget_pass_teet');
   wp_delete_post($forget);
$signup = get_option('signup_page_teet');
  wp_delete_post($signup);
$signin = get_option('login_page_teet');
  wp_delete_post($signin);
$rewards = get_option('rewards_page_teet');
  wp_delete_post($rewards);
$reset = get_option('reset_page_teet');
  wp_delete_post($reset);
$specialrewards = get_option('special_rewrads_page_teet');
 wp_delete_post($specialrewards);
 $faq = get_option('faq_page_teet');
 wp_delete_post($faq);

?>