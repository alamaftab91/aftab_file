<?php
/*
Plugin Name: EpicSolution Plugin
*/

//adding page template
class PageTemplater {

	private static $instance;

	protected $templates;

	public static function get_instance() {

		if ( null == self::$instance ) {
			self::$instance = new PageTemplater();
		} 

		return self::$instance;

	} 
	private function __construct() {

		$this->templates = array();
		if ( version_compare( floatval( get_bloginfo( 'version' ) ), '4.7', '<' ) ) {
			add_filter(
				'page_attributes_dropdown_pages_args',
				array( $this, 'register_project_templates' )
			);

		} else {

			add_filter(
				'theme_page_templates', array( $this, 'add_new_template' )
			);

		}
		add_filter(
			'wp_insert_post_data', 
			array( $this, 'register_project_templates' ) 
		);
		add_filter(
			'template_include', 
			array( $this, 'view_project_template') 
		);
		// Add your templates to this array.
		$this->templates = array(
			'reward_specialTemplate.php' => 'specialRewardPage',
			'signup.php' => 'couponssignup',
			'faqTemplate.php'=> 'FAQ',
			'Forget_Password.php'=>'Forget_Password',
			'password_resetTemplate.php'=>'Reset Password',
			'loginTemplate.php'=>'couponsloginpage',
			'rewardsTemplate.php' => 'couponsrewardspage',		
		);			
	} 
	public function add_new_template( $posts_templates ) {
		$posts_templates = array_merge( $posts_templates, $this->templates );
		return $posts_templates;
	}
	public function register_project_templates( $atts ) {
		$cache_key = 'page_templates-' . md5( get_theme_root() . '/' . get_stylesheet() );

		$templates = wp_get_theme()->get_page_templates();
		if ( empty( $templates ) ) {
			$templates = array();
		} 
		wp_cache_delete( $cache_key , 'themes');
		$templates = array_merge( $templates, $this->templates );
		wp_cache_add( $cache_key, $templates, 'themes', 1800 );

		return $atts;

	} 
	public function view_project_template( $template ) {
		global $post;
		if ( ! $post ) {
			return $template;
		}
		if ( ! isset( $this->templates[get_post_meta( 
			$post->ID, '_wp_page_template', true 
		)] ) ) {
			return $template;
		} 

		$file = plugin_dir_path( __FILE__ ). get_post_meta( 
			$post->ID, '_wp_page_template', true
		);
		if ( file_exists( $file ) ) {
			return $file;
		} else {
			echo $file;
		}

		// Return template
		return $template;

	}
} 
add_action( 'plugins_loaded', array( 'PageTemplater', 'get_instance' ) );

//Add menu in setting
 add_action("admin_menu", "apiplugin_menu");
function apiplugin_menu() {

    add_options_page("EpicSolution", "EpicSolution","manage_options", "epicplugin", "epic_api");
}

function epic_api(){
	include(plugin_dir_path(__FILE__).'form.php');
}

//Plugin Activation Code 
function epic_api_table(){

include(plugin_dir_path(__FILE__).'insertpage.php');
   global $wpdb;
   $charset_collate = $wpdb->get_charset_collate();

   $tablename = $wpdb->prefix."api_detail";

   $sql = "CREATE TABLE $tablename (
      id mediumint(11) NOT NULL AUTO_INCREMENT,
     api varchar(255) NOT NULL,
     user_name varchar(255) NOT NULL,
     password varchar(255) NOT NULL,
     token varchar(255) NOT NULL,
     PRIMARY KEY (id)
   ) $charset_collate;";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );

}
register_activation_hook( __FILE__, 'epic_api_table' );

//Plugin Deactivation Code

register_deactivation_hook( __FILE__, 'my_plugin_remove_database' );

function my_plugin_remove_database() {
include(plugin_dir_path(__FILE__).'delete_page.php');
     global $wpdb;
     $table_name = $wpdb->prefix . 'api_detail';
     $sql = "DROP TABLE IF EXISTS $table_name";
     $wpdb->query($sql);
     delete_option("my_plugin_db_version");
}

//Adding Plugin Setting
add_filter('plugin_action_links_'.plugin_basename(__FILE__), 'epic_plugin_setting_link');
function epic_plugin_setting_link( $links ) {
	$links[] = '<a href="' .
		admin_url( 'options-general.php?page=epicplugin' ) .
		'">' . __('Settings') . '</a>';
	return $links;
}

//Adding ajax
include('ajax.php');


add_shortcode('epic_header', 'epic_header_function');
function epic_header_function() {
     
if($_GET['tab'] == 'home-mobile' || $_GET['tab'] == 'login-mobile' || $_GET['tab'] == 'signup-mobile' || $_GET['tab'] == 'forget-password-mobile' || $_GET['tab'] == 'reward-special-mobile'|| $_GET['tab'] == 'edit-profile-mobile' || $_GET['tab'] == 'member-id-mobile' || $_GET['tab'] == 'myclub-count-mobile' ){
	?>
	<style>
		.header-container_wrap{
           display:none;
        }
        #colophon{
         display:none;
        }
		
	</style>
<?php
}else{
	get_header();
}
}

if(isset($_GET['logout'])){
	setcookie ("member_login","");
	setcookie ("member_password","");
}


add_action('init', function() {
if(!empty($_SESSION['member_login'])){
if (!isset($_COOKIE['member_login'])) {
	setcookie("member_login",$_SESSION['member_login'], time()+3600 * 24 * 365);
	setcookie("member_password",$_SESSION['member_password'], time()+3600 * 24 * 365);
	//setcookie('my_cookie', 'some default Ram', strtotime('+1 day'));
}
}
});
