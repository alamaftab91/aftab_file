<?php /* Template Name: couponsloginpage */ 
error_reporting(0);

include(plugin_dir_path(__FILE__).'loyalityLane/functions.php');
echo do_shortcode('[epic_header]');

if(isset($_SESSION['loyalityLaneUserDetails']))
{
   echo "<script> window.location.href='".site_url()."/rewards'</script>";
} 
?>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/style.css">
  <link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/responsive.css">
  
<!---- Login page start ----->
<style>
input.largerCheckbox { 
            margin-top:10px;
            width: 20px; 
            height: 20px; 
        } 


        @media(max-width:992px){
         .alert-danger {
    font-size: 14px;
    display: block;
}
        }
</style>
<section class="loginPage">
   <div class="container">
      <div class="logSec"> 
         <div class="row">
         <?php
                      
                    
                 ?>
         <form role="search" method="post" class="w-100" action="">
                <?php
                      if($_GET['success'] == '1'){
                         $msg = 'Successfully created account..';
                        echo "<center><span class='alert alert-success' style='color:Green'>".$msg."</span></center><br>";
                      }
                      if(!empty($_SESSION['successMsg']))
                      {
                         //$msg = 'Successfully created account..';
                         echo "<center><span class='alert alert-success' style='color:Green'>".$_SESSION['successMsg']."</span></center><br>";
                         unset($_SESSION['successMsg']);
                      } 
                      else 
                      {
                         if(!empty($_SESSION['errorMsg'])){
                           echo "<center><span class='alert alert-danger' style='color:red'>".$_SESSION['errorMsg']."</span></center> <br>";
                           unset($_SESSION['errorMsg']);
                         }
                         
                      }
                  ?>
               <div class="col-md-6 m-auto">
               
                  <div class="formTitle">
                  
                     <h2 class="loginText">Sign In</h2>
                  </div>
                  <div class="form-group row mb-3">
                     <label for="" class="col-sm-4 col-form-label">Email Address<span style="color:red">*</span></label>
                     <div class="col-sm-8">
                        <input type="email" class="form-control" name="username" value="<?php if(isset($_COOKIE["member_login"])) { echo $_COOKIE["member_login"]; } ?>" id="uname">
                        <span style="color:red" id="unameError"></span>
                     </div>
                  </div>
                  <div class="form-group row mb-3">
                     <label for=" " class="col-sm-4 col-form-label">Password<span style="color:red">*</span></label>
                     <div class="col-sm-8">
                        <input type="password" class="form-control" name="password" value="<?php if(isset($_COOKIE["member_password"])) { echo $_COOKIE["member_password"]; } ?>" id="pass">
                        <span style="color:red" id="passError"></span>
                     </div>
                  </div>
                  <div class="form-group row mb-3">
                     <div class="col-sm-4"></div>
                     <div class="col-sm-8">
                     <input type="checkbox" name="remember" id="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> />
                        <label for=" " class="col-form-label setRem" style="position:relative;top:-1px;">Remember Me</label>
                     </div>
                  </div>
                  <div class="form-group row">
                     <div class="col-md-12 text-center">
                        <input type="hidden" name="DIGITAL" class="form-check-input" id="ShowPassword">
                        <!-- <label class="form-check-label" for="ShowPassword">Show Password</label> -->
                     </div>
                  </div>
                  <div class="form-group row">
                     <div class="col-md-12 signBtn text-center">
                        <!-- <a href="<?php echo site_url(); ?>/rewards/" > -->
                            <button class="btn" name="digital-login" type="submit" id="signinButton" onclick="return goSignin()">Sign in</button>
                        <!-- </a> -->
                     </div>
                  </div>
                  <div class="forBox text-center">
                     <!-- <a href="">Forget Email?</a><br/>
                        <a href="">I don't know my password</a> -->
                  </div>
                  <hr>
                  <div class="regisecContent">
                     <h2>Just got your card and enrolled at the store?</h2>
                     <p>Start here if this is your first time on our website after you enrolled at the store.</p>
                  </div>
                  <div class="signBtn text-center">
                  <?php if($_GET['tab'] == 'login-mobile'){ ?>
                     <a href="<?php echo site_url(); ?>/register-an-account/?tab=signup-mobile">
                        <button type="button" class="btn fs-28 mb-2">Register Account</button>                    
                    </a>
                    <a href="<?php echo site_url(); ?>/forget-password/?tab=forget-password-mobile">
                        <button type="button" class="btn fs-28 mb-2">Forgot Password</button>                    
                    </a>
                  <?php }else{ ?>
                    <a href="<?php echo site_url(); ?>/register-an-account/">
                        <button type="button" class="btn fs-28 mb-2">Register Account</button>                    
                    </a>
                    <a href="<?php echo site_url(); ?>/forget-password/">
                        <button type="button" class="btn fs-28 mb-2">Forgot Password</button>                    
                    </a>
                    <?php } ?>  
                  </div>

                  <div class="copyContent">
                     <p>&#169; 2020 Loyalty Lane, Inc V.3.63.21</p>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</section>
<script>
  
   function goSignin(){
      var count = true;
      var uname = document.getElementById("uname").value;
      var pass = document.getElementById("pass").value;
      if(uname==""){
			document.getElementById("unameError").innerHTML="Email Address is required.";
			count = false;
		}else{
            document.getElementById("unameError").innerHTML="";
      }
      if(pass==""){
			document.getElementById("passError").innerHTML="Password is required.";
			count = false;
		}else{
            document.getElementById("passError").innerHTML="";
		}

      if(count==false){
        return count;
      }else{
         return count;
      }
   }
</script>