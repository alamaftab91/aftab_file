<?php /* Template Name: Forget Password*/
include(plugin_dir_path(__FILE__).'loyalityLane/functions.php');

echo do_shortcode( '[head_epic]');
?>

<!---- Forget page start ----->
<section class="loginPage">
   <div class="container">
      <div class="logSec">
         <div class="row">
          <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/style.css">
<link rel="stylesheet" href="<?php echo plugin_dir_url('__FILE__')?>EpicSolutions/templates/css/responsive.css">
         <div class="col-md-10 col-offset-2 m-auto">
         <form role="search" method="POST" class="w-100" action="">
                 
               <div class="col-md-6 m-auto">
               
                  <div class="formTitle">
                     
                     <h2 class="loginText">Forgot Password</h2>
                  </div>
                  <div class="form-group row mb-3">
                     <label for="" class="col-sm-4 col-form-label">Email Address<span style="color:red">*</span></label>
                     <div class="col-sm-8">
                        <input type="email" class="form-control" name="contactInfo" required>
                     </div>
                  </div>
                  <div class="form-group row">
                     <div class="col-md-12 signBtn text-center">
                        <button class="btn" type="submit">Submit</button>
                     </div>
                  </div>
                  <div class="col-md-12">
    						   <hr>
    					</div>
    					<div class="col-md-12 text-center">
                  <?php if($_GET['tab'] == 'forget-password-mobile'){ ?>
    						<p>Already have an account? <a href="<?php echo site_url()?>/login/?tab=login-mobile">Login</a></p>
                  <?php 
                  }else{ ?>
                    <p>Already have an account? <a href="<?php echo site_url()?>/login">Login</a></p>
                  <?php }
                  ?>    
    					</div>

                  <div class="copyContent">
                     <p>&#169; 2020 Loyalty Lane, Inc V.3.63.21</p>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</section>
